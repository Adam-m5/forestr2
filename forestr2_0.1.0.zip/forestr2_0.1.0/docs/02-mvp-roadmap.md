# forestr MVP Roadmap

The MVP is the smallest defensible release that demonstrates the package's
design principles end-to-end. Each milestone is independently shippable.

## Milestone 0: Project bootstrap — DONE

- DESCRIPTION with minimal `Imports` and rich `Suggests`.
- NAMESPACE via `exportPattern` (will switch to explicit exports once
  roxygen2 runs are wired up).
- LICENSE (MIT), README, CONTRIBUTING, .gitignore, inst/CITATION.
- `.github/workflows/` for R-CMD-check, test-coverage, lint.
- `.lintr`, `styler.yaml`, `_pkgdown.yml`.

## Milestone 1: Data model — DONE

- `tree_inventory()` constructor + `is_/as_forestr2_inventory`.
- `repeated_measurements()` + `growth_increments()`.
- `plot_summary()` and `stand_summary()` with `fixed_area` and
  `explicit` expansion.
- `forestr2_options()` and `forestr2_fields()`.
- `print()` and `summary()` methods.
- Tests covering validation, expansion, increment computation.

**Exit criteria**: `R CMD check` passes; coverage ≥ 90% on `R/inventory.R`.

## Milestone 2: Volume — DONE (MVP scope)

- `calc_tree_volume()` with `form_factor`, `sectional`, `taper`,
  `equation` methods.
- `calc_stem_section_volume()` (Smalian, Huber, Newton).
- `calc_log_volume()` with cumulative + merchantable totals.
- `calc_merchantable_volume()` with rule-based inclusion.
- `calc_volume_by_plot()` and `calc_volume_by_stand()` with design-based
  SE and t-based CI.
- `fit_volume_model()` (lm/nls, optional nlme) + `predict_volume()`.
- Tests with deterministic numeric expectations.

**Out of scope for MVP** (deferred to `forestr.growth` or a minor release):

- BAF point sampling (function exists but calls `.NotYetImplemented()`).
- National Volume Estimator Library equations (require species parameter
  database — lands in `forestr.data`).
- Taper equation libraries (Kozak, Max-Burkhart): interface stubbed
  through `taper_fn`.

## Milestone 3: Biomass and carbon — DONE (MVP scope)

- `calc_tree_biomass()` (allometric, volume_density, equation).
- `calc_component_biomass()` with reconciliation check.
- `calc_aboveground_biomass()`, `calc_belowground_biomass()`,
  `calc_total_biomass()`.
- `calc_carbon_stock()` (carbon fraction applied once).
- `calc_co2e()` (opt-in 44/12 conversion).
- `fit_biomass_model()` + `predict_biomass()` (log-response with
  Baskerville bias correction).
- `aggregate_biomass_plot()` with design-based SE, Mg/ha, C and CO2e.
- Tests asserting the carbon-once and CO2e-opt-in invariants.

**Out of scope for MVP**:

- Bayesian biomass models (deferred to `forestr.growth` companion).
- Full uncertainty propagation across volume→biomass→carbon chain
  (interface stubbed via `interval = "prediction"` on fitted models).

## Milestone 4: Growth and yield — DONE (MVP scope)

- `growth_function_library()` (Chapman-Richards, Gompertz, logistic,
  von Bertalanffy, Schumacher, Hossfeld, Weibull, Richards alias).
- `fit_growth_model()` with k-fold CV.
- `predict_growth()` with optional CI.
- `site_index()` (anamorphic Chapman-Richards and Schumacher).
- `self_thinning()` (Reineke SDImax line).
- `mortality()` (constant-rate placeholder).
- `simulate_stand()` (deterministic, for sensitivity analysis).
- Tests on synthetic age-height series.

**Out of scope for MVP**:

- GAD (generalized algebraic difference) approaches.
- Distance-dependent individual-tree models.
- Mortality models with density and stress covariates.
- Recruitment models.

## Milestone 5: Experimental design — DONE (MVP scope)

- `aov_forestr2()` for CRD, RCBD, factorial, split-plot, repeated-measures.
- `cld_forestr2()` with emmeans/multcomp fallback to TukeyHSD.
- Supported adjustments: Tukey, Scheffe, Bonferroni, Holm, Dunnett, LSD,
  Duncan, Games-Howell (where emmeans/multcomp provide them).
- `confint.forestr2_aov()` delegates to `stats::confint()`.
- Tests with synthetic RCBD trials.

**Out of scope for MVP**:

- Alpha-lattice, row-column, augmented designs — `forestr.design`.
- AMMI, GGE, stability analyses — `forestr.design`.
- Spatial adjustment (AR1 x AR1) — `forestr.design` + `asreml`/`spATS`.

## Milestone 6: Documentation and CI — DONE

- `vignettes/forestr-workflow.Rmd` covering all 15 required sections.
- `_pkgdown.yml` with reference structure.
- `CONTRIBUTING.md` describing the scientific-review-then-implement workflow.
- `inst/CITATION` for methodological credits.
- `.lintr`, `styler.yaml`, three CI workflows.

## Milestone 7: CRAN-readiness — IN PROGRESS

- [ ] Run `devtools::check()` and fix all NOTE/WARNING/ERROR.
- [ ] Generate `man/` via `roxygen2::roxygenize()`.
- [ ] Replace `exportPattern` in NAMESPACE with explicit exports (roxygen2
  will rewrite it).
- [ ] Confirm 90%+ coverage via `covr::package_coverage()`.
- [ ] Cross-platform CI green on ubuntu/macos/windows for `release`,
  `oldrel-1`, `oldrel-2`, `oldrel-3`.
- [ ] Submit to CRAN; respond to reviewer comments; tag v0.1.0.

## Milestone 8: Companion packages — PLANNED (post-0.1.0)

- `forestr.data` — datasets and species parameter tables (0.2.0).
- `forestr.visuals` — ggplot2 themes and turnkey plots (0.2.0).
- `forestr.design` — specialized trial designs (0.3.0).
- `forestr.spatial` — sf/terra/LiDAR workflows (0.3.0).
- `forestr.growth` — advanced growth/yield and GAD models (0.4.0).

Each companion package keeps the core's review-warning discipline and
the `forestr_*` result class hierarchy.

## Prioritization rationale

The MVP delivers *vertical slice* value: a user can install only
`forestr`, build an inventory, compute volume + biomass + carbon + CO2e
with explicit units and parameter provenance, fit a growth model, project
it forward, run a basic RCBD analysis, and produce a defensible
reproducible report. Every default parameter that lacks peer-reviewed
provenance emits a visible warning. This slice is small enough to ship
to CRAN quickly and broad enough to validate the architecture.
