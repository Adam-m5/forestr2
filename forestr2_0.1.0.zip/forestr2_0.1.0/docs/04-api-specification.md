# forestr API Specification

All public functions live in `R/*.R`. Each is exported via the
`exportPattern` in NAMESPACE (to be replaced by explicit roxygen2-driven
exports once `roxygen2::roxygenize()` is run).

## 1. Data model

### `tree_inventory(...)`
- **Inputs**: `data` (optional data frame) + named vectors or column
  names for any of the standard fields. Control arguments
  `allow_missing_id`, `allow_duplicate_trees`, `allow_dead`.
- **Output**: `forestr2_inventory` (data.frame subclass).
- **Errors**: negative/zero measurements; duplicate `tree_id` within
  `plot_id`; non-coercible `measurement_date`.
- **Warnings**: implausible outliers (DBH > 300, height > 100, plot_area
  > 100 ha); unknown `status` values.

### `is_forestr2_inventory(x)`, `as_forestr2_inventory(x)`
Standard S3 predicates / coercers.

### `repeated_measurements(..., measurement_date, allow_negative_increment)`
- Builds a `forestr2_repeated` from the same inputs as `tree_inventory()`.
- Additional validation: `(tree_id, measurement_date)` uniqueness; negative
  DBH increment detection.

### `growth_increments(inv, variables)`
- First differences per tree, sorted by `measurement_date`.

### `plot_summary(inv, expansion, level)`, `stand_summary(inv, expansion)`
- Returns one row per plot/stand with basal area, volume, biomass per ha,
  diversity indices, mean DBH/height.

### `forestr2_fields()`
- Returns the canonical field-name vector.

### `forestr2_options(...)`
- Get/set package options.

## 2. Volume

### `calc_tree_volume(data, dbh_cm, height_m, method, form_factor, ...)`
- **Methods**: `form_factor` (default), `sectional`, `taper`, `equation`.
- **Output**: numeric vector (`output = "vector"`) or `forestr2_result`
  data frame (`output = "data.frame"`).
- **Invariants**: DBH converted cm→m *after* validation; volume in m³ per
  tree; species-specific form factors via named vector; merchantable
  height override supported; review-warning for default `form_factor`.

### `calc_stem_section_volume(top_diameter_cm, bot_diameter_cm, mid_diameter_cm, length_m, method)`
- **Methods**: `smalian`, `huber`, `newton`.
- **Validation**: positive lengths, non-negative diameters, matching
  vector lengths; Huber/Newton require `mid_diameter_cm`.

### `calc_log_volume(...)`
- Buckling records with optional `trim_allowance_m` and
  `bark_deduction_cm`. Returns log-level + cumulative + merchantable
  totals.

### `calc_merchantable_volume(...)`
- Rule-based inclusion: `min_top_diameter_cm`, `min_merchantable_length_m`,
  `max_defect_pct`, `min_stump_height_m`, `species_rules`,
  `product_class`. Returns `included` and `status_reason` columns.

### `calc_volume_by_plot(inv, expansion, level, conf_level)`,
### `calc_volume_by_stand(...)`
- Returns total, mean, SE, CI, n_trees, n_plots, estimator, units.
- SE is design-based: SD of plot-level per-ha volumes / sqrt(n_plots).

### `fit_volume_model(data, formula, start, weights, species, random, cv, log_response)`
- Supports `lm()`, `nls()`, and `nlme::nlme()` (when installed).
- Returns `forestr2_volume_model` with `$fit`, `$formula`, `$metrics`,
  `$cv_metrics`, `$bias_correction` (when `log_response = TRUE`).

### `predict_volume(object, newdata, dbh_cm, height_m, species, interval, level)`
- Returns data frame with `volume_m3` (and `lower`/`upper` when
  `interval != "none"`).

## 3. Biomass and carbon

### `calc_tree_biomass(data, dbh_cm, height_m, method, equation_form, coefficients, component, wood_density_kg_m3, form_factor, biomass_expansion_factor, root_to_shoot_ratio, ...)`
- **Methods**: `allometric` (power law in DBH or DBH+H), `volume_density`
  (volume × wood density × BEF × root-to-shoot), `equation` (user function).
- **Components**: `aboveground`, `stem`, `bark`, `branches`, `foliage`,
  `roots`, `deadwood`, `total`.

### `calc_component_biomass(..., component_fractions, tol)`
- Reconciliation: fractions must sum to 1 within `tol` (default 1e-3).

### `calc_aboveground_biomass(component_biomass)`, `calc_belowground_biomass(...)`, `calc_total_biomass(...)`
- Aggregate component long-form to per-tree totals.

### `calc_carbon_stock(biomass, carbon_fraction, output)`
- **Invariant**: carbon fraction applied exactly once.
- Range check: `carbon_fraction` must be in `[0.30, 0.60]`.

### `calc_co2e(carbon, ratio, output)`
- **Invariant**: opt-in only; uses `44/12` by default.

### `fit_biomass_model(data, formula, start, weights, species, cv, log_response)`
- Returns `forestr2_biomass_model` with Baskerville bias correction
  factor when `log_response = TRUE`.

### `predict_biomass(object, newdata, dbh_cm, height_m, species, interval, level)`

### `aggregate_biomass_plot(inv, expansion, level, carbon_fraction, include_co2e, conf_level)`
- Returns `biomass_kg_ha`, `biomass_Mg_ha`, `se`, `lower`, `upper`,
  `mean_biomass_per_tree_kg`, `carbon_stock_kg_ha`, `carbon_stock_Mg_ha`,
  optional `co2e_kg_ha`, `co2e_Mg_ha`, `n_trees`, `n_plots`.

## 4. Growth and yield

### `growth_function_library()`
- Named list of growth forms (Chapman-Richards, Gompertz, logistic, von
  Bertalanffy, Schumacher, Hossfeld, Weibull, Richards alias). Each entry
  has `f` (function), `pnames` (parameter names), `start` (starting-value
  generator function).

### `fit_growth_model(data, age_var, y_var, model, start, weights, cv)`
- Returns `forestr2_growth_model`.

### `predict_growth(object, age_yr, interval, level)`

### `site_index(height_m, age_yr, base_age_yr, model, params)`
- Anamorphic scaling. Default base age 50 years. Models:
  `chapman_richards`, `schumacher`.

### `self_thinning(dbh_q_cm, sdimax, exponent)`
- Reineke line. Default `sdimax = 450`, exponent `-1.605`.

### `mortality(n0, annual_rate, years)`
- Constant-rate decay: `N = N0 * (1 - r)^years`.

### `simulate_stand(initial, years, annual_ba_increment_pct, annual_mortality_rate, volume_ba_ratio)`
- Deterministic projection. Returns one row per year.

## 5. Experimental design

### `aov_forestr2(formula, data, design, contrasts)`
- Wraps `stats::aov()`. Supports `Error()` in formula for split-plot /
  repeated-measures. `design` argument is metadata-only.

### `cld_forestr2(aov_obj, factor, adjust, level, letters)`
- Uses `emmeans` + `multcomp` when installed; falls back to `TukeyHSD`.
- Supported `adjust`: `tukey`, `scheffe`, `bonferroni`, `holm`,
  `dunnett`, `lsd`, `duncan`, `games_howell`.

### `confint.forestr2_aov(object, parm, level)`
- Delegates to `stats::confint()` on the underlying `aov` object.

## 6. Utilities

### `format_sig(x, digits)`, `se_value(x, na.rm)`, `ci_vector(x, level, na.rm)`
- Numeric helpers exported for downstream use.

## 7. Standard generics

The package provides `print()` and (where appropriate) `summary()`,
`predict()`, `confint()` methods for its result classes. `plot()` methods
are deliberately minimal in the MVP (a future `forestr.visuals` companion
will provide richer `ggplot2` outputs).
