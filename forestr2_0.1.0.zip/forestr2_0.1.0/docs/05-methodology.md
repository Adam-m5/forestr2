# forestr Volume and Biomass Methodology Specification

This document specifies the equations, default parameters, estimators,
and known limitations of the volume and biomass modules. **Every default
parameter listed here is a scientific placeholder** and must be validated
against peer-reviewed literature or regional manuals before operational
use.

---

## Part A: Volume methodology

### A.1 Per-tree volume

#### A.1.1 Form-factor method (default)

$$V = BA \cdot h \cdot f$$

where:
- $BA = \pi \cdot (dbh_{\text{m}}/2)^2$ (basal area in m²),
- $h$ is total height (m), or merchantable height when
  `merchantable_height_m` is supplied,
- $f$ is the form factor (default `0.45`, **placeholder**).

**Default parameter source**: forestr placeholder. **Required review**:
species- and region-specific form factors from local volume tables.

#### A.1.2 Sectional method

Stem is divided into sections and volumes summed. Section volume is
computed via Smalian, Huber, or Newton (see A.2).

#### A.1.3 Taper / integrated stem

Cross-sectional area $A(h) = \pi \cdot (d(h)/2)^2$ is integrated along
the stem using the trapezoidal rule with `n_integrate` subintervals
(default 100):

$$V = \int_0^H A(h)\, dh \approx \sum_{i=1}^{n} \frac{A(h_i) + A(h_{i+1})}{2}\, \Delta h_i$$

The taper function `taper_fn(h_rel)` returns diameter (cm) at relative
height `h_rel ∈ [0, 1]`. Users supply the form; common forms (Kozak,
Max-Burkhart, Bi) will be added in a minor release.

#### A.1.4 Equation method

User-supplied function `f(dbh_cm, height_m, ...)` returns volume (m³).
Or a `forestr2_volume_model` returned by `fit_volume_model()`.

### A.2 Section volume formulas

#### Smalian
$$V = L \cdot (A_1 + A_2) / 2$$

#### Huber
$$V = L \cdot A_m$$

#### Newton
$$V = L \cdot (A_1 + 4 A_m + A_2) / 6$$

where $A_1$, $A_m$, $A_2$ are cross-sectional areas at the small end,
midpoint, and large end (cm²), $L$ is section length (m). Areas are
converted to m² by the constant $10^{-4}$.

**Recommended use**:
- Newton when midpoint diameter is available (most accurate).
- Smalian when only end diameters are available (most common).
- Huber when midpoint is available but logs are short and uniform.

### A.3 Log volume

`calc_log_volume()` applies Smalian by default (configurable to Huber or
Newton) to each log record. Cumulative volume per tree is returned. Bark
deduction (`bark_deduction_cm`) is applied uniformly to both diameters
before volume computation. Trim allowance (`trim_allowance_m`) is
recorded but does not alter computed volume.

### A.4 Merchantable volume

A log/section is included if and only if:

- `top_diameter_cm >= min_top_diameter_cm` (default 7 cm,
  **placeholder** — regional utilization standards vary), AND
- `length_m >= min_merchantable_length_m` (default 2.0 m), AND
- (optional) defect percent ≤ `max_defect_pct` (default 0; defect logic
  to be expanded in a minor release), AND
- (optional) stump height ≥ `min_stump_height_m` (default 0.3 m; applied
  at the stand level, not the log level).

`status_reason` is reported per log explaining inclusion/exclusion.

### A.5 Plot- and stand-level volume aggregation

#### Estimator

For each plot $j$:

$$\hat{V}_j^{\text{ha}} = \sum_{i \in \text{plot}_j} V_i \cdot EF_i$$

where $EF_i$ is the per-tree expansion factor (trees/ha represented).

For fixed-area plots: $EF = 1 / A_{\text{plot}}$ where $A_{\text{plot}}$
is in ha.

For explicit expansion: $EF$ is read from the `expansion_factor` column.

For BAF point sampling (planned, not yet implemented): $EF_i$ is
computed from the tree's inclusion angle and BAF.

#### Standard error

The reported SE is the **design-based** standard error of plot-level
per-hectare estimates:

$$\widehat{SE}(\bar{V}) = \frac{s_V}{\sqrt{n_{\text{plots}}}}, \quad
  s_V^2 = \frac{1}{n_{\text{plots}}-1} \sum_j (\hat{V}_j^{\text{ha}} - \bar{V})^2$$

with a t-based CI at `conf_level` and `df = n_plots - 1`.

**This is NOT the SE of tree-level observations.** Tree-level SE
conflates within-plot variance with sampling variance and is not
reported.

#### Limitations

- No stratified or unequal-probability weighting in the MVP (use
  `expansion = "explicit"` with pre-computed weights).
- No measurement-error propagation from volume equations (use
  `predict_volume(interval = "prediction")` for equation uncertainty).
- No finite-population correction.

### A.6 Volume equation fitting

`fit_volume_model()` supports three families:

1. **Linear (lm)**: e.g. `volume_m3 ~ I(dbh_cm^2 * height_m)` (constant
   form-factor model), `volume_m3 ~ dbh_cm + I(dbh_cm^2) + height_m`
   (combined-variable Schumacher-Hall).
2. **Nonlinear (nls)**: e.g. `volume_m3 ~ a * dbh_cm^b1 * height_m^b2`
   with user-supplied `start`.
3. **Mixed-effects (nlme)**: when `random` is supplied and `nlme` is
   installed.

#### Log-response with bias correction

When `log_response = TRUE`, the model is fit on `log(response)`. The
Baskerville (1972) bias correction factor is computed as:

$$\lambda = \exp(\hat{\sigma}^2 / 2)$$

where $\hat{\sigma}^2$ is the residual variance on the log scale.
Predictions are back-transformed as $\hat{V} = \exp(\hat{\log V}) \cdot \lambda$.

**Known limitation**: this is a logarithmic bias correction; for
heteroscedastic log-normal residuals, a more sophisticated correction
(e.g. Snowdon 1991 ratio) may be required. The `bias_correction` field
on the fitted model reports $\lambda$.

#### Cross-validation

`cv` controls the number of k-folds. Each fold is fit on the training
portion and predictions are accumulated across folds. RMSE, MAE, and
bias are reported as `cv_metrics`.

---

## Part B: Biomass and carbon methodology

### B.1 Per-tree biomass

#### B.1.1 Allometric method

Power-law forms:

- **DBH-only**: $B = a \cdot D^b$
- **DBH + height**: $B = a \cdot D^{b_1} \cdot H^{b_2}$
- **Combined variable**: $B = a \cdot (D^2 H)^{b_1} + b_2 \cdot D + b_3$

Coefficients must be supplied by the user. **There are no default
allometric coefficients** — the function stops with an error if
`coefficients` is missing.

#### B.1.2 Volume-density method

$$B_{\text{stem}} = V \cdot \rho$$

where $V$ is stem volume (m³) and $\rho$ is wood density (kg/m³).
Aboveground biomass is:

$$B_{\text{AG}} = B_{\text{stem}} \cdot BEF$$

where $BEF$ is the biomass expansion factor (default `1.3`,
**placeholder**).

Total biomass with belowground:

$$B_{\text{total}} = B_{\text{AG}} \cdot (1 + R)$$

where $R$ is the root-to-shoot ratio (default `0.25`, IPCC 2006
default for tropical/subtropical moist forest, **placeholder**).

Belowground biomass:

$$B_{\text{BGB}} = B_{\text{AG}} \cdot R$$

#### B.1.3 Equation method

User-supplied function `f(dbh_cm, height_m, ...)` returns biomass (kg).

### B.2 Component biomass

`calc_component_biomass()` distributes total biomass across components
using a species-specific fraction table. **Reconciliation invariant**:
the fractions (stem + bark + branches + foliage + roots + deadwood)
must sum to 1 within `tol` (default 1e-3); otherwise the function errors.

### B.3 Carbon stock

$$C = B \cdot f_C$$

where $f_C$ is the carbon fraction (default `0.47`, **placeholder**).

**Critical invariant**: `calc_carbon_stock()` is the ONLY function that
applies $f_C$. The result is a `carbon_kg` column. Downstream functions
(including `aggregate_biomass_plot()`) treat this as a carbon mass and
do not multiply by $f_C$ again.

**Range check**: $f_C \in [0.30, 0.60]$. Values outside this range are
rejected with an informative error.

### B.4 CO2 equivalent

$$CO_2e = C \cdot \frac{44}{12}$$

`calc_co2e()` is opt-in: no public function returns CO2e unless this
function is explicitly called. The molecular-weight ratio `44/12`
(≈3.667) is the IPCC default.

### B.5 Aggregation

`aggregate_biomass_plot()` returns:

- `biomass_kg_ha`: $\sum_i B_i \cdot EF_i$ per plot, averaged across plots.
- `biomass_Mg_ha`: biomass_kg_ha / 1000.
- `mean_biomass_per_tree_kg`: mean of per-tree biomass (tree-level mean,
  not weighted).
- `carbon_stock_kg_ha`: `biomass_kg_ha * carbon_fraction` (applied once,
  via `calc_carbon_stock()` internally).
- `co2e_kg_ha`: only when `include_co2e = TRUE`.
- `se`, `lower`, `upper`: design-based t-CI as in volume aggregation.

### B.6 Biomass model fitting

`fit_biomass_model()` mirrors `fit_volume_model()` with the following
addition: when `log_response = TRUE`, the `metrics$retransformation_bias_correction`
field reports the Baskerville factor and is exposed via
`predict_biomass()` for back-transformation.

**Limitations**:
- No measurement-error propagation from DBH/height into biomass.
- No hierarchical Bayesian models (planned for `forestr.growth`).
- No covariance structure across component equations (each component
  equation is fit independently).

---

## Part C: Parameter default register

The following defaults are **scientific placeholders**. They are
recorded here so reviewers can audit and replace them.

| Parameter                              | Default             | Module                  | Required review |
|----------------------------------------|---------------------|-------------------------|-----------------|
| `form_factor`                          | 0.45                | Volume A.1.1            | Species-specific form factor from local volume tables. |
| `min_top_diameter_cm` (merchantable)   | 7                   | Volume A.4              | Regional utilization standard (e.g. 5 cm pulp, 14 cm sawlog). |
| `min_merchantable_length_m`            | 2.0                 | Volume A.4              | Regional sawlog standard. |
| `min_stump_height_m`                   | 0.3                 | Volume A.4              | Regional stump height standard. |
| `biomass_expansion_factor` (BEF)       | 1.3                 | Biomass B.1.2           | Species- and stand-structure-specific BEF. |
| `root_to_shoot_ratio`                  | 0.25                | Biomass B.1.2           | IPCC 2006 species group defaults; verify species applicability. |
| `carbon_fraction`                      | 0.47                | Carbon B.3              | Species-specific carbon fraction from elemental analysis. |
| `wood_density_kg_m3`                   | (no default)        | Biomass B.1.2           | Required input; no default. Users should supply species-specific values from `forestr.data` or the Global Wood Density Database. |
| `sdimax` (Reineke)                     | 450                 | Growth self-thinning    | Species-specific SDI maximum from regional yield tables. |
| `chapman_richards` site curve params   | Asym=35, k=0.04, p=1.5 | Growth site_index    | Species- and region-specific site curve parameters. |
| `annual_ba_increment_pct` (simulator)  | 0.03                | Growth simulate_stand   | Stand-specific; for sensitivity only. |
| `annual_mortality_rate` (simulator)    | 0.01                | Growth simulate_stand   | Stand-specific; for sensitivity only. |
| `volume_ba_ratio` (simulator)          | 5                   | Growth simulate_stand   | Stand-specific; for sensitivity only. |

Each default emits a `forestr2_review_warning` on first use. Warnings
are suppressed via
`forestr2_options(forestr.review_warnings = FALSE)` only after
parameters have been validated.

---

## Part D: Estimator and assumption documentation

Every result carries a `parameter_source` attribute and (for plot/stand
results) an `estimator` column documenting:

1. The estimator form (e.g. "design-based mean of plot-level per-ha volumes").
2. The expansion factor convention (`fixed_area` / `explicit`).
3. The parameter source string (e.g. "form_factor=0.45; BEF=1.3;
   root_to_shoot=0.25; forestr placeholder (review)").
4. The units of the primary result.

This documentation is printed by `print.forestr2_result()` and is
intended to be embedded in reproducible reports.
