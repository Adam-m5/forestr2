# forestr Data Standard Specification

## 1. Canonical field names

`forestr` recognizes the following canonical field names. User-defined
names are supported through explicit `*_field` arguments on constructors
(e.g. `tree_inventory(data = df, dbh_cm = "D")`).

| Field                  | Type        | Unit        | Required | Description |
|------------------------|-------------|-------------|----------|-------------|
| `tree_id`              | character   | —           | yes      | Unique per plot. |
| `plot_id`              | character   | —           | yes      | Plot identifier. |
| `stand_id`             | character   | —           | no       | Stand identifier; allows stand-level aggregation. |
| `species`              | character   | —           | yes      | Scientific name (Genus species). Recommended. |
| `species_code`         | character   | —           | no       | Operational species code (e.g. FIA codes). |
| `dbh_cm`               | numeric     | cm          | yes      | Diameter at breast height (1.3 m). |
| `height_m`             | numeric     | m           | no       | Total height. Required for `form_factor` volume. |
| `crown_width_m`        | numeric     | m           | no       | Mean crown width. |
| `tree_age`             | numeric     | years       | no       | Age at breast height or total age; document which. |
| `status`               | character   | category    | no       | One of `live`, `dead`, `harvested`, `missing`, `damaged`, `dying`, `recruit`. Default `live`. |
| `x`, `y`               | numeric     | m           | no       | Stem coordinates (CRS documented separately). |
| `measurement_date`     | Date/POSIXct| date        | yes for `repeated_measurements()` | Measurement date. |
| `basal_area_m2_ha`     | numeric     | m²/ha       | no       | Pre-computed basal area per ha (overrides `dbh_cm`-derived BA when present). |
| `volume_m3`            | numeric     | m³          | no       | Pre-computed per-tree stem volume. |
| `biomass_kg`           | numeric     | kg          | no       | Pre-computed per-tree biomass. |
| `treatment`            | character   | category    | no       | Treatment label. |
| `block`                | character   | id          | no       | Block label for RCBD. |
| `plot_area_ha`         | numeric     | ha          | yes for `fixed_area` expansion | Plot area in hectares. |
| `expansion_factor`     | numeric     | per_ha      | no       | Per-tree expansion factor (trees/ha represented by this tree). |

## 2. Validation rules

The constructor `tree_inventory()` enforces:

| Rule                                                                 | Effect |
|----------------------------------------------------------------------|--------|
| `tree_id` missing and `allow_missing_id = FALSE`                     | ERROR |
| `tree_id` duplicated within `plot_id` and `allow_duplicate_trees = FALSE` | ERROR |
| `tree_id` duplicated within `plot_id` and `allow_duplicate_trees = TRUE`  | WARNING |
| `dbh_cm` negative                                                    | ERROR |
| `dbh_cm` zero                                                        | ERROR |
| `dbh_cm > 300`                                                       | WARNING (implausible) |
| `height_m` negative                                                  | ERROR |
| `height_m` zero                                                      | ERROR |
| `height_m > 100`                                                     | WARNING |
| `plot_area_ha` negative or zero                                      | ERROR |
| `plot_area_ha > 100`                                                 | WARNING |
| `expansion_factor` negative or zero                                  | ERROR |
| `basal_area_m2_ha`, `volume_m3`, `biomass_kg` negative               | ERROR |
| `status` not in known vocabulary                                     | WARNING (kept as-is) |
| `status == "dead"` and `allow_dead = FALSE`                          | ERROR |

For `repeated_measurements()`:

| Rule                                          | Effect |
|-----------------------------------------------|--------|
| `(tree_id, measurement_date)` duplicated      | ERROR |
| `measurement_date` not coercible to Date      | ERROR |
| Negative DBH increment for same tree          | WARNING (unless `allow_negative_increment = TRUE`) |

## 3. Unit conventions

| Quantity            | Default unit |
|---------------------|--------------|
| Diameter            | cm           |
| Height, length      | m            |
| Area                | ha           |
| Volume              | m³           |
| Biomass             | kg           |
| Carbon              | kg           |
| CO2 equivalent      | kg           |
| Basal area          | m²/ha        |
| Density             | trees/ha     |
| Wood density        | kg/m³        |
| Carbon fraction     | unitless     |
| BEF, root-to-shoot  | unitless     |

Conversion to other units (Mg/ha, t/ha, tC/ha) is performed only at
explicit aggregation steps (`aggregate_biomass_plot()` returns both
`biomass_kg_ha` and `biomass_Mg_ha`).

## 4. Result classes

### `forestr2_inventory`

A `data.frame` subclass with attributes:

- `units`: named character vector mapping field → unit.
- `design`: list with `plot_area_ha`, `expansion_factor`, `has_blocks`,
  `has_treatments`.
- `validated_at`: POSIXct timestamp.
- `validation_warnings`: character vector of warnings emitted.
- `parameter_source`: `"user-supplied"` for user-built inventories.

### `forestr2_repeated`

A `forestr2_inventory` subclass (additional class tag
`"forestr2_repeated"`) built by `repeated_measurements()`.

### `forestr2_result`

A `data.frame` subclass returned by all `calc_*`, `aggregate_*`, and
`predict_*` functions. Attributes:

- `method`: character scalar naming the estimator.
- `units`: character scalar describing the units of the primary result.
- `parameter_source`: character scalar naming the parameters used (with
  placeholder markers where applicable).
- (Optional) `estimator`: explicit estimator description for plot/stand
  results.

`print.forestr2_result()` displays these attributes above the data frame.

### `forestr2_volume_model`, `forestr2_biomass_model`, `forestr2_growth_model`

Lists returned by `fit_*()` functions, containing `$fit` (the underlying
lm/nls/nlme object), `$formula`, `$metrics`, `$cv_metrics`, and
`$parameter_source`.

## 5. Identifier conventions

- `tree_id` is unique **within `plot_id`**, not globally.
- `plot_id` is unique within `stand_id` (when `stand_id` is present).
- Across repeated measurements, `(tree_id, measurement_date)` is unique.

## 6. Missing-value policy

All `calc_*()` functions accept `missing = c("error","warn","return_na")`
with the default `"error"`. `"warn"` proceeds and produces `NA` values
with a warning; `"return_na"` is silent and produces `NA`s.

For grouped aggregation (`calc_volume_by_plot()`,
`aggregate_biomass_plot()`), `NA`s in per-tree values are dropped from
the per-plot sum (i.e. `sum(..., na.rm = TRUE)`). The number of `NA`s
is reported in `validation_warnings`.

## 7. Date and time

`measurement_date` is stored as `Date` by `repeated_measurements()`. A
POSIXct input is accepted and down-converted (the time-of-day component
is dropped). Dates are interpreted in the user's local timezone unless
the input is explicitly `UTC`.

## 8. Encoding

All character fields are stored as UTF-8. The package sets
`Encoding: UTF-8` in DESCRIPTION. Species names with diacritics are
supported.
