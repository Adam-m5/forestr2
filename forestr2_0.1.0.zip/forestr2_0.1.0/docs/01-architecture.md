# forestr Architecture and Package-Boundary Recommendation

## 1. Design philosophy

`forestr` is built on five non-negotiable principles:

1. **Units are never inferred.** Every numeric field declares its unit in
   its name (`dbh_cm`, `height_m`, `plot_area_ha`, `basal_area_m2_ha`) and
   in a `units` attribute on constructed objects. Functions that consume
   measurements validate the unit explicitly before any conversion.
2. **Estimators are documented, not magic.** Every plot- and stand-level
   estimator reports (a) the formula used, (b) the expansion factor, (c)
   the standard-error convention (tree-level vs. design-based plot-level),
   and (d) the units of the result. This is attached as attributes on the
   returned data frame and printed by `print.forestr2_result`.
3. **Production equations are flagged for review.** Any default parameter
   that lacks peer-reviewed, region- and species-specific provenance
   carries a `TODO(scientific-review)` marker in source and emits a
   `forestr2_review_warning` on first use. The warning is a feature, not a
   bug: it prevents silent publication of unsuitable parameters.
4. **Minimal mandatory dependencies.** Core `forestr` depends only on
   base-recommended packages. `tibble`, `ggplot2`, `dplyr`, `nlme`,
   `lme4`, `emmeans`, and `multcomp` are `Suggests` and loaded
   opportunistically. Spatial and Bayesian extensions live in companion
   packages.
5. **Companion packages are first-class extension points.** The core
   package never imports from `forestr.spatial`, `forestr.growth`,
   `forestr.design`, or `forestr.visuals`. Extension points are documented
   S3 generics or explicitly named hooks.

## 2. Layered architecture

```
┌────────────────────────────────────────────────────────────────────┐
│  forestr.visuals        forestr.spatial        forestr.growth      │
│  (ggplot2, dist plots)  (sf, terra, LiDAR)    (GAD, advanced YM)  │
└────────────────────────────────────────────────────────────────────┘
            │                     │                     │
            ▼                     ▼                     ▼
┌────────────────────────────────────────────────────────────────────┐
│                     forestr.design                                │
│   (specialized experimental designs: provenance, nursery,         │
│    thinning, fertilization, multi-environment trials)             │
└────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌────────────────────────────────────────────────────────────────────┐
│                       forestr (core)                              │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │  R/inventory.R     — tree_inventory, plot/stand summaries    │ │
│  │  R/volume.R        — calc_tree_volume + sectional/log/merch  │ │
│  │  R/biomass.R       — biomass, carbon, CO2e, components       │ │
│  │  R/yield-models.R  — site index, growth fit/predict, sim     │ │
│  │  R/statistics.R    — aov_forestr2, cld_forestr2                │ │
│  │  R/utils.R         — validators, units, NA policy            │ │
│  │  R/forestr2-package.R — options, review-warning helper        │ │
│  └──────────────────────────────────────────────────────────────┘ │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │  tests/testthat/   — unit tests (≥90% coverage target)       │ │
│  │  vignettes/        — workflow vignette                       │ │
│  │  inst/CITATION     — methodological credits                  │ │
│  └──────────────────────────────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────────────┘
            │
            ▼
┌────────────────────────────────────────────────────────────────────┐
│  forestr.data  — redistributable datasets and data dictionaries    │
│  (synthetic inventories, species parameter tables, demo trials)    │
└────────────────────────────────────────────────────────────────────┘
```

## 3. Package-boundary decisions

### 3.1 What stays in `forestr` (core)

- **Data model constructors**: `tree_inventory()`,
  `repeated_measurements()`, plus `is_/as_forestr2_inventory()`.
- **Inventory summaries**: `plot_summary()`, `stand_summary()`,
  `growth_increments()`.
- **Volume**: `calc_tree_volume()`, `calc_stem_section_volume()`,
  `calc_log_volume()`, `calc_merchantable_volume()`,
  `calc_volume_by_plot()`, `calc_volume_by_stand()`,
  `fit_volume_model()`, `predict_volume()`.
- **Biomass and carbon**: `calc_tree_biomass()`,
  `calc_component_biomass()`, `calc_aboveground_biomass()`,
  `calc_belowground_biomass()`, `calc_total_biomass()`,
  `calc_carbon_stock()`, `calc_co2e()`, `fit_biomass_model()`,
  `predict_biomass()`, `aggregate_biomass_plot()`.
- **Growth and yield (foundational)**: `growth_function_library()`,
  `fit_growth_model()`, `predict_growth()`, `site_index()`,
  `self_thinning()`, `mortality()`, `simulate_stand()`.
- **Experimental design (essential)**: `aov_forestr2()`, `cld_forestr2()`
  covering CRD, RCBD, factorial, split-plot, repeated-measures with
  emmeans/multcomp fallback to base R.
- **Utilities**: `forestr2_options()`, `forestr2_fields()`, `format_sig()`,
  `se_value()`, `ci_vector()`.

### 3.2 What moves to `forestr.data`

- Redistributable demo inventories and trial datasets.
- Species parameter tables (wood density, BEF, root-to-shoot ratios, form
  factors) curated from public literature with explicit citation columns.
- Data dictionaries and metadata files.

**Rationale**: keeps core lightweight and lets users depend on the data
package only when they need example data. Data packages also avoid CRAN
binary-size limits for the core.

### 3.3 What moves to `forestr.spatial`

- `sf`/`terra` integration for plot maps and stand polygons.
- LiDAR-derived metrics (CHM, canopy cover, individual tree segmentation).
- Raster workflows (predicting biomass maps from inventory + remote sensing).
- Landscape pattern metrics.

**Rationale**: spatial dependencies (`sf`, `terra`, `lidR`, `stars`) are
heavy and have system requirements. Keeping them in a companion package
keeps the core installable in minimal environments (CI, Docker, cloud
functions).

### 3.4 What moves to `forestr.growth`

- Generalized Algebraic Difference (GAD) approaches.
- Distance-independent and distance-dependent individual-tree models
  (e.g. Prognaus, BWIN, Moses-style).
- Stand-level growth simulators with detailed mortality, recruitment,
  and self-thinning submodels.
- Bayesian hierarchical growth models (via `rstan`/`brms`, declared as
  Suggests in the companion package).

**Rationale**: advanced growth models are scientifically opinionated and
benefit from being versioned independently. The core provides the
fit/predict scaffold and the basic function library; the companion
package provides the depth.

### 3.5 What moves to `forestr.design`

- Specialized trial designs: alpha-lattice, row-column, augmented
  designs, provenance trials with multi-environment analysis.
- Genotype-by-environment interaction analyses (AMMI, GGE).
- Spatial adjustment models (AR1 x AR1) using `asreml` or `spATS`.
- Reproducible randomization generators with seed tracking.

### 3.6 What moves to `forestr.visuals`

- `ggplot2` themes and palettes branded for forestry publications.
- Stand table visualization, diameter distribution overlays with Weibull
  fits, height-diameter scatter with species-specific volume isolines.
- Volume/biomass profiles, residual diagnostics dashboards, CLD plot
  helpers.

## 4. Cross-package conventions

All packages in the ecosystem share:

- **The `forestr2_inventory` class**. Constructors in `forestr.spatial`
  can extend it (e.g. add an `sf` geometry column) and the class
  hierarchy remains valid.
- **The `forestr2_result` class** for tabular outputs, with attributes
  `method`, `units`, `parameter_source`, and (optionally) `estimator`.
- **The review-warning helper** `warn_review_placeholder()` (exported as
  internal but re-used by companions via `forestr2:::warn_review_placeholder`).
- **The options registry** under the `forestr.*` prefix via
  `forestr2::forestr2_options()`.

## 5. Dependency policy

| Package       | Status in `forestr` | Reason |
|---------------|---------------------|--------|
| `stats`       | Depends (R default) | ANOVA, nls, predict. |
| `utils`       | Depends (R default) | read/write.csv, sessionInfo. |
| `methods`     | Depends (R default) | S3/S4 plumbing. |
| `graphics`    | Depends (R default) | default `plot()` methods. |
| `grDevices`   | Depends (R default) | color utilities. |
| `tibble`      | Suggests            | Return tibbles when installed. |
| `ggplot2`     | Suggests            | Plot methods. |
| `dplyr`       | Suggests            | Grouped workflows in examples. |
| `tidyr`       | Suggests            | Long/wide pivots in vignettes. |
| `nlme`        | Suggests            | Mixed-effects volume/biomass. |
| `lme4`        | Suggests            | Alternative mixed-effects. |
| `emmeans`     | Suggests            | EMMs and CLD. |
| `multcomp`    | Suggests            | Tukey/Dunnett/Scheffe. |
| `MASS`        | Suggests            | Games-Howell fallback. |
| `testthat`    | Suggests            | Testing. |
| `roxygen2`    | Suggests            | Documentation generation. |
| `knitr`       | Suggests            | Vignette engine. |
| `rmarkdown`   | Suggests            | Vignette output format. |
| `pkgdown`     | Suggests            | Site generation. |
| `lintr`       | Suggests            | Linting. |
| `styler`      | Suggests            | Code styling. |
| `covr`        | Suggests            | Coverage. |
| `withr`       | Suggests            | Test scoping. |

The package never uses `:::` for cross-package internals within the
ecosystem. Companion packages export their own public API.

## 6. Failure modes the architecture prevents

| Failure mode | How the architecture prevents it |
|---|---|
| Silent unit confusion (cm vs m) | Every numeric field has a unit suffix; validators reject non-positive values; cm-to-m conversion happens *after* validation, never before. |
| Double application of carbon fraction | `calc_carbon_stock()` is the *only* function that multiplies biomass by `carbon_fraction`; the result is a `carbon_kg` column. Downstream `calc_co2e()` multiplies by `44/12`, not by `carbon_fraction` again. Tests assert the invariant. |
| Silent CO2e inflation | `calc_co2e()` is opt-in; no public function returns CO2e unless explicitly requested. |
| Tree-level SE reported as plot-level SE | `calc_volume_by_plot()` aggregates per-tree values to plot-level per-ha values *before* computing the SE. The `estimator` column is `design-based mean of plot-level per-ha volumes`. |
| Inability to track parameter provenance | Every `forestr2_result` carries a `parameter_source` attribute printed by `print.forestr2_result()`. |
| Placeholder parameters presented as universal | `warn_review_placeholder()` fires on first use of every default; `forestr2_options(forestr.review_warnings = FALSE)` is an explicit, documented override. |
| Heavy system requirements for basic use | Core depends only on base-recommended packages. Spatial and Bayesian extensions are companion packages. |

## 7. Open architectural questions

These are flagged for governance discussion, not resolved by the MVP:

1. **`units` package integration.** Should we depend on the `units` package
   for first-class unit arithmetic? Pro: eliminates ambiguity. Con: adds a
   hard dependency. Recommended: keep `units` as a Suggests and add an
   optional `validate_with_units()` validator in a future minor release.
2. **S4 vs S3.** We have chosen S3 for simplicity and inheritance from
   `data.frame`. If the spatial companions require richer dispatch, an S4
   `ForestrInventory` class may be warranted. Decision deferred.
3. **`data.table` vs `dplyr` for grouped workflows.** Core functions use
   base R's `split`/`lapply`/`do.call(rbind, ...)` to avoid any hard
   dependency. `dplyr`-style grouped workflows are demonstrated in the
   vignette when `dplyr` is installed.
4. **Multilingual strings.** Species names and treatment labels are
   stored as character. We do not currently localize messages. A future
   i18n pass (using `gettext`) may be warranted for non-English CRAN
   submissions.
