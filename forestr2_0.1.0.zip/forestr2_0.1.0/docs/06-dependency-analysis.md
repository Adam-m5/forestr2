# forestr Dependency and Competitor Analysis

## 1. R package dependencies

### 1.1 Hard dependencies (`Depends`/`Imports`)

| Package     | Why required                              | Replaceable? |
|-------------|-------------------------------------------|--------------|
| `stats`     | `lm()`, `nls()`, `aov()`, `predict()`, `qt()`, `sd()`, etc. | No (R default). |
| `utils`     | `read.csv()`, `write.csv()`, `sessionInfo()`, `head()`, `tail()`. | No (R default). |
| `methods`   | S3/S4 dispatch helpers.                   | No (R default). |
| `graphics`  | Default `plot()` methods.                 | No (R default). |
| `grDevices` | `rgb()` and color utilities.              | No (R default). |

The MVP deliberately has **zero non-base-recommended dependencies**.
This keeps install time minimal on CI, in Docker, and on cloud
functions, and avoids version-pinning problems on CRAN.

### 1.2 Suggested dependencies

| Package     | Why suggested                                       | Used by                                    |
|-------------|-----------------------------------------------------|--------------------------------------------|
| `tibble`    | Return tibbles instead of data frames when installed. | `as_forestr2_result_df()`, summary methods. |
| `ggplot2`   | Plot methods, vignette examples.                    | Vignettes; future `forestr.visuals`. |
| `dplyr`     | Grouped workflows in examples.                      | Vignettes. |
| `tidyr`     | Long/wide pivoting in examples.                     | Vignettes. |
| `nlme`      | Mixed-effects volume/biomass models.                | `fit_volume_model(random = ...)`, `fit_biomass_model()`. |
| `lme4`      | Alternative mixed-effects (faster for large data).  | Planned; not yet wired up. |
| `emmeans`   | Estimated marginal means and CLD.                   | `cld_forestr2()`. |
| `multcomp`  | Tukey/Dunnett/Scheffe/Games-Howell.                 | `cld_forestr2()`. |
| `MASS`      | Games-Howell fallback; `rlm` for robust regression. | Planned for `cld_forestr2(adjust = "games_howell")`. |
| `testthat`  | Unit testing framework.                             | `tests/testthat/`. |
| `roxygen2`  | Documentation generation.                           | Build-time. |
| `knitr`     | Vignette engine.                                    | `vignettes/`. |
| `rmarkdown` | Vignette output format.                             | `vignettes/`. |
| `pkgdown`   | Documentation website.                              | Site generation. |
| `lintr`     | Static analysis.                                    | CI. |
| `styler`    | Code formatting.                                    | CI. |
| `covr`      | Coverage tracking.                                  | CI. |
| `withr`     | Test scoping.                                       | Tests. |

### 1.3 Reserved companion-package namespaces

| Package             | Required by the core? | Purpose |
|---------------------|-----------------------|---------|
| `forestr.data`      | No                    | Redistributable datasets and species parameter tables. |
| `forestr.spatial`   | No                    | sf, terra, lidR, stars workflows. |
| `forestr.growth`    | No                    | Advanced growth/yield, GAD, Bayesian hierarchical models. |
| `forestr.design`    | No                    | Specialized trial designs and MET analyses. |
| `forestr.visuals`   | No                    | ggplot2 themes and turnkey forestry plots. |

The core package never imports from these. Extension points are
documented S3 generics or hooks in `R/forestr2-package.R`.

## 2. Competitor and adjacent-package analysis

### 2.1 General-purpose R forestry packages

| Package       | Scope                                            | forestr difference |
|---------------|--------------------------------------------------|--------------------|
| `rFIA`        | FIA database extraction and estimation.          | forestr is method-agnostic and works on any inventory; `forestr.data` may include FIA-derived parameter tables but does not couple to the FIA database. |
| `lme4`/`nlme` | Mixed-effects modeling.                          | forestr uses these as `Suggests` for mixed effects, not as primary APIs. |
| `rstan`/`brms`| Bayesian hierarchical models.                    | Deferred to `forestr.growth`. |
| `sitree`      | Individual-tree simulators (Norway).             | forestr provides foundational fit/predict; advanced simulation lands in `forestr.growth`. |
| `ForIT`       | Italian forestry inventory tools.                | Region-specific; forestr is method-generic. |
| `BIOMASS`     | Tropical biomass estimation.                     | forestr provides the same equation framework with explicit placeholder parameters and review warnings. |

### 2.2 General-purpose experimental design

| Package       | Scope                                            | forestr difference |
|---------------|--------------------------------------------------|--------------------|
| `agricolae`   | Agricultural experimental design; the design inspiration. | forestr adds unit-aware inventory data model, design-based SE for plot/stand estimates, and forestry-specific designs (provenance, thinning) planned for `forestr.design`. |
| `emmeans`     | Estimated marginal means.                        | Used as `Suggests`; not a competitor. |
| `multcomp`    | Multiple comparisons.                            | Used as `Suggests`; not a competitor. |
| `asreml`      | Commercial; AR1×AR1 spatial adjustment.          | `forestr.design` will offer `spATS` as an open-source alternative. |
| `lme4`/`nlme` | Mixed-effects.                                   | Used as `Suggests`. |

### 2.3 Spatial and remote sensing

| Package       | Scope                                            | forestr difference |
|---------------|--------------------------------------------------|--------------------|
| `sf`          | Vector spatial data.                             | Companion `forestr.spatial`. |
| `terra`       | Raster data.                                     | Companion `forestr.spatial`. |
| `lidR`        | LiDAR processing.                                | Companion `forestr.spatial`. |
| `ForestTools` | Tree segmentation from CHM.                      | Companion `forestr.spatial` (wrapper or interop). |

### 2.4 Adjacent ecosystems

| Ecosystem | Adjacent package | forestr difference |
|-----------|------------------|--------------------|
| Python    | `forsys` (Portland State) | forestr is R-native; uses `data.frame` and base R idioms familiar to forestry analysts. |
| Julia     | `ForestBiometrics.jl` | forestr targets the larger R user base; potential future interop via `JuliaCall`. |
| C++       | `libforestry` (hypothetical) | forestr is R-only for MVP; performance-critical inner loops can be ported via `Rcpp` in a minor release without API changes. |
| Jupyter   | (various) | forestr works in `IRkernel`; the workflow vignette renders to HTML and notebook formats. |

## 3. Why `forestr` exists

The R forestry ecosystem has many specialized packages but lacks a
unified, dependency-light, unit-aware foundation that:

1. **Enforces units explicitly** (no silent cm/m conflation).
2. **Reports design-based SEs** at the plot/stand level, never
   conflating them with tree-level SEs.
3. **Applies carbon fraction exactly once** and treats CO2e conversion
   as opt-in.
4. **Flags every placeholder parameter with a visible warning** so users
   cannot publish unsuitable defaults without explicitly suppressing the
   warning.
5. **Supports the full inventory → volume → biomass → carbon → CO2e →
   statistics → growth → simulation workflow** in a single package
   with a consistent result class.

`agricolae` inspired the accessible workflow design but is
agriculture-focused and does not address tree/plot/stand data models or
volume/biomass methods. `rFIA` couples tightly to the FIA database.
`BIOMASS` is tropical-focused and does not enforce the carbon-once
invariant. `sitree` is region-specific (Norway) and does not include
experimental-design workflows.

## 4. Interoperability policy

`forestr` results are returned as `data.frame` subclasses with explicit
attributes. They are designed to interoperate cleanly with:

- `dplyr` pipes (`%>%` or native `|>`): all `calc_*()` functions accept
  a `data` argument as their first parameter.
- `ggplot2`: vignettes demonstrate `ggplot(as.data.frame(inv), ...)`.
  `as.data.frame()` strips the `forestr2_inventory` class but preserves
  the columns.
- `tidyr::pivot_longer()` for converting component biomass results to
  long form.
- `emmeans` / `multcomp` for downstream multiple comparisons (the result
  of `cld_forestr2()` is a plain `forestr2_result` data frame).

The package does **not** import `magrittr` or any pipe operator; users
may use either `%>%` (if `magrittr`/`dplyr` is loaded) or native `|>`
(R ≥ 4.1).
