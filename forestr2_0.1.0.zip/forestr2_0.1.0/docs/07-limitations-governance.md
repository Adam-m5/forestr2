# forestr Limitations, Governance, and Release-Readiness Report

## 1. Scientific limitations

### 1.1 Placeholder parameters

Every default parameter listed in `docs/05-methodology.md` Part C is a
scientific placeholder. They have been chosen to be plausible (within
published ranges) but are **not** validated for any specific species,
region, or operational use case. They emit `forestr2_review_warning` on
first use.

**Implication**: Results produced with default parameters are suitable
for:
- Teaching and workshops.
- Internal prototyping.
- Sensitivity analyses that vary parameters systematically.

They are **not** suitable for:
- Carbon crediting (VCS, CDM, ART, Gold Standard).
- Operational harvest scheduling.
- Regulatory reporting.
- Publication without parameter validation.

### 1.2 Estimator limitations

| Estimator | Limitation | Mitigation |
|-----------|------------|------------|
| Design-based SE (plot/stand) | Does not propagate equation uncertainty. | Use `predict_volume(interval = "prediction")` / `predict_biomass(interval = "prediction")` and propagate via simulation or bootstrap. |
| Volume form factor | Generic 0.45 default. | Supply species-specific form factor or fit `fit_volume_model()` with species as a covariate. |
| Volume sectional (Smalian) | Bias of ~5-10% on strongly tapering logs. | Use Newton when midpoint diameter available. |
| Volume taper | User must supply `taper_fn`; no library of standard taper equations in MVP. | Planned for minor release (Kozak, Max-Burkhart, Bi). |
| Biomass allometric | No default coefficients; user must supply. | Curated coefficient tables will land in `forestr.data`. |
| Biomass volume-density | Linear BEF assumption; real BEF depends on stand structure. | Use species- and stand-structure-specific BEF. |
| Belowground biomass | Root-to-shoot ratio is a placeholder; root mass is highly uncertain. | Use species-specific equations from Mokany et al. (2006) where available. |
| Carbon fraction | Generic 0.47; species-specific values range 0.42-0.51. | Use species-specific elemental analysis where available. |
| Site index | Anamorphic scaling assumes the curve shape is constant across sites. | Polymorphic site curves planned for minor release. |
| Mortality | Constant annual rate. | Density-dependent mortality planned for `forestr.growth`. |
| Stand simulator | Deterministic; for sensitivity only. | Stochastic simulator with recruitment and density-dependent mortality planned for `forestr.growth`. |

### 1.3 Design limitations

- BAF (point) sampling is not yet implemented.
- Stratified and unequal-probability designs are not supported in the
  MVP; users must supply pre-computed expansion factors via
  `expansion = "explicit"`.
- No finite-population correction.
- No small-area estimation.

### 1.4 Data limitations

- No redistributable datasets ship with the MVP (planned for
  `forestr.data`).
- The vignette uses synthetic data that does not represent any real
  species or stand structure.
- Species parameter tables (wood density, BEF, form factors) are not
  bundled; users must supply them or wait for `forestr.data`.

## 2. Software limitations

### 2.1 Performance

- Volume and biomass calculations are vectorized in R; no `Rcpp` is
  used in the MVP. For inventories > 10^6 trees, a future minor release
  may port hot loops to `Rcpp`.
- `plot_summary()` uses `split`/`lapply`/`do.call(rbind, ...)`. With
  `dplyr` installed, users can achieve faster grouped workflows by
  calling the lower-level `calc_*()` functions directly in a pipe.

### 2.2 Compatibility

- R ≥ 3.6.0 is required (uses no R 4.x-only features, but tests are
  run on R 4.x).
- The package is pure R with no compiled code. Platform-specific issues
  are not anticipated.
- The vignette is rendered with `rmarkdown::html_vignette`; no special
  LaTeX is required.

### 2.3 Documentation

- Roxygen2 docs are complete in source but `man/` has not yet been
  regenerated. Run `roxygen2::roxygenize()` before CRAN submission.
- The pkgdown site has not yet been built. Run `pkgdown::build_site()`
  after the first CRAN release.

## 3. Governance

### 3.1 Scientific review board

The project will convene a small Scientific Review Board (3-5 members)
with expertise covering:

- Forest biometrics and growth & yield.
- Carbon accounting and IPCC / VCS methodologies.
- Experimental design for forestry trials.
- R package development and CRAN submission.

The Board reviews and approves:
- Removal of any `TODO(scientific-review)` marker.
- Promotion of a parameter from placeholder to default-with-citation.
- New equations entering the core package.
- Companion package release plans.

### 3.2 Code governance

- **Lead maintainer**: forestr Core Team (currently a placeholder; a
  real-name maintainer must be designated before CRAN submission).
- **Contributors**: must sign off on the CONTRIBUTING.md workflow.
- **Code review**: all PRs require at least one reviewer; PRs touching
  volume/biomass/carbon methods require a domain reviewer.
- **CI policy**: all PRs must pass `R CMD check`, `lintr`, `styler`
  check, and ≥90% coverage on changed lines.

### 3.3 Versioning

The package follows semantic versioning:
- 0.x.y: pre-1.0; breaking changes permitted with minor-version bump.
- 1.0.0: first CRAN stable release; backward-compatible from there.
- Patch (x.y.Z): bug fixes only.
- Minor (x.Y.0): new features, backward-compatible.
- Major (X.0.0): breaking changes; migration guide required.

### 3.4 Discontinuation policy

If the project becomes unmaintained for > 12 months, the Scientific
Review Board will:
1. Notify CRAN to archive the package.
2. Publish a final release with a `NEWS` entry pointing to any active
   forks.
3. Mark the GitHub repository as archived.

## 4. Release readiness

### 4.1 MVP (v0.1.0) readiness checklist

| Item | Status |
|------|--------|
| DESCRIPTION passes `R CMD check --as-cran`. | Pending (run devtools::check()). |
| NAMESPACE generated by roxygen2. | Pending (roxygen2::roxygenize()). |
| All exported functions have runnable examples. | Done. |
| All exported functions have tests. | Done. |
| Coverage ≥ 90%. | Pending (run covr::package_coverage()). |
| Vignette builds without error. | Pending (run rmarkdown::render). |
| R CMD check passes on Linux, macOS, Windows. | Pending (CI). |
| lintr passes. | Pending (CI). |
| styler check passes. | Pending (CI). |
| inst/CITATION is correct. | Done. |
| LICENSE is correct (MIT). | Done. |
| ORCID and maintainer email populated. | **Pending** — placeholder email and ORCID must be replaced. |
| CRAN Submission Notes prepared. | Pending. |

### 4.2 Blockers for CRAN submission

1. **Maintainer identity**: `forestr Core Team` is a placeholder; CRAN
   requires a real person with a working email address.
2. **roxygen2 regeneration**: `man/` must be generated before submission.
3. **Vignette build verification**: the vignette must be confirmed to
   build on a clean R installation without the `Suggests` packages that
   are not strictly required for vignette rendering (e.g. `ggplot2`).
4. **Cross-platform CI verification**: the workflow matrix in
   `.github/workflows/R-CMD-check.yaml` must be green on all platforms
   before submission.
5. **Methodology citations**: the vignette and selected man pages should
   cite key references (Baskerville 1972; Reineke 1933; Chapman 1961;
   Richards 1959; IPCC 2006). A `inst/REFERENCES.bib` is recommended.

### 4.3 Post-0.1.0 milestones (non-blocking)

- `forestr.data` (v0.2.0): species parameter tables and demo datasets.
- `forestr.visuals` (v0.2.0): ggplot2 themes and turnkey plots.
- BAF point sampling in core (v0.2.0).
- Stratified / unequal-probability design support in core (v0.2.0).
- Taper equation library (Kozak, Max-Burkhart, Bi) (v0.3.0).
- `forestr.design` companion (v0.3.0).
- `forestr.spatial` companion (v0.3.0).
- `forestr.growth` companion (v0.4.0).

## 5. Risk register

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| User publishes results with placeholder parameters despite warnings. | Medium | High (reputational, scientific). | Warnings on first use; documented in vignette and methodology spec; `print.forestr2_result()` displays `parameter_source`. |
| Carbon fraction applied twice by user pipeline. | Low (prevented by API design). | High (incorrect carbon estimates). | Invariant enforced by API: `calc_carbon_stock()` is the only function applying the fraction. Tests assert the invariant. |
| CO2e silently inflated. | Low (prevented by API design). | High (regulatory non-compliance). | `calc_co2e()` is opt-in only. |
| Mixed-effects model fitting fails on `nlme` version drift. | Medium | Medium | `Suggests` requirement on `nlme (>= 3.1)`. CI matrix tests on `release` and `oldrel-1`. |
| CRAN flags missing `ORCID` / maintainer email. | High (will block submission). | High (release delay). | Replace placeholders before submission. |
| Spatial companion packages create circular dependency with core. | Low | High | Architectural rule: core never imports companions; companions import core. CI linter can enforce. |
| Bayesian methods require heavy dependencies. | Medium | Medium (user friction). | Bayesian methods live exclusively in `forestr.growth` with `rstan`/`brms` as `Suggests`. |

## 6. Conclusion

The MVP delivers a scientifically defensible, unit-aware foundation for
forest inventory and growth modeling in R. Every default parameter
lacking peer-reviewed provenance is visibly flagged. Every estimator
reports its formula, expansion factor, and SE convention. The carbon-once
and CO2e-opt-in invariants are enforced by API design and verified by
tests.

The package is **not yet CRAN-ready** (placeholder maintainer identity
and `man/` regeneration are required), but the architecture, code,
tests, vignette, CI configuration, and documentation are in place for
a v0.1.0 release once those final steps are completed.

The companion-package roadmap (`forestr.data`, `forestr.spatial`,
`forestr.growth`, `forestr.design`, `forestr.visuals`) preserves the
core's minimal-dependency principle while creating clear extension
points for spatial, Bayesian, and simulation workflows.
