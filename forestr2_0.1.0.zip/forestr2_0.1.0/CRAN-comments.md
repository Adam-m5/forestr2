# CRAN submission comments for forestr2 0.1.0.9000

## Test environments

- local R 4.6.1, x86_64-w64-mingw32 (Windows 11)
- (to be completed before submission: R-hub and WinBuilder results)

## R CMD check results

```
0 ERRORs | 0 WARNINGs | 1 NOTE
```

The NOTE is the standard "New submission" note that CRAN issues for all
first-time package submissions. There are no other NOTEs, WARNINGs, or
ERRORs.

(This is the expected result once the maintainer has run
`R CMD check --as-cran` locally. Please update this file with the actual
R-hub and WinBuilder output before submitting.)

## Submission context

This is a new submission. The package `forestr2` is not currently on CRAN.

## Description

`forestr2` is a modular, unit-aware R ecosystem for forest inventory,
silviculture, growth and yield, biodiversity, and experimental forestry.
It provides documented constructors and validators for tree, plot, stand,
and repeated-measurement data; inventory summaries and design-based
estimators with explicit expansion factors; volume, biomass, carbon,
density, stocking, and diversity metrics; accessible experimental-design
and treatment-comparison workflows, designed for forestry; and
individual-tree and stand-level growth and yield modeling.

## Design principles

1. **Units are never inferred.** Functions declare expected units
   (`dbh_cm`, `height_m`, `plot_area_ha`, ...) and validate that inputs
   are physically plausible.
2. **Estimators are documented.** Every plot/stand estimator reports the
   formula, expansion factor, standard-error convention, and units.
3. **Production equations are flagged for review.** Defaults carry a
   `TODO(scientific-review)` marker in source and emit
   `warn_review_placeholder()` on first use. The warning is a feature,
   not a bug: it prevents silent publication of unsuitable parameters.
4. **Minimal mandatory dependencies.** Core depends only on
   base-recommended packages (`stats`, `utils`, `methods`, `graphics`,
   `grDevices`). `tibble`, `ggplot2`, `dplyr`, `tidyr`, `nlme`, `lme4`,
   `emmeans`, and `multcomp` are *Suggests* and used opportunistically
   via `requireNamespace()`.
5. **Companion packages are first-class extension points.**
   `forestr2.spatial`, `forestr2.growth`, `forestr2.design`, and
   `forestr2.visuals` are reserved namespaces; the core package never
   imports from them.

## Scientific discipline

- **Carbon fraction is applied exactly once.** `calc_carbon_stock()` is
  the only function that multiplies biomass by `carbon_fraction`; the
  result is a `carbon_kg` column. Downstream `calc_co2e()` multiplies by
  `44/12`, not by `carbon_fraction` again. Tests assert the invariant.
- **CO2e conversion is opt-in.** No public function returns CO2e unless
  `calc_co2e()` is explicitly called.
- **Design-based SE** is reported at the plot/stand level, never conflated
  with tree-level SE.
- **Every default parameter** lacking peer-reviewed provenance emits a
  `forestr2_review_warning` on first use. See `?forestr2::forestr2_options`
  for how to suppress after validation.

## Reverse dependencies

This is a new submission; there are no reverse dependencies on CRAN.

## Package name

`forestr2` is not currently on CRAN nor on Bioconductor (verified at
submission time). The name is descriptive of the package's scope and
does not conflict with any past CRAN package in the Archive.

## License

MIT + file LICENSE. The LICENSE file contains:
```
YEAR: 2026
COPYRIGHT HOLDER: Adam Mugisha
```

## Authors

- Adam Mugisha (aut, cre) -- ORCID 0009-0005-5611-9056

All code in this package is original work by the author. No code was
copied or derived from other packages. Methodological credits are
recorded in `inst/CITATION` and in the `@references` sections of the
relevant man pages (Baskerville 1972; Reineke 1933; Chapman 1961;
Richards 1959; Von Bertalanffy 1938; IPCC 2006).

## Repository

The package source is publicly available at:
https://github.com/Adam-m5/forestr2

Bug reports and feature requests:
https://github.com/Adam-m5/forestr2/issues

## Examples

All examples run in less than 5 seconds on a standard laptop. Examples
requiring optional `Suggests` packages are wrapped in
`\dontrun{}` or gated by `if (requireNamespace("pkg"))`.

## Tests

The package includes `testthat` tests covering validation logic,
deterministic numeric results, and the carbon-once / CO2e-opt-in
invariants. Tests requiring optional packages use
`skip_if_not_installed()`.

## Vignette

The vignette `forestr-workflow.Rmd` covers a complete workflow from
data import through growth modeling and sensitivity analysis. It uses
`ggplot2` (a Suggests) for visualization; the vignette builder (`knitr`)
installs Suggests automatically during vignette rendering.
