# forestr2 0.1.0.9000 (development)

## Initial MVP

### Data model
- `tree_inventory()` constructor with validation, `is_/as_forestr2_inventory()`.
- `repeated_measurements()` and `growth_increments()`.
- `plot_summary()` and `stand_summary()` with `fixed_area` and `explicit`
  expansion modes.
- `forestr2_options()` and `forestr2_fields()`.

### Volume
- `calc_tree_volume()` with `form_factor`, `sectional`, `taper`, `equation`
  methods.
- `calc_stem_section_volume()` (Smalian, Huber, Newton).
- `calc_log_volume()` with cumulative + merchantable totals and bark/trim
  parameters.
- `calc_merchantable_volume()` with rule-based inclusion and status column.
- `calc_volume_by_plot()` and `calc_volume_by_stand()` with design-based
  SE and t-based CI.
- `fit_volume_model()` (lm/nls/nlme) and `predict_volume()` with
  log-response Baskerville bias correction.

### Biomass and carbon
- `calc_tree_biomass()` (`allometric`, `volume_density`, `equation`).
- `calc_component_biomass()` with reconciliation check.
- `calc_aboveground_biomass()`, `calc_belowground_biomass()`,
  `calc_total_biomass()`.
- `calc_carbon_stock()` (carbon fraction applied exactly once; range-checked
  to [0.30, 0.60]).
- `calc_co2e()` (opt-in; uses 44/12).
- `fit_biomass_model()` and `predict_biomass()`.
- `aggregate_biomass_plot()` with Mg/ha, C and CO2e.

### Growth and yield
- `growth_function_library()` (Chapman-Richards, Gompertz, logistic,
  von Bertalanffy, Schumacher, Hossfeld, Weibull, Richards alias).
- `fit_growth_model()` with k-fold CV.
- `predict_growth()` with optional CI.
- `site_index()` (anamorphic Chapman-Richards and Schumacher).
- `self_thinning()` (Reineke SDImax line).
- `mortality()` (constant-rate decay).
- `simulate_stand()` (deterministic; for sensitivity analysis).

### Experimental design
- `aov_forestr2()` (CRD, RCBD, factorial, split-plot, repeated-measures).
- `cld_forestr2()` with emmeans/multcomp fallback to TukeyHSD.

### Documentation and CI
- Comprehensive workflow vignette covering all 15 required sections.
- `.github/workflows/` for R-CMD-check, test-coverage, lint.
- `.lintr`, `styler.yaml`, `_pkgdown.yml`.
- `CONTRIBUTING.md` documenting the scientific-review-then-implement workflow.
- `inst/CITATION` for methodological credits.
- Specification documents under `docs/` (architecture, MVP roadmap, data
  standard, API specification, methodology, dependency analysis,
  limitations and governance).

### Known limitations
- All default parameters (form factor, BEF, root-to-shoot, carbon fraction,
  SDI maximum, growth function parameters) are scientific placeholders
  that emit `forestr2_review_warning` on first use.
- BAF point sampling is not yet implemented (calls `.NotYetImplemented()`).
- Stratified and unequal-probability designs are not yet supported in the
  core (use `expansion = "explicit"` with pre-computed weights).
- No redistributable datasets ship with the MVP (planned for `forestr2.data`).
