# Contributing to forestr2

Thank you for considering a contribution to `forestr2`. The project follows
a **scientific-review-then-implement** workflow to keep the codebase
scientifically defensible.

## Workflow

1. **Open an issue first** before opening a PR with significant science
   content (new equations, default parameters, estimators). Discuss the
   approach, parameter source, and target user.
2. **Mark placeholders.** Any equation or default parameter that lacks
   peer-reviewed provenance must carry a `TODO(scientific-review)` marker
   in source and emit `warn_review_placeholder()` on first use.
3. **Implement.** Match the existing code style (run `styler::style_pkg()`).
4. **Document.** Add roxygen2 docs with explicit `@param`, `@return`,
   `@export`, `@examples`, and a `@references` section when applicable.
5. **Test.** Add testthat tests in `tests/testthat/`. Aim for ≥90% coverage
   of new code.
6. **Check.** Run `devtools::check()` locally and fix all ERRORs, WARNINGs,
   and NOTEs.
7. **Lint.** Run `lintr::lint_package()` and `styler::style_pkg()`.
8. **Open the PR.** Reference the issue, describe the parameter source,
   and request a domain reviewer.

## Scientific review

A reviewer with forestry-domain expertise must approve before any
`TODO(scientific-review)` marker can be removed. Reviewers check:

- **Provenance**: peer-reviewed publication or regional manual citation.
- **Units**: explicit unit declarations; no silent inference.
- **Estimator transparency**: the formula is named, the SE convention is
  named (tree-level vs. design-based), and the parameter source is
  attached as an attribute on the result.
- **Limitations**: the function's docs name the conditions under which
  the equation is invalid (e.g. outside its calibration DBH range).

## Code style

- 2-space indent; line length ≤ 100.
- snake_case for functions and variables; PascalCase for S3 classes.
- One function per file is preferred; related helpers may share a file.
- Roxygen2 with markdown (`Roxygen: list(markdown = TRUE)` in DESCRIPTION).
- Every public function must have a runnable `@examples` block. Use
  `\dontrun{}` only when a CRAN-incompatible dependency is required.

## Test conventions

- File names: `test-<module>.R`.
- One `test_that()` per logical assertion cluster.
- Deterministic tests use literal expected values; never `set.seed()` in
  production tests unless the function under test documents a seed.
- For tests requiring optional packages, use `skip_if_not_installed()`.

## CI

All PRs run `R CMD check`, `lintr`, `styler` check, and test coverage.
Coverage below 90% on changed lines triggers a NOTE.

## Citing forestr2

Please cite the package version and the methodological sources for any
equation used. See `inst/CITATION`.
