---
name: Bug report
about: Report a bug in forestr2
title: "[BUG] "
labels: bug
assignees: Adam-m5
---

## Description

A clear and concise description of what the bug is.

## Reproducible example

```r
# Insert a minimal reproducible example here
library(forestr2)
# ...
```

## Expected behavior

What you expected to happen.

## Actual behavior

What actually happened (including error messages, warnings, unexpected output).

## Session information

```r
# Paste the output of sessionInfo() here
sessionInfo()
```

## Additional context

Add any other context about the problem here (e.g. OS, R version, relevant
package versions, parameter tables used).
