---
name: Feature request
about: Suggest a new feature for forestr2
title: "[FEATURE] "
labels: enhancement
assignees: Adam-m5
---

## Motivation

A clear and concise description of what problem this feature would solve.
Is your feature request related to a problem? Please describe.

## Proposed solution

A clear and concise description of what you want to happen.

## Alternatives considered

A clear and concise description of any alternative solutions or features
you've considered.

## Additional context

Add any other context or screenshots about the feature request here.

## Scientific references (if applicable)

If the feature implements a published method, please cite the source:
- Author, Year. Title. Journal, Volume(Issue), pages. DOI: ...

This helps us ensure scientific provenance is recorded in the
`@references` section of the relevant man page.
