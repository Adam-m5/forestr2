## Description

Briefly describe what this PR changes and why.

## Related issue

Fixes #<issue number>
Refers to #<issue number>

## Type of change

- [ ] Bug fix (non-breaking change which fixes an issue)
- [ ] New feature (non-breaking change which adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Documentation update
- [ ] Test improvement
- [ ] CI/build infrastructure

## Scientific review (for new equations or default parameters)

If this PR adds or changes a default parameter (form factor, BEF,
root-to-shoot ratio, carbon fraction, wood density, growth model
parameter, etc.):

- [ ] I have cited the peer-reviewed source in the `@references` section.
- [ ] I have updated `docs/05-methodology.md` Part C (parameter register).
- [ ] I have removed the `TODO(scientific-review)` marker from the
      parameter, OR documented why it must remain.
- [ ] I have updated or added tests asserting the new value.

## Checklist

- [ ] My code follows the style guidelines (run `styler::style_pkg()`)
- [ ] I have performed a self-review of my own code
- [ ] I have commented my code, particularly in hard-to-understand areas
- [ ] I have updated the documentation accordingly (run `roxygen2::roxygenize()`)
- [ ] My changes generate no new warnings or errors (`R CMD check`)
- [ ] I have added tests that prove my fix is effective or my feature works
- [ ] New and existing unit tests pass locally with my changes
- [ ] Any dependent changes have been merged and published in downstream modules

## Test output

```
# Paste the output of `devtools::test()` here
```
