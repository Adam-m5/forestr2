# ----------------------------------------------------------------------------
# forestr2: volume estimation
#
# All public functions:
#   - validate units (cm for dbh, m for height, m for length),
#   - convert DBH cm -> m *only after validation*,
#   - return m^3 per tree by default,
#   - preserve identifiers,
#   - attach method/units/parameter_source attributes,
#   - support explicit missing-value handling,
#   - emit scientific-review warnings for placeholder parameters.
# ----------------------------------------------------------------------------

# ---- calc_tree_volume -------------------------------------------------------

#' Tree-level volume
#'
#' Compute per-tree stem volume (m^3 per tree) using one of several methods.
#'
#' @param data optional data frame; when supplied, `dbh_cm`, `height_m`,
#'   `species`, and `tree_id` may be character scalars naming columns.
#' @param dbh_cm numeric vector, or column name. Required.
#' @param height_m numeric vector, or column name. Required for
#'   `method = "form_factor"` and `"taper"`.
#' @param method character; one of:
#'   - `"form_factor"` (default): V = basal_area * height * form_factor,
#'     where basal_area = pi*(dbh_m/2)^2.
#'   - `"sectional"`: sum of section volumes from a measured profile. Requires
#'     `section_diameters_cm` and `section_lengths_m`. Uses Smalian's formula
#'     by default (see [calc_stem_section_volume()]).
#'   - `"taper"`: numerical integration of a diameter or radius profile.
#'     Requires `taper_fn` (a function of relative height in [0,1] returning
#'     diameter outside bark in cm) or a named profile (`"kozak"` etc., TODO).
#'   - `"equation"`: user-supplied `equation` function or fitted model from
#'     [fit_volume_model()] (see [predict_volume()]).
#' @param form_factor numeric scalar or species-named vector. Default 0.45.
#'   **TODO(scientific-review)**: 0.45 is a generic placeholder; species- and
#'   region-specific values should be supplied.
#' @param merchantable_height_m optional numeric vector; when supplied for
#'   `method = "form_factor"` the volume is computed up to this height.
#' @param equation function or fitted model. For a function, the signature is
#'   `f(dbh_cm, height_m, ...)` and it must return a numeric vector.
#' @param species character vector (or column name) used to look up
#'   species-specific `form_factor` values when `form_factor` is a named vector.
#' @param tree_id optional identifier vector (or column name).
#' @param section_diameters_cm,section_lengths_m lists/numeric vectors for
#'   `method = "sectional"`. See [calc_stem_section_volume()].
#' @param taper_fn function for `method = "taper"`; signature `f(h_rel)` where
#'   `h_rel` in [0,1] returns diameter (cm) at that relative height.
#' @param n_integrate integer; number of subintervals for `method = "taper"`.
#'   Default 100.
#' @param missing character; one of `c("error","warn","return_na")`.
#' @param output character; one of `c("vector","data.frame")`.
#' @param ... passed to `equation` for `method = "equation"`.
#'
#' @return numeric vector (when `output = "vector"`) or data frame
#' (when `output = "data.frame"`) with columns `tree_id`, `volume_m3`,
#' `method`, and units in attributes. The data frame inherits from class
#' `forestr2_result`.
#'
#' @export
#' @examples
#' # Form-factor method
#' calc_tree_volume(dbh_cm = c(20, 25), height_m = c(15, 18),
#'                  method = "form_factor", form_factor = 0.45)
#'
#' # Species-specific form factors
#' calc_tree_volume(
#'   dbh_cm = c(20, 25), height_m = c(15, 18),
#'   species = c("Picea abies","Pinus sylvestris"),
#'   form_factor = c("Picea abies" = 0.46, "Pinus sylvestris" = 0.44),
#'   method = "form_factor"
#' )
#'
#' # Sectional method
#' calc_tree_volume(
#'   method = "sectional",
#'   section_diameters_cm = list(c(25, 20, 15), c(30, 25, 20, 15)),
#'   section_lengths_m    = list(c(5, 5),       c(4, 4, 4)),
#'   tree_id = c("T1","T2")
#' )
calc_tree_volume <- function(data = NULL,
                             dbh_cm = NULL,
                             height_m = NULL,
                             method = c("form_factor","sectional","taper","equation"),
                             form_factor = 0.45,
                             merchantable_height_m = NULL,
                             equation = NULL,
                             species = NULL,
                             tree_id = NULL,
                             section_diameters_cm = NULL,
                             section_lengths_m = NULL,
                             taper_fn = NULL,
                             n_integrate = 100L,
                             missing = c("error","warn","return_na"),
                             output = c("vector","data.frame"),
                             ...) {
  method <- match.arg(method)
  missing <- resolve_missing_policy(missing)
  output <- match.arg(output)

  dbh <- resolve_vec(dbh_cm, data, "dbh_cm")
  hgt <- resolve_vec(height_m, data, "height_m")
  sp  <- resolve_vec(species, data, "species")
  tid <- resolve_vec(tree_id, data, "tree_id")
  mh  <- resolve_vec(merchantable_height_m, data, "merchantable_height_m")

  n <- if (!is.null(dbh)) length(dbh)
       else if (!is.null(hgt)) length(hgt)
       else if (!is.null(tid)) length(tid)
       else if (method == "sectional" && is.list(section_diameters_cm)) length(section_diameters_cm)
       else if (!is.null(data)) nrow(data)
       else 1L

  if (is.null(tid)) tid <- seq_len(n)

  # Resolve form factor
  ff_lookup <- normalize_coef_table(form_factor, key_col = "species")
  if (ff_lookup$type != "NULL" && !is.null(sp)) {
    ff <- lookup_species_value(sp, ff_lookup, value_col = "form_factor",
                               default = NA_real_)
  } else if (ff_lookup$type == "named" && is.null(sp)) {
    # form_factor is named but no species given -> use the first value as scalar
    ff <- rep(unname(form_factor[1L]), n)
  } else {
    ff <- rep(as.numeric(form_factor), n)
  }
  ff[is.na(ff)] <- if (is.numeric(form_factor) && length(form_factor) == 1L) form_factor else 0.45
  warn_review_placeholder("form_factor", ff[1L],
                          "default 0.45 (forestr2 placeholder; species-specific values required)")

  # Validate dbh and height where required
  if (method %in% c("form_factor","taper")) {
    if (is.null(dbh)) stop("`dbh_cm` is required for method '", method, "'.",
                          call. = FALSE)
    dbh <- as_finite_numeric(dbh, "dbh_cm", allow_zero = FALSE)
    dbh <- match_length(dbh, n, "dbh_cm")
  }
  if (method %in% c("form_factor","taper") ||
      (!is.null(hgt) && method != "sectional")) {
    if (is.null(hgt) && method %in% c("form_factor","taper")) {
      stop("`height_m` is required for method '", method, "'.", call. = FALSE)
    }
    if (!is.null(hgt)) {
      hgt <- as_finite_numeric(hgt, "height_m", allow_zero = FALSE)
      hgt <- match_length(hgt, n, "height_m")
    }
  }
  if (!is.null(mh)) {
    mh <- as_finite_numeric(mh, "merchantable_height_m", allow_zero = FALSE)
    mh <- match_length(mh, n, "merchantable_height_m")
  }

  # Compute volume
  vol <- switch(method,
    form_factor = {
      h_use <- if (!is.null(mh)) mh else hgt
      bad <- is.na(dbh) | is.na(h_use) | is.na(ff) | dbh <= 0 | h_use <= 0
      v <- rep(NA_real_, n)
      dbh_m <- dbh / 100
      ba <- pi * (dbh_m / 2)^2
      v[!bad] <- ba[!bad] * h_use[!bad] * ff[!bad]
      v
    },
    sectional = {
      if (is.null(section_diameters_cm) || is.null(section_lengths_m)) {
        stop("method='sectional' requires `section_diameters_cm` and `section_lengths_m`.",
             call. = FALSE)
      }
      if (!is.list(section_diameters_cm)) {
        # single tree: wrap in list
        section_diameters_cm <- list(section_diameters_cm)
        section_lengths_m    <- list(section_lengths_m)
      }
      n <- length(section_diameters_cm)
      v <- vapply(seq_len(n), function(i) {
        d <- section_diameters_cm[[i]]; L <- section_lengths_m[[i]]
        if (is.null(d) || is.null(L) || length(d) == 0L) return(NA_real_)
        sum(calc_stem_section_volume(top_diameter_cm = d[-length(d)],
                                     mid_diameter_cm = NA_real_,
                                     bot_diameter_cm = d,
                                     length_m = L,
                                     method = "smalian",
                                     missing = "return_na", output = "vector"))
      }, numeric(1L))
      v
    },
    taper = {
      if (is.null(taper_fn)) stop("`taper_fn` is required for method='taper'.",
                                  call. = FALSE)
      if (!is.function(taper_fn)) stop("`taper_fn` must be a function.",
                                       call. = FALSE)
      v <- vapply(seq_len(n), function(i) {
        if (is.na(dbh[i]) || is.na(hgt[i]) || dbh[i] <= 0 || hgt[i] <= 0) return(NA_real_)
        # trapezoidal integration of cross-sectional area
        hs <- seq(0, 1, length.out = n_integrate + 1L)
        ds <- vapply(hs, function(hr) taper_fn(hr), numeric(1L))
        ds[ds < 0] <- 0
        ds_m <- ds / 100
        as_  <- pi * (ds_m / 2)^2
        h_m  <- hgt[i] * hs
        # trapezoidal
        sum(diff(h_m) * (head(as_, -1) + tail(as_, -1)) / 2)
      }, numeric(1L))
      v
    },
    equation = {
      if (is.null(equation)) stop("`equation` is required for method='equation'.",
                                  call. = FALSE)
      if (is.function(equation)) {
        v <- tryCatch(equation(dbh_cm = dbh, height_m = hgt, ...),
                      error = function(e) {
                        stop("user `equation` failed: ", conditionMessage(e),
                             call. = FALSE)
                      })
        if (length(v) != n) stop("user `equation` returned wrong length.",
                                call. = FALSE)
        v
      } else if (inherits(equation, "forestr2_volume_model")) {
        v <- predict_volume(equation, dbh_cm = dbh, height_m = hgt,
                            species = sp, ...)$volume_m3
        v
      } else {
        stop("`equation` must be a function or a forestr2_volume_model.",
             call. = FALSE)
      }
    }
  )

  # Missing policy
  if (anyNA(vol)) {
    mask <- is.na(vol)
    msg <- paste0("calc_tree_volume: ", sum(mask),
                  " of ", n, " volumes are NA.")
    if (missing == "error") stop(msg, call. = FALSE)
    if (missing == "warn")  warning(msg, call. = FALSE)
  }

  if (output == "vector") return(vol)

  df <- data.frame(tree_id = tid, volume_m3 = vol,
                   method = method, stringsAsFactors = FALSE)
  attr(df, "units") <- "m3 per tree"
  attr(df, "parameter_source") <- paste0("form_factor=", ff[1L],
                                         "; forestr2 placeholder (review)")
  class(df) <- c("forestr2_result", class(df))
  df
}

# ---- calc_stem_section_volume ----------------------------------------------

#' Stem section volume
#'
#' Implements Smalian, Huber, and Newton formulas for log sections.
#'
#' @param top_diameter_cm numeric vector; top diameter (under or over bark;
#'   the user is responsible for consistency).
#' @param bot_diameter_cm numeric vector; bottom (large-end) diameter.
#' @param mid_diameter_cm numeric vector; midpoint diameter. Required for
#'   Huber and Newton; ignored for Smalian.
#' @param length_m numeric vector; section length in meters.
#' @param method character; one of `c("smalian","huber","newton")`.
#' @param missing,output as in [calc_tree_volume()].
#' @param tree_id optional identifier vector.
#' @return numeric vector or data frame.
#' @export
#' @examples
#' calc_stem_section_volume(top_diameter_cm = 20, bot_diameter_cm = 25,
#'                          mid_diameter_cm = 22.5, length_m = 4,
#'                          method = "newton")
calc_stem_section_volume <- function(top_diameter_cm = NULL,
                                     bot_diameter_cm = NULL,
                                     mid_diameter_cm = NULL,
                                     length_m = NULL,
                                     method = c("smalian","huber","newton"),
                                     missing = c("error","warn","return_na"),
                                     output = c("vector","data.frame"),
                                     tree_id = NULL) {
  method <- match.arg(method)
  missing <- resolve_missing_policy(missing)
  output <- match.arg(output)

  top <- as_finite_numeric(top_diameter_cm, "top_diameter_cm", allow_zero = TRUE)
  bot <- as_finite_numeric(bot_diameter_cm, "bot_diameter_cm", allow_zero = TRUE)
  L   <- as_finite_numeric(length_m, "length_m", allow_zero = FALSE)
  n <- max(length(top), length(bot), length(L))
  top <- match_length(top, n, "top_diameter_cm")
  bot <- match_length(bot, n, "bot_diameter_cm")
  L   <- match_length(L,   n, "length_m")
  mid <- if (method != "smalian") {
    if (is.null(mid_diameter_cm)) stop("`mid_diameter_cm` is required for method='", method, "'.", call. = FALSE)
    mid <- as_finite_numeric(mid_diameter_cm, "mid_diameter_cm", allow_zero = TRUE)
    match_length(mid, n, "mid_diameter_cm")
  } else rep(NA_real_, n)

  area_cm2 <- function(d) pi * (d / 2)^2  # cross-sectional area in cm^2
  A1 <- area_cm2(top); A2 <- area_cm2(bot); Am <- area_cm2(mid)
  # Convert cm^2 * m -> m^3: divide cm^2 by 1e4
  conv <- 1e-4

  vol <- switch(method,
    smalian = conv * L * (A1 + A2) / 2,
    huber   = conv * L * Am,
    newton  = conv * L * (A1 + 4*Am + A2) / 6
  )

  if (anyNA(vol)) {
    mask <- is.na(vol)
    msg <- paste0("calc_stem_section_volume: ", sum(mask),
                  " of ", n, " volumes are NA.")
    if (missing == "error") stop(msg, call. = FALSE)
    if (missing == "warn")  warning(msg, call. = FALSE)
  }

  if (output == "vector") return(vol)
  tid <- if (!is.null(tree_id)) match_length(tree_id, n, "tree_id") else seq_len(n)
  df <- data.frame(tree_id = tid, section_volume_m3 = vol,
                   method = method, stringsAsFactors = FALSE)
  attr(df, "units") <- "m3 per section"
  attr(df, "parameter_source") <- "geometric formula"
  class(df) <- c("forestr2_result", class(df))
  df
}

# ---- calc_log_volume --------------------------------------------------------

#' Log volume from bucking records
#'
#' @param data optional data frame with log records.
#' @param tree_id,log_number,length_m,butt_diameter_cm,top_diameter_cm,mid_diameter_cm,bark_status
#'   column names or vectors.
#' @param method character; default `"smalian"` (Huber and Newton supported).
#' @param trim_allowance_m optional numeric; trim allowance added to each log's
#'   nominal length for tallying purposes (does NOT alter computed volume).
#' @param bark_deduction_cm optional numeric; per-log deduction applied uniformly
#'   to both diameters before computing volume. Default 0 (no deduction).
#' @param include_cumulative logical; if TRUE, add `cumulative_volume_m3`.
#' @param include_merchantable logical; if TRUE, add `merchantable_total_m3`
#'   as an attribute.
#' @inheritParams calc_tree_volume
#' @return data frame (class `forestr2_result`) of log-level volumes plus
#'   per-tree cumulative volume.
#' @export
#' @examples
#' calc_log_volume(
#'   tree_id = c("T1","T1","T1"),
#'   log_number = 1:3,
#'   length_m = c(4, 4, 4),
#'   butt_diameter_cm = c(30, 25, 20),
#'   top_diameter_cm  = c(25, 20, 15)
#' )
calc_log_volume <- function(data = NULL,
                            tree_id = NULL, log_number = NULL,
                            length_m = NULL,
                            butt_diameter_cm = NULL,
                            top_diameter_cm = NULL,
                            mid_diameter_cm = NULL,
                            bark_status = "ob",
                            method = c("smalian","huber","newton"),
                            trim_allowance_m = 0,
                            bark_deduction_cm = 0,
                            missing = c("error","warn","return_na"),
                            output = c("data.frame","vector"),
                            include_cumulative = TRUE,
                            include_merchantable = TRUE) {
  method <- match.arg(method)
  missing <- resolve_missing_policy(missing)
  output <- match.arg(output)

  tid <- resolve_vec(tree_id, data, "tree_id")
  ln  <- resolve_vec(log_number, data, "log_number")
  L   <- resolve_vec(length_m, data, "length_m")
  b   <- resolve_vec(butt_diameter_cm, data, "butt_diameter_cm")
  t   <- resolve_vec(top_diameter_cm, data, "top_diameter_cm")
  m_  <- resolve_vec(mid_diameter_cm, data, "mid_diameter_cm")
  bs  <- resolve_vec(bark_status, data, "bark_status")

  n <- max(length(tid), length(ln), length(L), length(b), length(t))
  if (n == 0L) stop("calc_log_volume: no inputs.", call. = FALSE)
  tid <- match_length(tid, n, "tree_id")
  ln  <- match_length(ln, n, "log_number")
  L   <- match_length(L, n, "length_m")
  b   <- match_length(b, n, "butt_diameter_cm")
  t   <- match_length(t, n, "top_diameter_cm")
  bs  <- match_length(bs, n, "bark_status")
  # Bark deduction
  b <- b - bark_deduction_cm
  t <- t - bark_deduction_cm
  b[b < 0] <- 0
  t[t < 0] <- 0

  vol <- calc_stem_section_volume(top_diameter_cm = t, bot_diameter_cm = b,
                                  mid_diameter_cm = m_, length_m = L,
                                  method = method, missing = "return_na",
                                  output = "vector")
  df <- data.frame(tree_id = tid, log_number = ln,
                   length_m = L,
                   butt_diameter_cm = b + bark_deduction_cm,
                   top_diameter_cm  = t + bark_deduction_cm,
                   bark_status = bs,
                   log_volume_m3 = vol,
                   trim_allowance_m = trim_allowance_m,
                   stringsAsFactors = FALSE)
  if (include_cumulative) {
    ord <- order(df$tree_id, df$log_number)
    df_ord <- df[ord, , drop = FALSE]
    df_ord$cumulative_volume_m3 <- ave(df_ord$log_volume_m3, df_ord$tree_id,
                                       FUN = function(x) cumsum(x))
    df <- df_ord[order(match(paste(df_ord$tree_id, df_ord$log_number),
                             paste(df$tree_id, df$log_number))), ]
  }
  if (include_merchantable) {
    attr(df, "merchantable_total_m3") <-
      tapply(df$log_volume_m3, df$tree_id, sum, na.rm = TRUE)
  }
  attr(df, "method") <- paste0("log_", method)
  attr(df, "units")  <- "m3 per log"
  attr(df, "parameter_source") <- "geometric formula"
  class(df) <- c("forestr2_result", class(df))
  if (output == "vector") return(df$log_volume_m3)
  df
}

# ---- calc_merchantable_volume -----------------------------------------------

#' Merchantable volume
#'
#' Filters sections / logs by merchantability rules and returns the surviving
#' volume plus a status column explaining inclusion/exclusion.
#'
#' @param data optional data frame.
#' @param tree_id,length_m,top_diameter_cm,butt_diameter_cm,column names or vectors.
#' @param min_top_diameter_cm numeric scalar; default 7 (small-end utilization).
#'   **TODO(scientific-review)**: utilization standards vary by region.
#' @param min_merchantable_length_m numeric scalar; default 2.0.
#' @param max_defect_pct numeric scalar in [0,1]; default 0 (no defect allowance).
#' @param min_stump_height_m numeric scalar; default 0.3.
#' @param species_rules optional data frame with columns `species`, `min_top_diameter_cm`,
#'   `min_merchantable_length_m` overriding the defaults per species.
#' @param species character vector (or column name).
#' @param product_class optional character vector; if supplied, logs are
#'   annotated with their `product_class` (e.g. `"sawlog"`,`"pulp"`,`"biomass"`).
#' @param bark_status character vector `"ob"`/`"ub"`; default `"ob"`.
#' @return data frame with one row per section/log and an `included` logical
#'   and `status_reason` character column. Total merchantable volume per tree
#'   is attached as attribute `merchantable_total_m3`.
#' @export
#' @examples
#' calc_merchantable_volume(
#'   tree_id = c("T1","T1","T1"),
#'   length_m = c(4, 4, 4),
#'   butt_diameter_cm = c(35, 25, 18),
#'   top_diameter_cm  = c(25, 18, 10),
#'   species = c("Pinus","Pinus","Pinus")
#' )
calc_merchantable_volume <- function(data = NULL,
                                     tree_id = NULL,
                                     length_m = NULL,
                                     butt_diameter_cm = NULL,
                                     top_diameter_cm = NULL,
                                     min_top_diameter_cm = 7,
                                     min_merchantable_length_m = 2.0,
                                     max_defect_pct = 0,
                                     min_stump_height_m = 0.3,
                                     species_rules = NULL,
                                     species = NULL,
                                     product_class = NULL,
                                     bark_status = "ob") {
  tid <- resolve_vec(tree_id, data, "tree_id")
  L   <- resolve_vec(length_m, data, "length_m")
  b   <- resolve_vec(butt_diameter_cm, data, "butt_diameter_cm")
  t   <- resolve_vec(top_diameter_cm, data, "top_diameter_cm")
  sp  <- resolve_vec(species, data, "species")
  pc  <- resolve_vec(product_class, data, "product_class")

  n <- max(length(tid), length(L), length(b), length(t))
  if (n == 0L) stop("calc_merchantable_volume: no inputs.", call. = FALSE)
  tid <- match_length(tid, n, "tree_id")
  L   <- match_length(L, n, "length_m")
  b   <- match_length(b, n, "butt_diameter_cm")
  t   <- match_length(t, n, "top_diameter_cm")

  # Per-species rules
  mtd <- if (!is.null(species_rules) && !is.null(sp)) {
    rules_lookup <- normalize_coef_table(species_rules, key_col = "species")
    lookup_species_value(sp, rules_lookup, value_col = "min_top_diameter_cm",
                         default = min_top_diameter_cm)
  } else rep(min_top_diameter_cm, n)

  # Inclusion test
  incl <- !is.na(t) & !is.na(L) & t >= min_top_diameter_cm & L >= min_merchantable_length_m
  reason <- rep(NA_character_, n)
  reason[!incl & (is.na(t) | t < min_top_diameter_cm)] <-
    sprintf("top_diameter_cm %s < min_top_diameter_cm %s",
            format_sig(t[!incl & (is.na(t) | t < min_top_diameter_cm)]),
            min_top_diameter_cm)
  reason[!incl & !is.na(t) & t >= min_top_diameter_cm & L < min_merchantable_length_m] <-
    sprintf("length_m %s < min_merchantable_length_m %s",
            format_sig(L[!incl & !is.na(t) & t >= min_top_diameter_cm & L < min_merchantable_length_m]),
            min_merchantable_length_m)
  reason[incl] <- "included"

  vol <- calc_stem_section_volume(top_diameter_cm = t, bot_diameter_cm = b,
                                  mid_diameter_cm = rep(NA_real_, n),
                                  length_m = L, method = "smalian",
                                  missing = "return_na", output = "vector")
  vol[!incl] <- 0

  df <- data.frame(
    tree_id           = tid,
    species           = sp,
    length_m          = L,
    butt_diameter_cm  = b,
    top_diameter_cm   = t,
    bark_status       = bark_status,
    volume_m3         = vol,
    included          = incl,
    status_reason     = reason,
    min_top_diameter_cm = mtd,
    min_merchantable_length_m = min_merchantable_length_m,
    stringsAsFactors = FALSE
  )
  if (!is.null(pc)) df$product_class <- pc

  attr(df, "merchantable_total_m3") <-
    tapply(df$volume_m3, df$tree_id, sum, na.rm = TRUE)
  attr(df, "method") <- "merchantable (Smalian + utilization rules)"
  attr(df, "units")  <- "m3 per log/section"
  attr(df, "parameter_source") <- paste0(
    "min_top_diameter_cm=", min_top_diameter_cm,
    "; min_merchantable_length_m=", min_merchantable_length_m,
    "; forestr2 placeholder (review regional utilization standards)")
  warn_review_placeholder("min_top_diameter_cm", min_top_diameter_cm,
                          "forestr2 placeholder (regional review required)")
  class(df) <- c("forestr2_result", class(df))
  df
}

# ---- calc_volume_by_plot / by_stand -----------------------------------------

#' Aggregate volume to plot level
#'
#' @param inv a `forestr2_inventory` object with `volume_m3` populated (e.g.
#'   via [calc_tree_volume()]).
#' @param expansion one of `c("fixed_area","explicit","basal_area_factor")`.
#' @param level one of `c("plot","stand")`.
#' @param conf_level numeric; default 0.95.
#' @return data frame with `volume_m3_ha`, `se`, `lower`, `upper`, `n_trees`,
#'   `n_plots`, `estimator`, `units`.
#' @details The default standard error is the **design-based** SE of the
#'   plot-level per-hectare estimates. Tree-level SE is *not* reported because
#'   it conflates within-plot variance with sampling variance; see
#'   "Estimators" in the vignette.
#' @export
#' @examples
#' inv <- tree_inventory(
#'   tree_id = c("T1","T2","T3"),
#'   plot_id = c("P1","P1","P2"),
#'   species = "Picea abies",
#'   dbh_cm  = c(20, 22, 24),
#'   height_m= c(15, 16, 18),
#'   plot_area_ha = c(0.05, 0.05, 0.05)
#' )
#' inv$volume_m3 <- calc_tree_volume(inv, method = "form_factor")
#' calc_volume_by_plot(inv)
calc_volume_by_plot <- function(inv,
                                expansion = c("fixed_area","explicit","basal_area_factor"),
                                level = c("plot","stand"),
                                conf_level = 0.95) {
  if (!is_forestr2_inventory(inv)) {
    stop("`inv` must be a forestr2_inventory.", call. = FALSE)
  }
  expansion <- match.arg(expansion)
  level <- match.arg(level)
  if (is.null(inv$volume_m3) || all(is.na(inv$volume_m3))) {
    stop("`inv$volume_m3` must be populated; call calc_tree_volume() first.",
         call. = FALSE)
  }
  ef <- switch(expansion,
               fixed_area = 1 / inv$plot_area_ha,
               explicit   = inv$expansion_factor,
               basal_area_factor = stop("basal_area_factor not implemented."))
  tree_vol_ha <- inv$volume_m3 * ef

  grp <- if (level == "plot") inv$plot_id else inv$stand_id
  plot_vols <- tapply(tree_vol_ha, grp, sum, na.rm = TRUE)
  n_plots <- length(plot_vols)
  if (n_plots < 2L) {
    se <- NA_real_; lower <- NA_real_; upper <- NA_real_
  } else {
    se <- stats::sd(plot_vols) / sqrt(n_plots)
    tcrit <- stats::qt((1 + conf_level) / 2, df = n_plots - 1)
    lower <- mean(plot_vols) - tcrit * se
    upper <- mean(plot_vols) + tcrit * se
  }
  out <- data.frame(
    level            = level,
    volume_m3_ha     = mean(plot_vols),
    se               = se,
    lower            = lower,
    upper            = upper,
    n_trees          = nrow(inv),
    n_plots          = n_plots,
    estimator        = "design-based mean of plot-level per-ha volumes",
    units            = "m3/ha",
    stringsAsFactors = FALSE
  )
  attr(out, "method") <- paste0("calc_volume_by_plot(expansion=", expansion,
                                ", level=", level, ")")
  attr(out, "parameter_source") <- "calculated"
  class(out) <- c("forestr2_result", class(out))
  out
}

#' @describeIn calc_volume_by_plot Aggregate to stand level
#' @export
calc_volume_by_stand <- function(inv,
                                 expansion = c("fixed_area","explicit","basal_area_factor"),
                                 conf_level = 0.95) {
  calc_volume_by_plot(inv, expansion = expansion, level = "stand",
                      conf_level = conf_level)
}

# ---- fit_volume_model + predict_volume --------------------------------------

#' Fit a volume equation
#'
#' Fits a linear or nonlinear volume equation. For linear fits, uses
#' [stats::lm()]; for nonlinear, uses [stats::nls()]. Supports weighting,
#' species-group fitting, optional mixed effects (via `nlme`, when installed),
#' and k-fold cross-validation.
#'
#' @param data data frame containing the response and predictors.
#' @param formula a formula. Supported templates include:
#'   - `volume_m3 ~ dbh_cm^2 * height_m` (linearized as
#'     `volume_m3 ~ I(dbh_cm^2 * height_m)`); constant-form-factor model.
#'   - `volume_m3 ~ dbh_cm + I(dbh_cm^2) + height_m` (combined-variable).
#'   - Self-starting nonlinear forms are supported via `nls()` when a
#'     `start` argument is supplied.
#' @param start optional named list of starting values for `nls()`.
#' @param weights optional numeric vector of case weights.
#' @param species optional character vector; if supplied, model is fit
#'   separately per species group and the result is a list.
#' @param random optional formula for random effects; requires `nlme` to be
#'   installed. e.g. `~ 1 | plot_id`.
#' @param cv integer; number of folds for cross-validation. Default 0 (off).
#' @param log_response logical; if TRUE, fit on log(response). A bias-correction
#'   factor (Baskerville 1972) is computed and reported.
#'
#' @return An object of class `forestr2_volume_model` (a list) containing:
#'   - `fit` the underlying lm/nls/nlme object.
#'   - `formula`, `species`, `log_response`, `bias_correction`.
#'   - `metrics` (RMSE, MAE, bias, R2, AIC where defined).
#'   - `cv_metrics` (when `cv > 0`).
#'   - `parameter_source`.
#' @references
#' Baskerville, G. L. (1972). Use of logarithmic regression in the estimation
#' of plant biomass. *Canadian Journal of Forestry Research*, 2(1), 49-53.
#' \doi{10.1139/x72-009}
#'
#' Snowdon, P. (1991). A ratio estimator for bias correction in logarithmic
#' regressions. *Canadian Journal of Forest Research*, 21(5), 720-724.
#' \doi{10.1139/x91-101}
#' @export
#' @examples
#' \dontrun{
#' d <- data.frame(
#'   volume_m3 = c(0.2, 0.3, 0.5, 0.6, 0.8, 1.0),
#'   dbh_cm    = c(15, 18, 22, 25, 28, 30),
#'   height_m  = c(12, 14, 16, 18, 20, 22),
#'   species   = rep("Pinus", 6)
#' )
#' m <- fit_volume_model(d, volume_m3 ~ I(dbh_cm^2 * height_m))
#' predict_volume(m, dbh_cm = 25, height_m = 18)
#' }
fit_volume_model <- function(data, formula, start = NULL, weights = NULL,
                             species = NULL, random = NULL, cv = 0L,
                             log_response = FALSE) {
  if (!is.data.frame(data)) stop("`data` must be a data.frame.", call. = FALSE)
  if (!inherits(formula, "formula")) stop("`formula` must be a formula.",
                                          call. = FALSE)

  fit_one <- function(d) {
    if (nrow(d) < 3L) stop("Need >=3 rows to fit a volume model.", call. = FALSE)
    f <- formula
    if (log_response) {
      resp <- all.vars(f)[1L]
      f <- update(f, as.formula(paste("log(", resp, ") ~ .")))
    }
    if (!is.null(random)) {
      if (!requireNamespace("nlme", quietly = TRUE)) {
        stop("Random effects require the 'nlme' package to be installed.",
             call. = FALSE)
      }
      fit <- nlme::nlme(f, data = d, random = random, start = start)
    } else if (!is.null(start)) {
      fit <- stats::nls(f, data = d, start = start, weights = weights)
    } else {
      fit <- stats::lm(f, data = d, weights = weights)
    }

    preds <- as.numeric(stats::predict(fit))
    if (log_response) {
      # Baskerville 1972 bias correction
      resid <- log(d[[all.vars(formula)[1L]]]) - log(preds)
      cf <- exp(stats::var(resid, na.rm = TRUE) / 2)
      preds <- exp(preds) * cf
    }
    obs <- d[[all.vars(formula)[1L]]]
    resid <- obs - preds
    mse <- mean(resid^2, na.rm = TRUE)
    metrics <- list(
      rmse = sqrt(mse),
      mae  = mean(abs(resid),  na.rm = TRUE),
      bias = mean(resid,       na.rm = TRUE),
      r2   = if (!log_response && !is.null(start)) NA_real_
             else 1 - sum(resid^2, na.rm = TRUE) /
                       sum((obs - mean(obs, na.rm = TRUE))^2, na.rm = TRUE),
      aic  = tryCatch(stats::AIC(fit), error = function(e) NA_real_),
      n    = nrow(d)
    )

    cv_metrics <- NULL
    if (cv >= 2L) {
      folds <- sample(rep(seq_len(cv), length.out = nrow(d)))
      preds_cv <- rep(NA_real_, nrow(d))
      for (k in seq_len(cv)) {
        train <- folds != k; test <- folds == k
        if (sum(train) < 2L || sum(test) == 0L) next
        fit_k <- tryCatch(
          if (!is.null(start)) stats::nls(f, data = d[train, ], start = start)
          else stats::lm(f, data = d[train, ]),
          error = function(e) NULL
        )
        if (is.null(fit_k)) next
        p <- as.numeric(stats::predict(fit_k, newdata = d[test, ]))
        if (log_response) p <- exp(p)
        preds_cv[test] <- p
      }
      r_cv <- d[[all.vars(formula)[1L]]] - preds_cv
      cv_metrics <- list(
        rmse = sqrt(mean(r_cv^2, na.rm = TRUE)),
        mae  = mean(abs(r_cv), na.rm = TRUE),
        bias = mean(r_cv, na.rm = TRUE)
      )
    }

    structure(
      list(
        fit              = fit,
        formula          = formula,
        log_response     = log_response,
        bias_correction  = if (log_response) cf else 1,
        metrics          = metrics,
        cv_metrics       = cv_metrics,
        parameter_source = "user-supplied formula"
      ),
      class = "forestr2_volume_model"
    )
  }

  if (!is.null(species)) {
    if (is.character(species) && length(species) == 1L && species %in% names(data)) {
      species <- data[[species]]
    }
    out <- by(data, factor(species), fit_one)
    return(structure(as.list(out), class = "forestr2_volume_model_list",
                     species = levels(factor(species))))
  }
  fit_one(data)
}

#' Predict from a fitted volume model
#'
#' @param object a `forestr2_volume_model` or `forestr2_volume_model_list`.
#' @param newdata optional data frame; if NULL, fitted values are returned.
#' @param dbh_cm,height_m,species optional vectors for prediction when
#'   `newdata` is NULL.
#' @param interval character; one of `c("none","confidence","prediction")`.
#' @param level numeric; default 0.95.
#' @param ... passed to `predict()`.
#' @return data frame with `volume_m3` (and `lower`,`upper` when intervals
#'   requested).
#' @export
predict_volume <- function(object, newdata = NULL, dbh_cm = NULL,
                           height_m = NULL, species = NULL,
                           interval = c("none","confidence","prediction"),
                           level = 0.95, ...) {
  interval <- match.arg(interval)
  if (inherits(object, "forestr2_volume_model_list")) {
    if (is.null(species)) stop("`species` is required to predict from a per-species model list.", call. = FALSE)
    out <- do.call(rbind, lapply(seq_along(object), function(i) {
      m <- object[[i]]
      sp <- attr(object, "species")[i]
      sel <- species == sp
      if (!any(sel)) return(NULL)
      pred <- predict_volume(m, newdata = newdata, dbh_cm = dbh_cm[sel],
                             height_m = height_m[sel],
                             interval = interval, level = level, ...)
      pred$species <- sp
      pred
    }))
    return(out)
  }
  if (!inherits(object, "forestr2_volume_model")) {
    stop("`object` must be a forestr2_volume_model.", call. = FALSE)
  }
  if (is.null(newdata) && (!is.null(dbh_cm) || !is.null(height_m))) {
    newdata <- data.frame(dbh_cm = dbh_cm, height_m = height_m)
  }
  if (is.null(newdata)) {
    preds <- as.numeric(stats::predict(object$fit))
    se    <- tryCatch(as.numeric(stats::predict(object$fit,
                                                se.fit = TRUE)$se.fit),
                      error = function(e) NA_real_)
  } else {
    p <- tryCatch(stats::predict(object$fit, newdata = newdata,
                                 se.fit = TRUE, ...),
                  error = function(e) list(fit = stats::predict(object$fit,
                                                                newdata = newdata),
                                            se.fit = NA_real_))
    preds <- as.numeric(p$fit)
    se    <- as.numeric(p$se.fit)
    if (length(se) == 1L && is.na(se)) se <- rep(NA_real_, length(preds))
  }
  if (isTRUE(object$log_response)) {
    preds <- exp(preds) * object$bias_correction
    se    <- se * preds  # rough delta-method
  }
  out <- data.frame(volume_m3 = preds)
  if (interval != "none") {
    tcrit <- stats::qt((1 + level) / 2, df = object$metrics$n - 1)
    out$lower <- out$volume_m3 - tcrit * se
    out$upper <- out$volume_m3 + tcrit * se
  }
  out
}

#' @describeIn predict_volume Print method for `forestr2_volume_model`
#' @param x an object of class `forestr2_volume_model`.
#' @export
print.forestr2_volume_model <- function(x, ...) {
  cat("<forestr2_volume_model>\n")
  cat("formula:", deparse(x$formula), "\n")
  if (isTRUE(x$log_response)) {
    cat("log-response: TRUE (Baskerville bias correction factor =",
        format(x$bias_correction, digits = 4), ")\n")
  }
  cat("metrics:\n"); print(x$metrics)
  if (!is.null(x$cv_metrics)) {
    cat("cross-validation metrics:\n"); print(x$cv_metrics)
  }
  invisible(x)
}
