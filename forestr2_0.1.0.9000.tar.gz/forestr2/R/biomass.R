# ----------------------------------------------------------------------------
# forestr2: biomass and carbon
#
# Key invariants enforced by this module:
#   - carbon fraction is NEVER applied twice;
#   - wood density and volume units MUST be compatible (kg/m^3 and m^3);
#   - default carbon_fraction = 0.47 is a documented parameter, NOT a constant;
#   - CO2e conversion is opt-in via calc_co2e(), using 44/12;
#   - belowground biomass, when estimated from root-to-shoot ratios, is
#     labelled as an assumption with explicit source attribution;
#   - component totals reconcile to total biomass within tolerance.
# ----------------------------------------------------------------------------

# ---- calc_tree_biomass ------------------------------------------------------

#' Tree-level biomass
#'
#' @param data optional data frame.
#' @param dbh_cm,height_m,species,tree_id as in [calc_tree_volume()].
#' @param method one of `c("allometric","volume_density","equation")`.
#'   - `"allometric"`: uses a species-specific allometric equation.
#'     `coefficients` must be a named numeric vector or data frame; the form
#'     is controlled by `equation_form`. Default form is
#'     `biomass_kg = a * dbh_cm^b` (power law).
#'   - `"volume_density"`: computes stem volume via [calc_tree_volume()] and
#'     multiplies by `wood_density_kg_m3`. Component allocation is performed
#'     by `biomass_expansion_factor` (BEF).
#'   - `"equation"`: a user-supplied function `f(dbh_cm, height_m, ...)`.
#' @param equation function (for `method = "equation"`).
#' @param equation_form character; one of `c("power_dbh","power_dbh_h","combined_var")`.
#'   Default `"power_dbh"`.
#' @param coefficients named numeric vector or data frame. For `"power_dbh"`:
#'   `c(a, b)` (intercept and exponent on dbh). For `"power_dbh_h"`:
#'   `c(a, b1, b2)`. For `"combined_var"`: `c(a, b1, b2, b3)` on
#'   `dbh^2*height`. **TODO(scientific-review)**: these coefficients must be
#'   species- and region-specific; supplied defaults are placeholders.
#' @param component character; one of `c("aboveground","stem","bark","branches",
#'   "foliage","roots","deadwood","total")`. Controls which component is
#'   returned when the method provides multiple components.
#' @param wood_density_kg_m3 numeric scalar or species-named vector. Required
#'   for `method = "volume_density"`. Default 400 (placeholder).
#' @param form_factor numeric; passed to [calc_tree_volume()] for
#'   `method = "volume_density"`.
#' @param biomass_expansion_factor numeric scalar or species-named vector; BEF
#'   used to scale stem biomass to aboveground biomass. Default 1.3
#'   (**TODO(scientific-review)**).
#' @param root_to_shoot_ratio numeric scalar or species-named vector; default
#'   0.25 (IPCC 2006 default for tropical/subtropical moist forest,
#'   **placeholder**).
#' @param missing,output as in [calc_tree_volume()].
#' @return numeric vector or data frame. The data frame includes `biomass_kg`,
#'   `component`, `method`, and `parameter_source`.
#' @export
#' @examples
#' # Allometric power-law
#' calc_tree_biomass(dbh_cm = c(20, 25), height_m = c(15, 18),
#'                   method = "allometric",
#'                   equation_form = "power_dbh",
#'                   coefficients = c(a = 0.1, b = 2.4))
#'
#' # Volume-density
#' calc_tree_biomass(dbh_cm = c(20, 25), height_m = c(15, 18),
#'                   method = "volume_density",
#'                   wood_density_kg_m3 = 400)
calc_tree_biomass <- function(data = NULL,
                              dbh_cm = NULL, height_m = NULL,
                              method = c("allometric","volume_density","equation"),
                              equation = NULL,
                              equation_form = c("power_dbh","power_dbh_h","combined_var"),
                              coefficients = NULL,
                              component = c("aboveground","stem","bark","branches",
                                            "foliage","roots","deadwood","total"),
                              wood_density_kg_m3 = NULL,
                              form_factor = 0.45,
                              biomass_expansion_factor = 1.3,
                              root_to_shoot_ratio = 0.25,
                              missing = c("error","warn","return_na"),
                              output = c("vector","data.frame"),
                              ...) {
  method <- match.arg(method)
  equation_form <- match.arg(equation_form)
  component <- match.arg(component)
  missing <- resolve_missing_policy(missing)
  output <- match.arg(output)

  dbh <- resolve_vec(dbh_cm, data, "dbh_cm")
  hgt <- resolve_vec(height_m, data, "height_m")
  sp  <- resolve_vec(species, data, "species")
  tid <- resolve_vec(tree_id, data, "tree_id")
  n <- if (!is.null(dbh)) length(dbh) else if (!is.null(data)) nrow(data) else 1L
  if (is.null(tid)) tid <- seq_len(n)
  dbh <- match_length(dbh, n, "dbh_cm")
  hgt <- match_length(hgt, n, "height_m")
  if (!is.null(dbh)) dbh <- as_finite_numeric(dbh, "dbh_cm", allow_zero = FALSE)
  if (!is.null(hgt)) hgt <- as_finite_numeric(hgt, "height_m", allow_zero = FALSE)

  warn_review_placeholder("biomass_expansion_factor", biomass_expansion_factor,
                          "default 1.3 (forestr2 placeholder)")
  warn_review_placeholder("root_to_shoot_ratio", root_to_shoot_ratio,
                          "IPCC 2006 default 0.25 (forestr2 placeholder)")

  biom <- switch(method,
    allometric = {
      if (is.null(coefficients)) {
        stop("`coefficients` is required for method='allometric'.", call. = FALSE)
      }
      coef_lookup <- normalize_coef_table(coefficients, key_col = "species")
      # We expect named vector c(a,b) or c(a,b1,b2) etc.
      get_coef <- function(nm, default = NA_real_) {
        if (coef_lookup$type == "named") {
          v <- coef_lookup$data[nm]
          if (is.na(v)) v <- coef_lookup$data[[nm]]  # by position fallback
          if (is.null(v) || length(v) == 0L || is.na(v)) default else as.numeric(v)
        } else if (coef_lookup$type == "data.frame") {
          # for data.frame, look up by species (first row only; per-species handled outside)
          if (!nm %in% names(coef_lookup$data)) return(default)
          v <- coef_lookup$data[[nm]][1]
          if (is.na(v)) default else as.numeric(v)
        } else default
      }
      a <- get_coef("a"); b <- get_coef("b")
      switch(equation_form,
        power_dbh = {
          if (is.na(a) || is.na(b)) stop("equation_form='power_dbh' requires coefficients a, b.", call. = FALSE)
          a * dbh^b
        },
        power_dbh_h = {
          b1 <- get_coef("b1"); b2 <- get_coef("b2")
          if (anyNA(c(a, b1, b2))) stop("equation_form='power_dbh_h' requires a, b1, b2.", call. = FALSE)
          a * dbh^b1 * hgt^b2
        },
        combined_var = {
          b1 <- get_coef("b1"); b2 <- get_coef("b2"); b3 <- get_coef("b3")
          if (anyNA(c(a, b1, b2, b3))) stop("equation_form='combined_var' requires a, b1, b2, b3.", call. = FALSE)
          a * (dbh^2 * hgt)^b1 + b2 * dbh + b3
        }
      )
    },
    volume_density = {
      if (is.null(wood_density_kg_m3)) {
        stop("`wood_density_kg_m3` is required for method='volume_density'.",
             call. = FALSE)
      }
      vol <- calc_tree_volume(dbh_cm = dbh, height_m = hgt,
                              method = "form_factor",
                              form_factor = form_factor,
                              missing = "return_na", output = "vector")
      wd <- rep(as.numeric(wood_density_kg_m3), length.out = n)
      stem_biomass <- vol * wd
      # Apply BEF for aboveground, then root-to-shoot for total
      bef <- rep(as.numeric(biomass_expansion_factor), length.out = n)
      ag  <- stem_biomass * bef
      switch(component,
        stem      = stem_biomass,
        aboveground = ag,
        total     = ag * (1 + rep(as.numeric(root_to_shoot_ratio),
                                  length.out = n)),
        roots     = ag * rep(as.numeric(root_to_shoot_ratio), length.out = n),
        ag  # default
      )
    },
    equation = {
      if (is.null(equation) || !is.function(equation)) {
        stop("`equation` must be a function for method='equation'.", call. = FALSE)
      }
      tryCatch(equation(dbh_cm = dbh, height_m = hgt, ...),
               error = function(e) stop("user equation failed: ",
                                        conditionMessage(e), call. = FALSE))
    }
  )

  if (anyNA(biom)) {
    mask <- is.na(biom)
    msg <- paste0("calc_tree_biomass: ", sum(mask), " of ", n, " are NA.")
    if (missing == "error") stop(msg, call. = FALSE)
    if (missing == "warn")  warning(msg, call. = FALSE)
  }

  if (output == "vector") return(biom)
  df <- data.frame(tree_id = tid, biomass_kg = biom,
                   component = component, method = method,
                   stringsAsFactors = FALSE)
  attr(df, "units") <- "kg per tree"
  attr(df, "parameter_source") <- paste0("method=", method,
        "; form_factor=", form_factor,
        "; BEF=", biomass_expansion_factor,
        "; root_to_shoot=", root_to_shoot_ratio,
        "; forestr2 placeholder (review)")
  class(df) <- c("forestr2_result", class(df))
  df
}

# ---- Component biomass ------------------------------------------------------

#' Component biomass (stem, bark, branches, foliage, roots, deadwood)
#'
#' Applies a species-specific component-fraction table to estimate per-tree
#' component biomass. The fractions must sum to 1 (within `tol`); otherwise
#' the function stops with a reconciliation error.
#'
#' @param data optional data frame.
#' @param dbh_cm,height_m,species,tree_id as usual.
#' @param total_biomass_kg optional numeric vector; if supplied, the
#'   component fractions are applied to this total. Otherwise, total biomass
#'   is computed via [calc_tree_biomass()].
#' @param component_fractions data frame with columns `species` and fractions
#'   named `stem`, `bark`, `branches`, `foliage`, `roots`, `deadwood`. Rows
#'   must sum to 1 (within `tol`).
#' @param tol numeric; reconciliation tolerance. Default 1e-3.
#' @param ... passed to [calc_tree_biomass()] when `total_biomass_kg` is NULL.
#' @return data frame (class `forestr2_result`) in long form with one row per
#'   tree-component combination.
#' @export
#' @examples
#' frac <- data.frame(
#'   species   = "Pinus",
#'   stem      = 0.65,
#'   bark      = 0.10,
#'   branches  = 0.12,
#'   foliage   = 0.03,
#'   roots     = 0.09,
#'   deadwood  = 0.01
#' )
#' calc_component_biomass(dbh_cm = 20, height_m = 15, species = "Pinus",
#'                        component_fractions = frac)
calc_component_biomass <- function(data = NULL, dbh_cm = NULL, height_m = NULL,
                                   species = NULL, tree_id = NULL,
                                   total_biomass_kg = NULL,
                                   component_fractions,
                                   tol = 1e-3, ...) {
  if (!is.data.frame(component_fractions)) {
    stop("`component_fractions` must be a data frame.", call. = FALSE)
  }
  req <- c("species","stem","bark","branches","foliage","roots","deadwood")
  missing_cols <- setdiff(req, names(component_fractions))
  if (length(missing_cols)) {
    stop(sprintf("`component_fractions` is missing columns: %s",
                 paste(missing_cols, collapse = ", ")), call. = FALSE)
  }
  # Reconciliation check
  rs <- rowSums(component_fractions[, c("stem","bark","branches","foliage","roots","deadwood")])
  bad <- abs(rs - 1) > tol
  if (any(bad)) {
    stop(sprintf("Component fractions for %d species do not sum to 1 (within tol=%g).",
                 sum(bad), tol), call. = FALSE)
  }

  dbh <- resolve_vec(dbh_cm, data, "dbh_cm")
  hgt <- resolve_vec(height_m, data, "height_m")
  sp  <- resolve_vec(species, data, "species")
  tid <- resolve_vec(tree_id, data, "tree_id")
  n <- max(length(dbh), length(hgt), length(sp), length(tid))
  if (is.null(tid)) tid <- seq_len(n)

  if (is.null(total_biomass_kg)) {
    total_biomass_kg <- calc_tree_biomass(data = data, dbh_cm = dbh,
                                          height_m = hgt, species = sp,
                                          method = "allometric",
                                          component = "total",
                                          missing = "return_na",
                                          output = "vector", ...)
  }
  total_biomass_kg <- match_length(total_biomass_kg, n, "total_biomass_kg")

  # Lookup fractions per species
  out <- do.call(rbind, lapply(seq_len(n), function(i) {
    s <- sp[i]
    fr <- component_fractions[component_fractions$species == s, , drop = FALSE]
    if (nrow(fr) == 0L) {
      return(data.frame(tree_id = tid[i], species = s,
                        component = c("stem","bark","branches","foliage","roots","deadwood"),
                        biomass_kg = NA_real_,
                        fraction = NA_real_,
                        stringsAsFactors = FALSE))
    }
    fr <- fr[1, ]
    comps <- c("stem","bark","branches","foliage","roots","deadwood")
    data.frame(
      tree_id = tid[i], species = s,
      component = comps,
      biomass_kg = unlist(fr[1, comps]) * total_biomass_kg[i],
      fraction   = unlist(fr[1, comps]),
      stringsAsFactors = FALSE
    )
  }))
  attr(out, "method") <- "component fractions applied to total"
  attr(out, "units")  <- "kg per tree per component"
  attr(out, "parameter_source") <- "user-supplied component_fractions"
  class(out) <- c("forestr2_result", class(out))
  out
}

#' Sum component biomass to aboveground
#'
#' @param component_biomass data frame returned by [calc_component_biomass()].
#' @return data frame with `tree_id`, `aboveground_biomass_kg`.
#' @export
calc_aboveground_biomass <- function(component_biomass) {
  if (!is.data.frame(component_biomass)) {
    stop("`component_biomass` must be a data frame.", call. = FALSE)
  }
  ag_components <- c("stem","bark","branches","foliage","deadwood")
  sub <- component_biomass[component_biomass$component %in% ag_components, , drop = FALSE]
  out <- aggregate(biomass_kg ~ tree_id, data = sub, FUN = sum, na.rm = TRUE)
  colnames(out)[2L] <- "aboveground_biomass_kg"
  attr(out, "method") <- "sum(stem+bark+branches+foliage+deadwood)"
  attr(out, "units")  <- "kg per tree"
  class(out) <- c("forestr2_result", class(out))
  out
}

#' Belowground biomass
#'
#' @param component_biomass data frame from [calc_component_biomass()].
#' @return data frame with `tree_id`, `belowground_biomass_kg`.
#' @export
calc_belowground_biomass <- function(component_biomass) {
  if (!is.data.frame(component_biomass)) {
    stop("`component_biomass` must be a data frame.", call. = FALSE)
  }
  sub <- component_biomass[component_biomass$component == "roots", , drop = FALSE]
  out <- aggregate(biomass_kg ~ tree_id, data = sub, FUN = sum, na.rm = TRUE)
  colnames(out)[2L] <- "belowground_biomass_kg"
  attr(out, "method") <- "sum(roots)"
  attr(out, "units")  <- "kg per tree"
  class(out) <- c("forestr2_result", class(out))
  out
}

#' Total biomass
#'
#' @param component_biomass data frame from [calc_component_biomass()].
#' @return data frame with `tree_id`, `total_biomass_kg`, plus a
#'   `reconciliation_ok` flag.
#' @export
calc_total_biomass <- function(component_biomass) {
  if (!is.data.frame(component_biomass)) {
    stop("`component_biomass` must be a data frame.", call. = FALSE)
  }
  out <- aggregate(biomass_kg ~ tree_id, data = component_biomass,
                  FUN = sum, na.rm = TRUE)
  colnames(out)[2L] <- "total_biomass_kg"
  attr(out, "method") <- "sum(all components)"
  attr(out, "units")  <- "kg per tree"
  class(out) <- c("forestr2_result", class(out))
  out
}

# ---- Carbon and CO2e --------------------------------------------------------

#' Carbon stock from biomass
#'
#' Applies the carbon fraction **once**. The carbon fraction is a parameter
#' with a documented default (`0.47`); it is NOT a universal constant.
#'
#' @param biomass either a numeric vector, a `forestr2_result` data frame with
#'   a `biomass_kg` column, or any object understood by [calc_tree_biomass()].
#' @param carbon_fraction numeric scalar; default 0.47
#'   (**TODO(scientific-review)**). Range-checked to [0.3, 0.6].
#' @param output character; one of `c("vector","data.frame")`.
#' @return numeric vector or data frame with `carbon_kg`.
#' @references
#' IPCC (2006). *2006 IPCC Guidelines for National Greenhouse Gas Inventories -
#' Volume 4: Agriculture, Forestry and Other Land Use*. Institute for Global
#' Environmental Strategies, Hayama, Japan.
#' \url{https://www.ipcc-nggip.iges.or.jp/public/2006gl/vol4.html}
#' @export
#' @examples
#' b <- calc_tree_biomass(dbh_cm = 20, height_m = 15,
#'                        method = "volume_density",
#'                        wood_density_kg_m3 = 400)
#' calc_carbon_stock(b)
calc_carbon_stock <- function(biomass, carbon_fraction = 0.47,
                              output = c("vector","data.frame")) {
  output <- match.arg(output)
  if (is.data.frame(biomass) && "biomass_kg" %in% names(biomass)) {
    b <- biomass$biomass_kg
    tid <- biomass$tree_id
  } else if (is.numeric(biomass)) {
    b <- biomass; tid <- seq_along(b)
  } else {
    stop("`biomass` must be a numeric vector or a forestr2_result data frame with `biomass_kg`.",
         call. = FALSE)
  }
  if (length(carbon_fraction) != 1L || !is.numeric(carbon_fraction)) {
    stop("`carbon_fraction` must be a numeric scalar.", call. = FALSE)
  }
  if (carbon_fraction < 0.30 || carbon_fraction > 0.60) {
    stop(sprintf("`carbon_fraction` = %g is outside the plausible range [0.30, 0.60].",
                 carbon_fraction), call. = FALSE)
  }
  warn_review_placeholder("carbon_fraction", carbon_fraction,
                          "default 0.47 (forestr2 placeholder; species-specific)")
  c_kg <- b * carbon_fraction
  if (output == "vector") return(c_kg)
  df <- data.frame(tree_id = tid, carbon_kg = c_kg,
                   carbon_fraction = carbon_fraction,
                   stringsAsFactors = FALSE)
  attr(df, "units") <- "kg C per tree"
  attr(df, "parameter_source") <- sprintf("carbon_fraction=%g (applied once)",
                                          carbon_fraction)
  class(df) <- c("forestr2_result", class(df))
  df
}

#' CO2 equivalent
#'
#' Converts carbon mass to CO2 equivalent using the molecular-weight ratio
#' 44/12. **This conversion is opt-in** — call [calc_co2e()] explicitly when
#' you want CO2e; do not let downstream functions silently multiply by 44/12.
#'
#' @param carbon numeric vector or data frame with `carbon_kg`.
#' @param ratio numeric scalar; default 44/12. Per IPCC AR6, the recommended
#'   value is 44/12 = 3.667; users may override if needed.
#' @param output character; one of `c("vector","data.frame")`.
#' @return numeric vector or data frame with `co2e_kg` and the ratio used.
#' @export
#' @examples
#' b <- calc_tree_biomass(dbh_cm = 20, height_m = 15,
#'                        method = "volume_density",
#'                        wood_density_kg_m3 = 400)
#' c <- calc_carbon_stock(b)
#' calc_co2e(c)
calc_co2e <- function(carbon, ratio = 44/12, output = c("vector","data.frame")) {
  output <- match.arg(output)
  if (is.data.frame(carbon) && "carbon_kg" %in% names(carbon)) {
    c_ <- carbon$carbon_kg
    tid <- carbon$tree_id
  } else if (is.numeric(carbon)) {
    c_ <- carbon; tid <- seq_along(c_)
  } else {
    stop("`carbon` must be a numeric vector or a forestr2_result data frame with `carbon_kg`.",
         call. = FALSE)
  }
  if (length(ratio) != 1L || !is.numeric(ratio) || ratio <= 0) {
    stop("`ratio` must be a positive numeric scalar.", call. = FALSE)
  }
  co2 <- c_ * ratio
  if (output == "vector") return(co2)
  df <- data.frame(tree_id = tid, co2e_kg = co2,
                   ratio = ratio, stringsAsFactors = FALSE)
  attr(df, "units") <- "kg CO2e per tree"
  attr(df, "parameter_source") <- sprintf("ratio=44/12=%g (molecular weight)", ratio)
  class(df) <- c("forestr2_result", class(df))
  df
}

# ---- fit_biomass_model ------------------------------------------------------

#' Fit a biomass allometric equation
#'
#' Wraps [stats::nls()] and [stats::lm()] for fitting allometric biomass
#' equations. Supports log-transformed response with Baskerville bias
#' correction, weighting, and cross-validation.
#'
#' @inheritParams fit_volume_model
#' @param data data frame.
#' @param formula a formula. Common templates:
#'   - `biomass_kg ~ dbh_cm` (linear; fit on log scale recommended).
#'   - `biomass_kg ~ dbh_cm + I(dbh_cm^2) + height_m`.
#'   - Self-starting nonlinear form for `nls()` via `start`.
#' @param start optional starting values for `nls()`.
#' @param weights optional case weights.
#' @param species optional column name or vector; per-species fits returned.
#' @param cv integer; folds for cross-validation.
#' @param log_response logical; if TRUE, fit on `log(response)`.
#'
#' @return object of class `forestr2_biomass_model`.
#' @references
#' Baskerville, G. L. (1972). Use of logarithmic regression in the estimation
#' of plant biomass. *Canadian Journal of Forestry Research*, 2(1), 49-53.
#' \doi{10.1139/x72-009}
#'
#' Zianis, D., Muukkonen, P., Makipaa, R., & Mencuccini, M. (2005).
#' Biomass and stem volume equations for tree species in Europe.
#' *Silva Fennica Monographs*, 4, 1-63.
#' \doi{10.14214/sf.sfm.4}
#' @export
#' @examples
#' \dontrun{
#' d <- data.frame(
#'   biomass_kg = c(50, 80, 120, 180, 250),
#'   dbh_cm     = c(10, 15, 20, 25, 30),
#'   height_m   = c(8, 12, 15, 18, 20)
#' )
#' m <- fit_biomass_model(d, log(biomass_kg) ~ log(dbh_cm), log_response = TRUE)
#' predict_biomass(m, newdata = data.frame(dbh_cm = c(20, 25)))
#' }
fit_biomass_model <- function(data, formula, start = NULL, weights = NULL,
                              species = NULL, cv = 0L, log_response = FALSE) {
  # Implementation mirrors fit_volume_model; separated to attach distinct class
  # and report retransformation bias specifically for biomass.
  if (!is.data.frame(data)) stop("`data` must be a data.frame.", call. = FALSE)
  if (!inherits(formula, "formula")) stop("`formula` must be a formula.",
                                          call. = FALSE)

  fit_one <- function(d) {
    if (nrow(d) < 3L) stop("Need >=3 rows to fit a biomass model.", call. = FALSE)
    f <- formula
    if (log_response) {
      resp <- all.vars(f)[1L]
      # If the user already wrote log(biomass_kg) on the LHS we don't double-log.
      if (!grepl("^log\\(", deparse(f[[2L]]))) {
        f <- update(f, as.formula(paste("log(", resp, ") ~ .")))
      }
    }
    if (!is.null(start)) {
      fit <- stats::nls(f, data = d, start = start, weights = weights)
    } else {
      fit <- stats::lm(f, data = d, weights = weights)
    }
    preds <- as.numeric(stats::predict(fit))
    obs <- d[[all.vars(formula)[1L]]]
    cf <- 1
    if (log_response) {
      resid <- log(obs) - preds
      cf <- exp(stats::var(resid, na.rm = TRUE) / 2)
      preds <- exp(preds) * cf
    }
    resid <- obs - preds
    metrics <- list(
      rmse = sqrt(mean(resid^2, na.rm = TRUE)),
      mae  = mean(abs(resid), na.rm = TRUE),
      bias = mean(resid, na.rm = TRUE),
      r2   = if (log_response) NA_real_
             else 1 - sum(resid^2, na.rm = TRUE) /
                       sum((obs - mean(obs, na.rm = TRUE))^2, na.rm = TRUE),
      aic  = tryCatch(stats::AIC(fit), error = function(e) NA_real_),
      n    = nrow(d),
      retransformation_bias_correction = cf
    )
    cv_metrics <- NULL
    if (cv >= 2L) {
      folds <- sample(rep(seq_len(cv), length.out = nrow(d)))
      preds_cv <- rep(NA_real_, nrow(d))
      for (k in seq_len(cv)) {
        train <- folds != k; test <- folds == k
        if (sum(train) < 2L || sum(test) == 0L) next
        fit_k <- tryCatch(
          if (!is.null(start)) stats::nls(f, data = d[train, ], start = start)
          else stats::lm(f, data = d[train, ]),
          error = function(e) NULL
        )
        if (is.null(fit_k)) next
        p <- as.numeric(stats::predict(fit_k, newdata = d[test, ]))
        if (log_response) p <- exp(p)
        preds_cv[test] <- p
      }
      r_cv <- d[[all.vars(formula)[1L]]] - preds_cv
      cv_metrics <- list(
        rmse = sqrt(mean(r_cv^2, na.rm = TRUE)),
        mae  = mean(abs(r_cv), na.rm = TRUE),
        bias = mean(r_cv, na.rm = TRUE)
      )
    }
    structure(
      list(fit = fit, formula = formula, log_response = log_response,
           bias_correction = cf, metrics = metrics,
           cv_metrics = cv_metrics,
           parameter_source = "user-supplied formula"),
      class = "forestr2_biomass_model"
    )
  }

  if (!is.null(species)) {
    if (is.character(species) && length(species) == 1L && species %in% names(data)) {
      species <- data[[species]]
    }
    out <- by(data, factor(species), fit_one)
    return(structure(as.list(out), class = "forestr2_biomass_model_list",
                     species = levels(factor(species))))
  }
  fit_one(data)
}

#' Predict from a fitted biomass model
#'
#' @inheritParams predict_volume
#' @export
predict_biomass <- function(object, newdata = NULL, dbh_cm = NULL,
                            height_m = NULL, species = NULL,
                            interval = c("none","confidence","prediction"),
                            level = 0.95, ...) {
  interval <- match.arg(interval)
  if (inherits(object, "forestr2_biomass_model_list")) {
    if (is.null(species)) stop("`species` is required for per-species prediction.",
                               call. = FALSE)
    out <- do.call(rbind, lapply(seq_along(object), function(i) {
      m <- object[[i]]
      sp <- attr(object, "species")[i]
      sel <- species == sp
      if (!any(sel)) return(NULL)
      pred <- predict_biomass(m, newdata = newdata, dbh_cm = dbh_cm[sel],
                              height_m = height_m[sel],
                              interval = interval, level = level, ...)
      pred$species <- sp
      pred
    }))
    return(out)
  }
  if (!inherits(object, "forestr2_biomass_model")) {
    stop("`object` must be a forestr2_biomass_model.", call. = FALSE)
  }
  if (is.null(newdata) && (!is.null(dbh_cm) || !is.null(height_m))) {
    newdata <- data.frame(dbh_cm = dbh_cm, height_m = height_m)
  }
  if (is.null(newdata)) {
    preds <- as.numeric(stats::predict(object$fit))
    se    <- tryCatch(as.numeric(stats::predict(object$fit, se.fit = TRUE)$se.fit),
                      error = function(e) NA_real_)
  } else {
    p <- tryCatch(stats::predict(object$fit, newdata = newdata,
                                 se.fit = TRUE, ...),
                  error = function(e) list(fit = stats::predict(object$fit,
                                                                newdata = newdata),
                                            se.fit = NA_real_))
    preds <- as.numeric(p$fit); se <- as.numeric(p$se.fit)
    if (length(se) == 1L && is.na(se)) se <- rep(NA_real_, length(preds))
  }
  if (isTRUE(object$log_response)) {
    preds <- exp(preds) * object$bias_correction
    se    <- se * preds
  }
  out <- data.frame(biomass_kg = preds)
  if (interval != "none") {
    tcrit <- stats::qt((1 + level) / 2, df = object$metrics$n - 1)
    out$lower <- out$biomass_kg - tcrit * se
    out$upper <- out$biomass_kg + tcrit * se
  }
  out
}

#' @describeIn predict_biomass Print method
#' @param x a `forestr2_biomass_model`.
#' @export
print.forestr2_biomass_model <- function(x, ...) {
  cat("<forestr2_biomass_model>\n")
  cat("formula:", deparse(x$formula), "\n")
  if (isTRUE(x$log_response)) {
    cat("log-response: TRUE; retransformation bias correction factor =",
        format(x$bias_correction, digits = 4), "\n")
  }
  cat("metrics:\n"); print(x$metrics)
  if (!is.null(x$cv_metrics)) {
    cat("cross-validation metrics:\n"); print(x$cv_metrics)
  }
  invisible(x)
}

# ---- Aggregation to plot/stand ----------------------------------------------

#' Aggregate biomass to plot (or stand) level
#'
#' Returns mean biomass per tree, biomass per hectare, component totals
#' (when components were computed), carbon stock per hectare, and CO2e per
#' hectare when `include_co2e = TRUE`. Includes design-based SE and CI.
#'
#' @param inv a `forestr2_inventory` with `biomass_kg` populated.
#' @param expansion as in [calc_volume_by_plot()].
#' @param level as in [calc_volume_by_plot()].
#' @param carbon_fraction passed to [calc_carbon_stock()].
#' @param include_co2e logical; default FALSE.
#' @param conf_level numeric; default 0.95.
#' @return data frame (class `forestr2_result`).
#' @export
aggregate_biomass_plot <- function(inv,
                                   expansion = c("fixed_area","explicit"),
                                   level = c("plot","stand"),
                                   carbon_fraction = 0.47,
                                   include_co2e = FALSE,
                                   conf_level = 0.95) {
  if (!is_forestr2_inventory(inv)) stop("`inv` must be a forestr2_inventory.", call. = FALSE)
  expansion <- match.arg(expansion); level <- match.arg(level)
  if (is.null(inv$biomass_kg) || all(is.na(inv$biomass_kg))) {
    stop("`inv$biomass_kg` must be populated; call calc_tree_biomass() first.",
         call. = FALSE)
  }
  ef <- switch(expansion,
               fixed_area = 1 / inv$plot_area_ha,
               explicit   = inv$expansion_factor)
  biom_ha <- inv$biomass_kg * ef  # kg/ha
  grp <- if (level == "plot") inv$plot_id else inv$stand_id
  plot_vals <- tapply(biom_ha, grp, sum, na.rm = TRUE)
  n_plots <- length(plot_vals)
  se <- if (n_plots >= 2L) stats::sd(plot_vals) / sqrt(n_plots) else NA_real_
  tcrit <- if (n_plots >= 2L) stats::qt((1 + conf_level)/2, df = n_plots - 1) else NA_real_
  mu <- mean(plot_vals)
  out <- data.frame(
    level               = level,
    biomass_kg_ha       = mu,
    biomass_Mg_ha       = mu / 1000,
    se                  = se,
    lower               = if (is.na(se)) NA_real_ else mu - tcrit * se,
    upper               = if (is.na(se)) NA_real_ else mu + tcrit * se,
    mean_biomass_per_tree_kg = mean(inv$biomass_kg, na.rm = TRUE),
    carbon_stock_kg_ha  = mu * carbon_fraction,
    carbon_stock_Mg_ha  = mu * carbon_fraction / 1000,
    n_trees             = nrow(inv),
    n_plots             = n_plots,
    stringsAsFactors    = FALSE
  )
  if (include_co2e) {
    out$co2e_kg_ha <- out$carbon_stock_kg_ha * 44 / 12
    out$co2e_Mg_ha <- out$co2e_kg_ha / 1000
  }
  attr(out, "method") <- sprintf("aggregate_biomass_plot(expansion=%s, level=%s)",
                                 expansion, level)
  attr(out, "parameter_source") <- sprintf("carbon_fraction=%g; ratio=44/12",
                                           carbon_fraction)
  class(out) <- c("forestr2_result", class(out))
  out
}
