# ----------------------------------------------------------------------------
# forestr2: data model
#
# Constructors and validators for tree, plot, stand, and repeated-measurement
# data. The class `forestr2_inventory` is a data.frame subclass carrying the
# standard fields plus metadata about units, design, and parameter provenance.
# ----------------------------------------------------------------------------

# ---- Standard field names ---------------------------------------------------

#' Standard field names used by forestr2
#'
#' Returns the canonical field names recognized by the package. User-defined
#' names are supported through explicit `*_field` arguments on constructors.
#'
#' @return named character vector.
#' @export
#' @examples
#' forestr2_fields()
forestr2_fields <- function() {
  c(
    tree_id            = "tree_id",
    plot_id            = "plot_id",
    stand_id           = "stand_id",
    species            = "species",
    species_code       = "species_code",
    dbh_cm             = "dbh_cm",
    height_m           = "height_m",
    crown_width_m      = "crown_width_m",
    tree_age           = "tree_age",
    status             = "status",
    x                  = "x",
    y                  = "y",
    measurement_date   = "measurement_date",
    basal_area_m2_ha   = "basal_area_m2_ha",
    volume_m3          = "volume_m3",
    biomass_kg         = "biomass_kg",
    treatment          = "treatment",
    block              = "block",
    plot_area_ha       = "plot_area_ha",
    expansion_factor   = "expansion_factor"
  )
}

# ---- Tree inventory constructor --------------------------------------------

#' Construct a validated tree-level inventory
#'
#' Builds a `forestr2_inventory` object from supplied vectors or a data frame.
#' Performs unit and plausibility validation and reports (but does not silently
#' fix) issues with identifiers, missingness, and duplicated tree IDs.
#'
#' @param data optional `data.frame` containing the standard fields.
#' @param tree_id,plot_id,stand_id,species,species_code,status,treatment,block
#'   character vectors or names of columns in `data`.
#' @param dbh_cm,height_m,crown_width_m,tree_age,x,y,measurement_date,basal_area_m2_ha,volume_m3,biomass_kg,plot_area_ha,expansion_factor
#'   numeric vectors or names of columns in `data`.
#' @param allow_missing_id logical; if FALSE (default) missing `tree_id` is an
#'   error.
#' @param allow_duplicate_trees logical; if TRUE, duplicate `tree_id` within
#'   plot is permitted (with a warning). Default FALSE.
#' @param allow_dead logical; if TRUE, dead trees (status `"dead"`) are
#'   permitted without requiring `dbh_cm`. Default TRUE.
#'
#' @return An object of class `forestr2_inventory`, a `data.frame` subclass with
#'   attributes:
#'   - `units`: named character vector mapping field -> unit string.
#'   - `design`: list with `plot_area_ha`, `expansion_factor` (if present).
#'   - `validated_at`: POSIXct timestamp.
#'   - `validation_warnings`: character vector of warnings emitted.
#'
#' @export
#' @examples
#' inv <- tree_inventory(
#'   tree_id = c("T1","T2"),
#'   plot_id = c("P1","P1"),
#'   species = c("Picea abies","Picea abies"),
#'   dbh_cm  = c(20.5, 22.0),
#'   height_m= c(15.0, 16.2),
#'   plot_area_ha = 0.05
#' )
#' print(inv)
tree_inventory <- function(data = NULL,
                            tree_id = NULL, plot_id = NULL, stand_id = NULL,
                            species = NULL, species_code = NULL,
                            dbh_cm = NULL, height_m = NULL, crown_width_m = NULL,
                            tree_age = NULL, status = NULL,
                            x = NULL, y = NULL, measurement_date = NULL,
                            basal_area_m2_ha = NULL, volume_m3 = NULL,
                            biomass_kg = NULL,
                            treatment = NULL, block = NULL,
                            plot_area_ha = NULL, expansion_factor = NULL,
                            allow_missing_id = FALSE,
                            allow_duplicate_trees = FALSE,
                            allow_dead = TRUE) {

  # Build a working data frame from explicit vectors, or pull from `data`.
  if (is.null(data)) {
    inputs <- list(tree_id, plot_id, stand_id, species, species_code,
                   dbh_cm, height_m, crown_width_m, tree_age, status,
                   x, y, measurement_date, basal_area_m2_ha, volume_m3,
                   biomass_kg, treatment, block, plot_area_ha,
                   expansion_factor)
    nonzero <- vapply(inputs, function(x) !is.null(x) && length(x) > 0L,
                      logical(1))
    if (!any(nonzero)) {
      stop("tree_inventory: at least one non-zero-length vector is required.",
           call. = FALSE)
    }
    n <- max(vapply(inputs[nonzero], length, integer(1)))
    df <- data.frame(row.names = seq_len(n))
  } else {
    if (!is.data.frame(data)) {
      stop("`data` must be a data.frame.", call. = FALSE)
    }
    n <- nrow(data)
    df <- data
  }

  # Resolve each field: explicit vector wins, else pull from `data` by name.
  get_field <- function(vec, default_name) {
    if (!is.null(vec)) {
      if (is.character(vec) && length(vec) == 1L && !is.null(data) &&
          vec %in% names(data)) {
        return(data[[vec]])
      }
      return(vec)
    }
    if (!is.null(data) && default_name %in% names(data)) return(data[[default_name]])
    return(NULL)
  }

  tree_id_v          <- get_field(tree_id, "tree_id")
  plot_id_v          <- get_field(plot_id, "plot_id")
  stand_id_v         <- get_field(stand_id, "stand_id")
  species_v          <- get_field(species, "species")
  species_code_v     <- get_field(species_code, "species_code")
  dbh_cm_v           <- get_field(dbh_cm, "dbh_cm")
  height_m_v         <- get_field(height_m, "height_m")
  crown_width_m_v    <- get_field(crown_width_m, "crown_width_m")
  tree_age_v         <- get_field(tree_age, "tree_age")
  status_v           <- get_field(status, "status")
  x_v                <- get_field(x, "x")
  y_v                <- get_field(y, "y")
  measurement_date_v <- get_field(measurement_date, "measurement_date")
  basal_area_m2_ha_v <- get_field(basal_area_m2_ha, "basal_area_m2_ha")
  volume_m3_v        <- get_field(volume_m3, "volume_m3")
  biomass_kg_v       <- get_field(biomass_kg, "biomass_kg")
  treatment_v        <- get_field(treatment, "treatment")
  block_v            <- get_field(block, "block")
  plot_area_ha_v     <- get_field(plot_area_ha, "plot_area_ha")
  expansion_factor_v <- get_field(expansion_factor, "expansion_factor")

  warnings_emitted <- character(0)

  # --- Identifier validation ---
  if (is.null(tree_id_v) && !allow_missing_id) {
    stop("`tree_id` is required (or set `allow_missing_id = TRUE`).",
         call. = FALSE)
  }
  if (!is.null(tree_id_v)) {
    if (anyNA(tree_id_v) && !allow_missing_id) {
      stop("`tree_id` contains NA values.", call. = FALSE)
    }
    if (!is.null(plot_id_v)) {
      dup <- duplicated(interaction(tree_id_v, plot_id_v))
      if (any(dup) && !allow_duplicate_trees) {
        stop(sprintf("`tree_id` is duplicated within `plot_id`: %d duplicates.",
                     sum(dup)), call. = FALSE)
      } else if (any(dup)) {
        warnings_emitted <- c(warnings_emitted,
          paste("Duplicate tree_id within plot_id:",
                sum(dup), "rows."))
      }
    }
  }

  # --- Numeric / unit validation ---
  if (!is.null(dbh_cm_v)) {
    dbh_cm_v <- as_finite_numeric(dbh_cm_v, "dbh_cm", allow_zero = FALSE)
    bad <- !is.na(dbh_cm_v) & dbh_cm_v > 300
    if (any(bad)) {
      warnings_emitted <- c(warnings_emitted,
        paste("Implausible dbh_cm > 300 cm:", sum(bad), "rows."))
    }
  }
  if (!is.null(height_m_v)) {
    height_m_v <- as_finite_numeric(height_m_v, "height_m", allow_zero = FALSE)
    bad <- !is.na(height_m_v) & height_m_v > 100
    if (any(bad)) {
      warnings_emitted <- c(warnings_emitted,
        paste("Implausible height_m > 100 m:", sum(bad), "rows."))
    }
  }
  if (!is.null(crown_width_m_v)) {
    crown_width_m_v <- as_finite_numeric(crown_width_m_v, "crown_width_m",
                                         allow_zero = TRUE)
  }
  if (!is.null(tree_age_v)) {
    tree_age_v <- as_finite_numeric(tree_age_v, "tree_age", allow_zero = TRUE)
  }
  if (!is.null(plot_area_ha_v)) {
    plot_area_ha_v <- as_finite_numeric(plot_area_ha_v, "plot_area_ha",
                                        allow_zero = FALSE)
    if (any(!is.na(plot_area_ha_v) & plot_area_ha_v > 100)) {
      warnings_emitted <- c(warnings_emitted,
        "Implausible plot_area_ha > 100 ha.")
    }
  }
  if (!is.null(expansion_factor_v)) {
    expansion_factor_v <- as_finite_numeric(expansion_factor_v,
                                            "expansion_factor", allow_zero = FALSE)
  }
  if (!is.null(basal_area_m2_ha_v)) {
    basal_area_m2_ha_v <- as_finite_numeric(basal_area_m2_ha_v,
                                            "basal_area_m2_ha",
                                            allow_zero = TRUE)
  }
  if (!is.null(volume_m3_v)) {
    volume_m3_v <- as_finite_numeric(volume_m3_v, "volume_m3", allow_zero = TRUE)
  }
  if (!is.null(biomass_kg_v)) {
    biomass_kg_v <- as_finite_numeric(biomass_kg_v, "biomass_kg",
                                      allow_zero = TRUE)
  }
  if (!is.null(x_v)) x_v <- as_finite_numeric(x_v, "x", allow_negative = TRUE)
  if (!is.null(y_v)) y_v <- as_finite_numeric(y_v, "y", allow_negative = TRUE)

  # --- Status normalization ---
  if (!is.null(status_v)) {
    status_v <- tolower(as.character(status_v))
    known <- c("live","dead","harvested","missing","damaged","dying","recruit")
    unknown <- setdiff(unique(status_v[!is.na(status_v)]), known)
    if (length(unknown)) {
      warnings_emitted <- c(warnings_emitted,
        paste("Unknown status values:", paste(unknown, collapse = ", ")))
    }
    if (!allow_dead && any(status_v == "dead", na.rm = TRUE)) {
      stop("Dead trees present and `allow_dead = FALSE`.", call. = FALSE)
    }
  }

  # --- Assemble ---
  out <- data.frame(
    tree_id          = tree_id_v %||% NA_character_,
    plot_id          = plot_id_v %||% NA_character_,
    stand_id         = stand_id_v %||% NA_character_,
    species          = species_v %||% NA_character_,
    species_code     = species_code_v %||% NA_character_,
    dbh_cm           = dbh_cm_v %||% NA_real_,
    height_m         = height_m_v %||% NA_real_,
    crown_width_m    = crown_width_m_v %||% NA_real_,
    tree_age         = tree_age_v %||% NA_real_,
    status           = status_v %||% "live",
    x                = x_v %||% NA_real_,
    y                = y_v %||% NA_real_,
    measurement_date = measurement_date_v,
    basal_area_m2_ha = basal_area_m2_ha_v %||% NA_real_,
    volume_m3        = volume_m3_v %||% NA_real_,
    biomass_kg       = biomass_kg_v %||% NA_real_,
    treatment        = treatment_v %||% NA_character_,
    block            = block_v %||% NA_character_,
    plot_area_ha     = plot_area_ha_v %||% NA_real_,
    expansion_factor = expansion_factor_v %||% NA_real_,
    stringsAsFactors = FALSE
  )

  attr(out, "units") <- c(
    tree_id = "id", plot_id = "id", stand_id = "id",
    species = "id", species_code = "id",
    dbh_cm = "cm", height_m = "m", crown_width_m = "m",
    tree_age = "yr", status = "category",
    x = "m", y = "m", measurement_date = "date",
    basal_area_m2_ha = "m2/ha", volume_m3 = "m3",
    biomass_kg = "kg", treatment = "category", block = "id",
    plot_area_ha = "ha", expansion_factor = "per_ha"
  )
  attr(out, "design") <- list(
    plot_area_ha     = plot_area_ha_v,
    expansion_factor = expansion_factor_v,
    has_blocks       = !all(is.na(out$block)),
    has_treatments   = !all(is.na(out$treatment))
  )
  attr(out, "validated_at") <- as.POSIXct(Sys.time())
  attr(out, "validation_warnings") <- warnings_emitted
  attr(out, "parameter_source") <- "user-supplied"
  class(out) <- c("forestr2_inventory", "data.frame")

  if (length(warnings_emitted) > 0L) {
    warning(paste(warnings_emitted, collapse = "\n"), call. = FALSE)
  }
  out
}

#' @describeIn tree_inventory Test for `forestr2_inventory` class
#' @param x object to test.
#' @export
is_forestr2_inventory <- function(x) {
  inherits(x, "forestr2_inventory")
}

#' @describeIn tree_inventory Coerce to `forestr2_inventory`
#' @export
as_forestr2_inventory <- function(x) {
  if (is_forestr2_inventory(x)) return(x)
  if (!is.data.frame(x)) stop("`x` must be a data.frame.", call. = FALSE)
  # naive coercion: pass through constructor with default field names.
  do.call(tree_inventory, c(list(data = x), lapply(names(x), function(nm) nm)))
}

# ---- %||% helper (re-exported semantics) ------------------------------------

#' Null-coalescing operator
#'
#' Returns `y` when `x` is `NULL`, otherwise `x`. Internal use.
#' @param x,y any R object.
#' @keywords internal
#' @noRd
`%||%` <- function(x, y) if (is.null(x)) y else x

# ---- Print method -----------------------------------------------------------

#' @describeIn tree_inventory Print method
#' @export
print.forestr2_inventory <- function(x, ...) {
  n <- nrow(x)
  np <- length(unique(x$plot_id[!is.na(x$plot_id)]))
  ns <- length(unique(x$species[!is.na(x$species)]))
  cat(sprintf("<forestr2_inventory> %d trees | %d plots | %d species\n",
              n, np, ns))
  if (!is.null(attr(x, "units"))) {
    cat("units:", paste(names(attr(x, "units")),
                        attr(x, "units"), sep = "=",
                        collapse = ", "), "\n")
  }
  if (length(attr(x, "validation_warnings"))) {
    cat("validation warnings:",
        length(attr(x, "validation_warnings")), "\n")
  }
  NextMethod("print")
  invisible(x)
}

# ---- Summary method ---------------------------------------------------------

#' Summary of a forestr2_inventory
#'
#' @param object a `forestr2_inventory` object.
#' @param ... unused.
#' @return object of class `summary.forestr2_inventory` (a list).
#' @export
summary.forestr2_inventory <- function(object, ...) {
  out <- list(
    n_trees          = nrow(object),
    n_plots          = length(unique(object$plot_id[!is.na(object$plot_id)])),
    n_stands         = length(unique(object$stand_id[!is.na(object$stand_id)])),
    n_species        = length(unique(object$species[!is.na(object$species)])),
    by_species       = if (!all(is.na(object$species))) {
                         as.data.frame(table(species = object$species,
                                             useNA = "ifany"))
                       } else NULL,
    dbh_summary      = if (!all(is.na(object$dbh_cm)))
                         summary(object$dbh_cm) else NULL,
    height_summary   = if (!all(is.na(object$height_m)))
                         summary(object$height_m) else NULL,
    status_counts    = as.data.frame(table(status = object$status,
                                           useNA = "ifany")),
    validation_warnings = attr(object, "validation_warnings")
  )
  class(out) <- "summary.forestr2_inventory"
  out
}

#' @describeIn summary.forestr2_inventory Print method
#' @param x an object returned by [summary.forestr2_inventory()].
#' @export
print.summary.forestr2_inventory <- function(x, ...) {
  cat(sprintf("forestr2_inventory summary: %d trees, %d plots, %d stands, %d species\n",
              x$n_trees, x$n_plots, x$n_stands, x$n_species))
  if (!is.null(x$dbh_summary)) {
    cat("\nDBH (cm) summary:\n"); print(x$dbh_summary)
  }
  if (!is.null(x$height_summary)) {
    cat("\nHeight (m) summary:\n"); print(x$height_summary)
  }
  cat("\nStatus counts:\n"); print(x$status_counts)
  if (!is.null(x$by_species)) {
    cat("\nTrees by species:\n"); print(x$by_species)
  }
  invisible(x)
}

# ---- Repeated measurements --------------------------------------------------

#' Construct a repeated-measurement (longitudinal) tree inventory
#'
#' Wraps [tree_inventory()] and additionally validates that (tree_id,
#' measurement_date) pairs are unique, that dates are sortable, and that
#' biologically impossible regress are flagged (e.g. DBH decreasing without
#' a status change).
#'
#' @param data,data.frame passing through to [tree_inventory()].
#' @param ... passed to [tree_inventory()].
#' @param measurement_date a Date or POSIXct vector, or the name of a column
#'   in `data`. Required.
#' @param allow_negative_increment logical; if TRUE, allow DBH to decrease
#'   without an explanatory status change (default FALSE, with warning).
#'
#' @return An object of class `c("forestr2_repeated","forestr2_inventory")`.
#' @export
#' @examples
#' \dontrun{
#' rep <- repeated_measurements(
#'   data = my_long_df,
#'   measurement_date = "measurement_date"
#' )
#' }
repeated_measurements <- function(data = NULL, ...,
                                  measurement_date = NULL,
                                  allow_negative_increment = FALSE) {
  if (is.null(measurement_date)) {
    stop("`measurement_date` is required for repeated_measurements().",
         call. = FALSE)
  }
  inv <- tree_inventory(data = data, ..., measurement_date = measurement_date)
  if (is.null(inv$measurement_date)) {
    stop("`measurement_date` could not be resolved.", call. = FALSE)
  }
  dates <- tryCatch(as.Date(inv$measurement_date),
                    error = function(e) NA)
  if (all(is.na(dates))) {
    stop("`measurement_date` could not be coerced to Date.",
         call. = FALSE)
  }
  inv$measurement_date <- dates
  # Uniqueness
  key <- paste(inv$tree_id, inv$measurement_date, sep = "::")
  dup <- duplicated(key)
  if (any(dup)) {
    stop(sprintf("Repeated (tree_id, measurement_date) pairs are not unique: %d duplicates.",
                 sum(dup)), call. = FALSE)
  }
  # Negative increments
  if (!allow_negative_increment && !all(is.na(inv$dbh_cm))) {
    ord <- order(inv$tree_id, inv$measurement_date)
    df_ord <- inv[ord, , drop = FALSE]
    ddbh <- c(NA, diff(df_ord$dbh_cm))
    same_tree <- c(FALSE, head(df_ord$tree_id, -1) == tail(df_ord$tree_id, -1))
    neg_inc <- same_tree & !is.na(ddbh) & ddbh < 0
    if (any(neg_inc)) {
      warning(sprintf("Negative DBH increments detected for %d tree-measurements; ",
                      "consider setting `allow_negative_increment = TRUE` or ",
                      "reviewing the `status` column.",
                      sum(neg_inc)), call. = FALSE)
    }
  }
  class(inv) <- c("forestr2_repeated", class(inv))
  inv
}

#' Compute growth increments for a repeated-measurement inventory
#'
#' For each tree, sort by measurement_date and compute first differences of
#' `dbh_cm` and (if present) `height_m` and `volume_m3`.
#'
#' @param inv a `forestr2_repeated` object.
#' @param variables character; which variables to difference. Default
#'   `c("dbh_cm","height_m","volume_m3")`.
#' @return data frame with one row per measurement, sorted by tree and date,
#'   with new `<var>_increment` columns. Class `c("forestr2_result","data.frame")`.
#' @export
growth_increments <- function(inv,
                              variables = c("dbh_cm","height_m","volume_m3")) {
  if (!inherits(inv, "forestr2_repeated")) {
    stop("`inv` must be a forestr2_repeated object.", call. = FALSE)
  }
  variables <- intersect(variables, names(inv))
  ord <- order(inv$tree_id, inv$measurement_date)
  df <- inv[ord, , drop = FALSE]
  for (v in variables) {
    if (!is.numeric(df[[v]])) next
    new_col <- paste0(v, "_increment")
    same_tree <- c(FALSE, head(df$tree_id, -1) == tail(df$tree_id, -1))
    incr <- c(NA, diff(df[[v]]))
    incr[!same_tree] <- NA
    df[[new_col]] <- incr
  }
  class(df) <- c("forestr2_result", class(df))
  attr(df, "method") <- "first-difference"
  attr(df, "units")  <- "same as input variable"
  df
}

# ---- Plot summary -----------------------------------------------------------

#' Plot-level summary of a forestr2_inventory
#'
#' Computes per-plot summaries: tree count, basal area per hectare (design-based
#' via expansion factors or computed from dbh and plot_area_ha), volume and
#' biomass per hectare when available, species richness, Shannon and Simpson
#' diversity, and mean DBH and height.
#'
#' @param inv a `forestr2_inventory` object.
#' @param expansion character; one of `c("fixed_area","explicit","basal_area_factor")`.
#'   - `"fixed_area"` (default): per-tree expansion factor is `1 / plot_area_ha`.
#'   - `"explicit"`: use the `expansion_factor` column of `inv`.
#'   - `"basal_area_factor"`: BAF point sampling (TODO(scientific-review)).
#' @param level character; one of `c("plot","stand")`. Default `"plot"`.
#'
#' @return data frame (class `forestr2_result`) with one row per plot/stand.
#' @export
#' @examples
#' inv <- tree_inventory(
#'   tree_id = c("T1","T2","T3"),
#'   plot_id = c("P1","P1","P1"),
#'   species = c("Picea abies","Picea abies","Pinus sylvestris"),
#'   dbh_cm  = c(20, 22, 24),
#'   height_m= c(15, 16, 18),
#'   plot_area_ha = 0.05
#' )
#' plot_summary(inv)
plot_summary <- function(inv,
                         expansion = c("fixed_area","explicit","basal_area_factor"),
                         level = c("plot","stand")) {
  if (!is_forestr2_inventory(inv)) {
    stop("`inv` must be a forestr2_inventory (see tree_inventory()).",
         call. = FALSE)
  }
  expansion <- match.arg(expansion)
  level <- match.arg(level)
  if (expansion == "basal_area_factor") {
    .NotYetImplemented("basal_area_factor expansion; use 'fixed_area' or 'explicit'.")
  }
  if (expansion == "explicit" &&
      (is.null(inv$expansion_factor) || all(is.na(inv$expansion_factor)))) {
    stop("expansion='explicit' requires a non-NA `expansion_factor` column.",
         call. = FALSE)
  }
  if (expansion == "fixed_area" &&
      (is.null(inv$plot_area_ha) || all(is.na(inv$plot_area_ha)))) {
    stop("expansion='fixed_area' requires a non-NA `plot_area_ha` column.",
         call. = FALSE)
  }

  grp_col <- if (level == "plot") "plot_id" else "stand_id"
  if (is.null(inv[[grp_col]]) || all(is.na(inv[[grp_col]]))) {
    stop(sprintf("`%s` column is required for level='%s'.", grp_col, level),
         call. = FALSE)
  }

  # Per-tree expansion factor
  ef <- switch(expansion,
               fixed_area = 1 / inv$plot_area_ha,
               explicit   = inv$expansion_factor,
               basal_area_factor = NA_real_)

  # Basal area per tree (m2)
  ba_tree <- if (!is.null(inv$dbh_cm) && !all(is.na(inv$dbh_cm))) {
               pi * (inv$dbh_cm / 100 / 2)^2
             } else rep(NA_real_, nrow(inv))
  ba_ha   <- ba_tree * ef

  # Per-plot aggregation
  out <- do.call(rbind, lapply(split(inv, inv[[grp_col]]), function(d) {
    i  <- match(d$tree_id, inv$tree_id)  # row index in original
    e  <- ef[i]
    ba <- ba_ha[i]
    ba_sum  <- sum(ba, na.rm = TRUE)
    n_trees <- sum(!is.na(d$tree_id))
    n_live  <- sum(d$status == "live", na.rm = TRUE)
    sp      <- unique(na.omit(d$species))
    vol_ha  <- if (!is.null(d$volume_m3)) sum(d$volume_m3 * e, na.rm = TRUE) else NA_real_
    bio_ha  <- if (!is.null(d$biomass_kg)) sum(d$biomass_kg * e, na.rm = TRUE) else NA_real_
    # Shannon
    props <- table(d$species); props <- props / sum(props)
    shannon <- -sum(props * log(props), na.rm = TRUE)
    simpson <- 1 - sum(props^2)
    data.frame(
      level_value      = unique(d[[grp_col]]),
      n_trees          = n_trees,
      n_live           = n_live,
      n_species        = length(sp),
      basal_area_m2_ha = ba_sum,
      volume_m3_ha     = vol_ha,
      biomass_kg_ha    = bio_ha,
      mean_dbh_cm      = mean(d$dbh_cm,  na.rm = TRUE),
      sd_dbh_cm        = stats::sd(d$dbh_cm, na.rm = TRUE),
      mean_height_m    = mean(d$height_m,na.rm = TRUE),
      shannon_H        = shannon,
      simpson_D1       = simpson,
      stringsAsFactors = FALSE
    )
  }))
  colnames(out)[1L] <- grp_col

  # Plot-level SE / CI of basal area
  out$basal_area_m2_ha_se <- NA_real_
  out$basal_area_m2_ha_lower <- NA_real_
  out$basal_area_m2_ha_upper <- NA_real_

  attr(out, "method") <- sprintf("plot_summary(expansion=%s, level=%s)",
                                 expansion, level)
  attr(out, "units")  <- "ha-based; basal area in m2/ha, volume in m3/ha, biomass in kg/ha"
  attr(out, "parameter_source") <- "calculated"
  class(out) <- c("forestr2_result", class(out))
  out
}

#' Stand-level summary
#'
#' Wrapper around [plot_summary()] with `level = "stand"`, plus plot-level
#' aggregation across stands.
#'
#' @inheritParams plot_summary
#' @export
stand_summary <- function(inv,
                          expansion = c("fixed_area","explicit","basal_area_factor")) {
  plot_summary(inv, expansion = expansion, level = "stand")
}
