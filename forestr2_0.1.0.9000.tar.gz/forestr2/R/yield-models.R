# ----------------------------------------------------------------------------
# forestr2: growth and yield modeling
#
# Functions:
#   - site_index()           : site index from height-age pairs
#   - fit_growth_model()     : fit Chapman-Richards, Gompertz, logistic,
#                              von Bertalanffy, Schumacher, Hossfeld, etc.
#   - predict_growth()       : project growth to a target age
#   - self_thinning()        : Reineke SDMax line
#   - mortality()            : simple mortality models
#   - simulate_stand()       : lightweight stand simulator
#
# Every default parameter with a single canonical value carries a
# TODO(scientific-review) marker in source.
# ----------------------------------------------------------------------------

# ---- Growth function library -----------------------------------------------

#' Library of growth function forms
#'
#' Returns a named list of self-starting growth functions used by
#' [fit_growth_model()]. Each entry is a list with `f` (the function) and
#' `pnames` (parameter names) and `start` (a default starting-value generator).
#'
#' Supported forms:
#'
#' - `chapman_richards`: `Asym * (1 - exp(-k * age))^p`
#' - `gompertz`:         `Asym * exp(-exp(-k * (age - t0)))`
#' - `logistic`:         `Asym / (1 + exp(-k * (age - t0)))`
#' - `von_bertalanffy`:  `Asym * (1 - exp(-k * age))`
#' - `schumacher`:       `Asym * exp(-b / age)`
#' - `hossfeld`:         `Asym * age^p / (b + age^p)`
#' - `weibull`:          `Asym * (1 - exp(-(age/b)^p))`
#' - `richards`:         same as Chapman-Richards (alias)
#'
#' @return named list.
#' @references
#' Chapman, D. G. (1961). Statistical problems in dynamics of exploited
#' fisheries populations. *Proceedings of the Fourth Berkeley Symposium on
#' Mathematical Statistics and Probability*, 4, 153-168.
#'
#' Richards, F. J. (1959). A flexible growth function for empirical use.
#' *Journal of Experimental Botany*, 10(2), 290-301.
#' \doi{10.1093/jxb/10.2.290}
#'
#' Von Bertalanffy, L. (1938). A quantitative theory of organic growth.
#' *Human Biology*, 10(2), 181-213.
#'
#' Winsor, S. B. (1932). The Gompertz curve as a growth curve.
#' *Proceedings of the National Academy of Sciences*, 18(1), 1-8.
#' \doi{10.1073/pnas.18.1.1}
#' @export
#' @examples
#' names(growth_function_library())
growth_function_library <- function() {
  list(
    chapman_richards = list(
      f = function(age, Asym, k, p) Asym * (1 - exp(-k * age))^p,
      pnames = c("Asym","k","p"),
      start  = function(data) c(Asym = max(data$y, na.rm = TRUE) * 1.1,
                                k = 0.05, p = 1.5)
    ),
    gompertz = list(
      f = function(age, Asym, k, t0) Asym * exp(-exp(-k * (age - t0))),
      pnames = c("Asym","k","t0"),
      start  = function(data) c(Asym = max(data$y, na.rm = TRUE) * 1.1,
                                k = 0.1, t0 = 10)
    ),
    logistic = list(
      f = function(age, Asym, k, t0) Asym / (1 + exp(-k * (age - t0))),
      pnames = c("Asym","k","t0"),
      start  = function(data) c(Asym = max(data$y, na.rm = TRUE) * 1.1,
                                k = 0.1, t0 = 10)
    ),
    von_bertalanffy = list(
      f = function(age, Asym, k) Asym * (1 - exp(-k * age)),
      pnames = c("Asym","k"),
      start  = function(data) c(Asym = max(data$y, na.rm = TRUE) * 1.1,
                                k = 0.05)
    ),
    schumacher = list(
      f = function(age, Asym, b) Asym * exp(-b / age),
      pnames = c("Asym","b"),
      start  = function(data) c(Asym = max(data$y, na.rm = TRUE) * 1.1,
                                b = 20)
    ),
    hossfeld = list(
      f = function(age, Asym, b, p) Asym * age^p / (b + age^p),
      pnames = c("Asym","b","p"),
      start  = function(data) c(Asym = max(data$y, na.rm = TRUE) * 1.1,
                                b = 100, p = 2)
    ),
    weibull = list(
      f = function(age, Asym, b, p) Asym * (1 - exp(-(age/b)^p)),
      pnames = c("Asym","b","p"),
      start  = function(data) c(Asym = max(data$y, na.rm = TRUE) * 1.1,
                                b = 20, p = 2)
    ),
    richards = list(  # alias of Chapman-Richards
      f = function(age, Asym, k, p) Asym * (1 - exp(-k * age))^p,
      pnames = c("Asym","k","p"),
      start  = function(data) c(Asym = max(data$y, na.rm = TRUE) * 1.1,
                                k = 0.05, p = 1.5)
    )
  )
}

# ---- Site index -------------------------------------------------------------

#' Compute site index from a height-age pair
#'
#' Uses anamorphic or polymorphic site curves. Default base age is 50 years.
#'
#' @param height_m observed top height (m).
#' @param age_yr observed stand age (years).
#' @param base_age_yr reference age; default 50.
#' @param model character; one of `c("chapman_richards","schumacher")`.
#' @param params named numeric vector of model parameters. If NULL, a
#'   placeholder Chapman-Richards parameterization is used
#'   (**TODO(scientific-review)**).
#' @return numeric scalar site index (predicted top height at `base_age_yr`).
#' @export
#' @examples
#' site_index(height_m = 18, age_yr = 30)
site_index <- function(height_m, age_yr, base_age_yr = 50,
                       model = c("chapman_richards","schumacher"),
                       params = NULL) {
  model <- match.arg(model)
  if (length(height_m) != 1L || length(age_yr) != 1L) {
    stop("`height_m` and `age_yr` must be scalar.", call. = FALSE)
  }
  if (age_yr <= 0 || height_m <= 0) {
    stop("`height_m` and `age_yr` must be positive.", call. = FALSE)
  }
  if (model == "chapman_richards") {
    if (is.null(params)) {
      params <- c(Asym = 35, k = 0.04, p = 1.5)
      warn_review_placeholder("chapman_richards params",
                              paste(params, collapse = ","),
                              "forestr2 placeholder (species-specific review required)")
    }
    f <- growth_function_library()$chapman_richards$f
    h_base <- f(base_age_yr, Asym = params["Asym"], k = params["k"], p = params["p"])
    h_obs  <- f(age_yr,      Asym = params["Asym"], k = params["k"], p = params["p"])
    # Anamorphic scaling
    si <- height_m * h_base / h_obs
  } else if (model == "schumacher") {
    if (is.null(params)) {
      params <- c(Asym = 35, b = 20)
      warn_review_placeholder("schumacher params",
                              paste(params, collapse = ","),
                              "forestr2 placeholder (species-specific review required)")
    }
    f <- growth_function_library()$schumacher$f
    h_base <- f(base_age_yr, Asym = params["Asym"], b = params["b"])
    h_obs  <- f(age_yr,      Asym = params["Asym"], b = params["b"])
    si <- height_m * h_base / h_obs
  }
  unname(si)
}

# ---- fit_growth_model -------------------------------------------------------

#' Fit a growth-and-yield model
#'
#' Fits one of the forms in [growth_function_library()] to age-vs-size data
#' (height, dbh, basal area, volume per ha, etc.).
#'
#' @param data data frame containing columns `age_yr` and `y`.
#' @param age_var character; column name for age. Default `"age_yr"`.
#' @param y_var character; column name for the response. Default `"y"`.
#' @param model character; one of the names returned by
#'   [growth_function_library()].
#' @param start optional named vector of starting values; if NULL, the form's
#'   `start` function is used.
#' @param weights optional case weights.
#' @param cv integer; folds for cross-validation.
#'
#' @return object of class `forestr2_growth_model`.
#' @export
#' @examples
#' \dontrun{
#' d <- data.frame(age_yr = c(5,10,15,20,25,30,35,40),
#'                 y = c(3,6,9,12,15,17,18,19))
#' m <- fit_growth_model(d, model = "chapman_richards")
#' predict_growth(m, age_yr = c(45, 50))
#' }
fit_growth_model <- function(data, age_var = "age_yr", y_var = "y",
                             model = c("chapman_richards","gompertz",
                                       "logistic","von_bertalanffy",
                                       "schumacher","hossfeld","weibull",
                                       "richards"),
                             start = NULL, weights = NULL, cv = 0L) {
  model <- match.arg(model)
  if (!is.data.frame(data)) stop("`data` must be a data.frame.", call. = FALSE)
  if (!age_var %in% names(data)) stop(sprintf("`%s` not in `data`.", age_var), call. = FALSE)
  if (!y_var   %in% names(data)) stop(sprintf("`%s` not in `data`.", y_var), call. = FALSE)
  age <- data[[age_var]]
  y   <- data[[y_var]]
  if (!is.numeric(age) || !is.numeric(y)) {
    stop("Age and response must be numeric.", call. = FALSE)
  }
  lib <- growth_function_library()[[model]]
  if (is.null(lib)) stop("Unknown model: ", model, call. = FALSE)
  if (is.null(start)) {
    start <- lib$start(data.frame(y = y))
  }
  # Build nls call using the form's parameter names (works for 2- and 3-param forms).
  f <- lib$f
  pnames <- lib$pnames
  # Construct the RHS expression as a call to f(age, ...).
  fmla_str <- paste0("y ~ f(age, ", paste(pnames, collapse = ", "), ")")
  fmla <- as.formula(fmla_str)
  start_use <- start[pnames]
  fit <- stats::nls(fmla,
                    data = data.frame(y = y, age = age),
                    start = start_use,
                    weights = weights)
  preds <- as.numeric(stats::predict(fit))
  resid <- y - preds
  metrics <- list(
    rmse = sqrt(mean(resid^2, na.rm = TRUE)),
    mae  = mean(abs(resid), na.rm = TRUE),
    bias = mean(resid, na.rm = TRUE),
    r2   = 1 - sum(resid^2, na.rm = TRUE) /
              sum((y - mean(y, na.rm = TRUE))^2, na.rm = TRUE),
    aic  = tryCatch(stats::AIC(fit), error = function(e) NA_real_),
    n    = nrow(data)
  )
  cv_metrics <- NULL
  if (cv >= 2L && nrow(data) >= cv) {
    folds <- sample(rep(seq_len(cv), length.out = nrow(data)))
    preds_cv <- rep(NA_real_, nrow(data))
    for (k in seq_len(cv)) {
      train <- folds != k; test <- folds == k
      if (sum(train) < 3L || sum(test) == 0L) next
      fit_k <- tryCatch(
        stats::nls(fmla,
                   data = data.frame(y = y, age = age)[train, ],
                   start = start_use),
        error = function(e) NULL
      )
      if (is.null(fit_k)) next
      preds_cv[test] <- as.numeric(stats::predict(fit_k,
                                newdata = data.frame(age = age[test])))
    }
    r_cv <- y - preds_cv
    cv_metrics <- list(
      rmse = sqrt(mean(r_cv^2, na.rm = TRUE)),
      mae  = mean(abs(r_cv), na.rm = TRUE),
      bias = mean(r_cv, na.rm = TRUE)
    )
  }
  structure(
    list(fit = fit, model = model, pnames = lib$pnames,
         formula_form = deparse(body(lib$f)),
         metrics = metrics, cv_metrics = cv_metrics,
         parameter_source = "user-supplied data; forestr2 placeholder start values"),
    class = "forestr2_growth_model"
  )
}

#' Predict from a fitted growth model
#'
#' @param object a `forestr2_growth_model`.
#' @param age_yr numeric vector of ages to project to.
#' @param interval character; one of `c("none","confidence","prediction")`.
#' @param level numeric; default 0.95.
#' @return data frame with `age_yr`, `predicted`, and optionally `lower`/`upper`.
#' @export
predict_growth <- function(object, age_yr,
                           interval = c("none","confidence","prediction"),
                           level = 0.95) {
  if (!inherits(object, "forestr2_growth_model")) {
    stop("`object` must be a forestr2_growth_model.", call. = FALSE)
  }
  interval <- match.arg(interval)
  newdata <- data.frame(age = age_yr)
  preds <- as.numeric(stats::predict(object$fit, newdata = newdata))
  out <- data.frame(age_yr = age_yr, predicted = preds)
  if (interval != "none") {
    # nls does not provide se.fit directly. Use residual standard error
    # as a rough approximation; for production intervals, use bootstrap.
    rss <- sum(resid(object$fit)^2, na.rm = TRUE)
    rdf <- object$metrics$n - length(stats::coef(object$fit))
    se_resid <- sqrt(rss / rdf)
    se_pred <- se_resid  # rough: residual-only, no leverage adjustment
    tcrit <- stats::qt((1 + level) / 2, df = rdf)
    out$lower <- preds - tcrit * se_pred
    out$upper <- preds + tcrit * se_pred
  }
  out
}

#' @describeIn predict_growth Print method
#' @param x a `forestr2_growth_model`.
#' @export
print.forestr2_growth_model <- function(x, ...) {
  cat("<forestr2_growth_model>\n")
  cat("model form:", x$model, "\n")
  cat("form:", x$formula_form, "\n")
  cat("parameters:\n"); print(stats::coef(x$fit))
  cat("metrics:\n"); print(x$metrics)
  if (!is.null(x$cv_metrics)) {
    cat("cross-validation metrics:\n"); print(x$cv_metrics)
  }
  invisible(x)
}

# ---- Self-thinning (Reineke) ------------------------------------------------

#' Reineke self-thinning line
#'
#' Returns the maximum stand density (trees per hectare) for a given quadratic
#' mean DBH according to Reineke's SDImax rule: `N = SDImax * (dbh_q/25)^(-1.605)`.
#'
#' @param dbh_q_cm quadratic mean DBH (cm).
#' @param sdimax numeric; maximum stand density index. Default 450
#'   (**TODO(scientific-review)** species-specific).
#' @param exponent numeric; Reineke exponent. Default -1.605.
#' @return numeric scalar N (trees/ha).
#' @references
#' Reineke, L. H. (1933). Perfecting a stand-density index for even-aged forests.
#' *Journal of Agricultural Research*, 46(7), 627-638.
#' @export
#' @examples
#' self_thinning(dbh_q_cm = 25)
self_thinning <- function(dbh_q_cm, sdimax = 450, exponent = -1.605) {
  if (length(dbh_q_cm) != 1L) stop("`dbh_q_cm` must be scalar.", call. = FALSE)
  if (dbh_q_cm <= 0) stop("`dbh_q_cm` must be positive.", call. = FALSE)
  warn_review_placeholder("sdimax", sdimax,
                          "forestr2 placeholder default 450 (species-specific review)")
  sdimax * (dbh_q_cm / 25)^exponent
}

# ---- Mortality --------------------------------------------------------------

#' Simple annual mortality
#'
#' Applies a constant annual mortality rate to a stand. **TODO(scientific-review)**:
#' operational mortality models require species, stand density, and stress
#' covariates.
#'
#' @param n0 initial stocking (trees/ha).
#' @param annual_rate numeric; annual proportion dying. Default 0.01.
#' @param years integer; projection horizon.
#' @return numeric scalar surviving trees per hectare.
#' @export
#' @examples
#' mortality(n0 = 1000, annual_rate = 0.01, years = 10)
mortality <- function(n0, annual_rate = 0.01, years = 1L) {
  if (n0 <= 0) stop("`n0` must be positive.", call. = FALSE)
  if (annual_rate < 0 || annual_rate >= 1) stop("`annual_rate` must be in [0,1).", call. = FALSE)
  if (years < 1) stop("`years` must be >= 1.", call. = FALSE)
  warn_review_placeholder("annual_rate", annual_rate,
                          "forestr2 placeholder constant-rate mortality")
  n0 * (1 - annual_rate)^years
}

# ---- Stand simulator --------------------------------------------------------

#' Lightweight stand simulator
#'
#' A minimal, transparent simulator that projects stocking, basal area, and
#' volume using simple increment and mortality assumptions. Designed for
#' sensitivity analysis, not operational yield forecasting.
#'
#' @param initial list with `n_ha`, `ba_m2_ha`, `volume_m3_ha`, `age_yr`.
#' @param years integer; projection horizon.
#' @param annual_ba_increment_pct numeric; default 0.03 (3%/yr).
#' @param annual_mortality_rate numeric; default 0.01.
#' @param volume_ba_ratio numeric; volume/basal area. Default 5
#'   (**TODO(scientific-review)**).
#' @return data frame of state at each year (class `forestr2_result`).
#' @export
#' @examples
#' simulate_stand(initial = list(n_ha = 1000, ba_m2_ha = 25,
#'                               volume_m3_ha = 125, age_yr = 25),
#'                years = 10)
simulate_stand <- function(initial,
                           years = 10L,
                           annual_ba_increment_pct = 0.03,
                           annual_mortality_rate = 0.01,
                           volume_ba_ratio = 5) {
  for (nm in c("n_ha","ba_m2_ha","volume_m3_ha","age_yr")) {
    if (is.null(initial[[nm]])) stop(sprintf("`initial$%s` is required.", nm), call. = FALSE)
  }
  warn_review_placeholder("volume_ba_ratio", volume_ba_ratio,
                          "forestr2 placeholder")
  out <- data.frame(year = 0:years,
                    age_yr = initial$age_yr + 0:years,
                    n_ha = NA_real_,
                    ba_m2_ha = NA_real_,
                    volume_m3_ha = NA_real_)
  n  <- initial$n_ha
  ba <- initial$ba_m2_ha
  v  <- initial$volume_m3_ha
  out$n_ha[1L]        <- n
  out$ba_m2_ha[1L]    <- ba
  out$volume_m3_ha[1L] <- v
  for (i in seq_len(years)) {
    n  <- n  * (1 - annual_mortality_rate)
    ba <- ba * (1 + annual_ba_increment_pct)
    v  <- ba * volume_ba_ratio
    out$n_ha[i + 1L]        <- n
    out$ba_m2_ha[i + 1L]    <- ba
    out$volume_m3_ha[i + 1L] <- v
  }
  attr(out, "method") <- "simple deterministic stand simulator"
  attr(out, "parameter_source") <- sprintf(
    "ba_increment=%g/yr; mortality=%g/yr; volume_ba_ratio=%g (forestr2 placeholders)",
    annual_ba_increment_pct, annual_mortality_rate, volume_ba_ratio)
  class(out) <- c("forestr2_result", class(out))
  out
}
