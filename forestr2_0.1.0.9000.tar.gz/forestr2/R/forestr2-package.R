#' forestr2: Forest Inventory, Silviculture, Growth and Yield, and Experimental Forestry
#'
#' A modular, unit-aware R ecosystem for forest inventory, silviculture,
#' growth and yield, biodiversity, and experimental forestry. The package
#' provides documented constructors and validators for tree, plot, stand,
#' and repeated-measurement data; inventory summaries and design-based
#' estimators with explicit expansion factors; volume, biomass, carbon,
#' density, stocking, and diversity metrics; accessible experimental-design
#' and treatment-comparison workflows; and individual-tree and stand-level
#' growth and yield modeling.
#'
#' @section Design principles:
#'
#' - **Units are never inferred.** Functions declare expected units
#'   (`dbh_cm`, `height_m`, `plot_area_ha`, ...) and validate that inputs
#'   are physically plausible.
#' - **Estimators are documented.** Every plot/stand estimator reports the
#'   formula, expansion factor, standard-error convention, and units.
#' - **Production equations are flagged for review.** Defaults carry a
#'   `TODO(scientific-review)` marker and a `parameter_source` field.
#' - **Minimal mandatory dependencies.** Core depends only on base-recommended
#'   packages; `ggplot2`, `dplyr`, `nlme`, `lme4`, `emmeans`, and `multcomp`
#'   are *Suggests* and used opportunistically.
#' - **Companion packages are first-class extension points.** `forestr2.spatial`,
#'   `forestr2.growth`, `forestr2.design`, `forestr2.visuals` are reserved
#'   namespaces; the core package never imports from them.
#'
#' @section Core API:
#'
#' - **Data model:** [tree_inventory()], [plot_summary()], [stand_summary()],
#'   [repeated_measurements()]
#' - **Volume:** [calc_tree_volume()], [calc_stem_section_volume()],
#'   [calc_log_volume()], [calc_merchantable_volume()],
#'   [calc_volume_by_plot()], [calc_volume_by_stand()],
#'   [fit_volume_model()], [predict_volume()]
#' - **Biomass & carbon:** [calc_tree_biomass()], [calc_component_biomass()],
#'   [calc_aboveground_biomass()], [calc_belowground_biomass()],
#'   [calc_total_biomass()], [calc_carbon_stock()], [calc_co2e()],
#'   [fit_biomass_model()], [predict_biomass()]
#' - **Growth & yield:** [fit_growth_model()], [predict_growth()],
#'   [site_index()], [simulate_stand()]
#' - **Experimental design:** [aov_forestr2()], [cld_forestr2()]
#'
#' @section Companion packages (planned, optional):
#'
#' - `forestr2.data` - redistributable datasets and data dictionaries
#' - `forestr2.spatial` - sf/terra/LiDAR workflows
#' - `forestr2.growth` - advanced growth/yield and GAD models
#' - `forestr2.design` - specialized trial designs
#' - `forestr2.visuals` - forestry-specific graphics
#'
#' @section Disclaimer:
#'
#' Default form factors, wood densities, carbon fractions, and allometric
#' coefficients in this package are **scientific placeholders** carrying a
#' `TODO(scientific-review)` marker in source. They must be validated against
#' region- and species-specific literature before being used for operational
#' decisions, carbon reporting, or publication. See `vignette("forestr2-workflow")`
#' for guidance on supplying your own parameter tables.
#'
#' @importFrom stats aggregate coef confint df residuals lm glm nls predict
#' @importFrom stats qnorm qt na.omit sd var median quantile weighted.mean
#' @importFrom stats reformulate model.matrix model.frame terms update formula
#' @importFrom stats pnorm setNames AIC rnorm
#' @importFrom utils data head tail read.csv write.csv packageVersion
#' @importFrom utils sessionInfo str
#' @importFrom methods is as new
#' @importFrom graphics plot
#' @importFrom grDevices rgb
#' @keywords internal
"_PACKAGE"

# The following block prevents R CMD check notes for imported-but-not-used
# symbols; they are used by downstream R/ files.
utils::globalVariables(character(0))

#' forestr2 package options
#'
#' Set or query package-wide options. Currently honored options:
#'
#' - `forestr2.units_volume`   : default volume unit (`"m3"`, default).
#' - `forestr2.units_biomass`  : default biomass unit (`"kg"`, default).
#' - `forestr2.units_carbon`   : default carbon unit (`"kg"`, default).
#' - `forestr2.carbon_fraction`: default carbon fraction (`0.47`).
#' - `forestr2.co2e_ratio`     : molecular-weight ratio C -> CO2e (`44/12`).
#' - `forestr2.form_factor`    : default form factor (`0.45`, placeholder).
#' - `forestr2.strict_units`   : logical, stop on unit mismatch (default `TRUE`).
#' - `forestr2.review_warnings`: logical, warn on placeholder parameters (default `TRUE`).
#'
#' @param ... named options to set, or a single character name to query.
#' @return A list of current option values (invisibly when setting).
#' @export
#' @examples
#' forestr2_options()
#' forestr2_options("forestr2.carbon_fraction")
forestr2_options <- function(...) {
  opts <- list(
    forestr2.units_volume    = "m3",
    forestr2.units_biomass   = "kg",
    forestr2.units_carbon    = "kg",
    forestr2.carbon_fraction = 0.47,
    forestr2.co2e_ratio      = 44 / 12,
    forestr2.form_factor     = 0.45,
    forestr2.strict_units    = TRUE,
    forestr2.review_warnings = TRUE
  )
  stored <- getOption("forestr2.options", list())
  merged <- modifyList(opts, stored)
  args <- list(...)
  if (length(args) == 0L) return(invisible(merged))
  if (length(args) == 1L && is.character(args[[1L]]) && !is.null(args[[1L]])) {
    return(merged[[args[[1L]]]])
  }
  # set
  stored <- modifyList(stored, args)
  options(forestr2.options = stored)
  invisible(modifyList(merged, stored))
}

#' Emit a scientific-review warning for a placeholder parameter
#'
#' Internal helper. Emits a warning of class `forestr2_review_warning` so
#' callers can suppress them programmatically. The warning is emitted at most
#' once per session per parameter (controlled by an environment).
#'
#' @param parameter character scalar naming the parameter (e.g. `"form_factor"`).
#' @param value numeric or character scalar; the default being applied.
#' @param source character scalar; provenance string.
#' @keywords internal
#' @noRd
warn_review_placeholder <- function(parameter, value, source) {
  if (!isTRUE(forestr2_options("forestr.review_warnings"))) return(invisible())
  env <- warn_review_env
  key <- paste(parameter, source, sep = "::")
  if (!is.null(env[[key]])) return(invisible())
  env[[key]] <- TRUE
  warning(
    "forestr2 placeholder parameter `", parameter, " = ", value,
    "` applied. Source: ", source,
    ". This default is a scientific placeholder and must be reviewed",
    " against region- and species-specific literature before operational use.",
    call. = FALSE, noBreaks. = TRUE
  )
}

warn_review_env <- new.env(parent = emptyenv())
