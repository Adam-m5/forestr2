# ----------------------------------------------------------------------------
# forestr2: utility helpers (validation, units, NA handling)
# ----------------------------------------------------------------------------

# ---- NA handling ------------------------------------------------------------

#' Resolve a `missing` argument
#'
#' Matches a user-supplied `missing` argument against
#' `c("error","warn","return_na")` and returns the canonical string.
#'
#' @param missing character scalar, partial matching allowed.
#' @return canonical string, one of `c("error","warn","return_na")`.
#' @keywords internal
#' @noRd
resolve_missing_policy <- function(missing) {
  if (is.null(missing)) missing <- "error"
  missing <- tryCatch(
    match.arg(missing, c("error", "warn", "return_na")),
    error = function(e) {
      stop("`missing` must be one of c('error','warn','return_na').",
           call. = FALSE)
    }
  )
  missing
}

#' Apply the missing-value policy to a logical mask
#'
#' @param mask logical vector; TRUE where input is invalid/missing.
#' @param varname character scalar; name to use in error/warn messages.
#' @param policy character scalar returned by [resolve_missing_policy()].
#' @return invisible(logical) same length as `mask`; TRUE where the result
#'   should be `NA`.
#' @keywords internal
#' @noRd
apply_missing_policy <- function(mask, varname, policy) {
  if (!any(mask)) return(invisible(!logical(length(mask))))
  msg <- paste0("Missing or non-finite values in `", varname, "`: ",
                sum(mask), " of ", length(mask), " observations.")
  if (policy == "error") {
    stop(msg, call. = FALSE)
  } else if (policy == "warn") {
    warning(msg, call. = FALSE)
  }
  mask
}

# ---- Numeric validation -----------------------------------------------------

#' Coerce to finite numeric with unit and sign checks
#'
#' @param x vector.
#' @param name character scalar; argument name for messages.
#' @param allow_negative logical; default FALSE.
#' @param allow_zero logical; default FALSE.
#' @param allow_na logical; default FALSE (handled by missing policy upstream).
#' @param min_val,max_val optional numeric bounds (inclusive).
#' @return numeric vector.
#' @keywords internal
#' @noRd
as_finite_numeric <- function(x, name = "x", allow_negative = FALSE,
                              allow_zero = FALSE, allow_na = FALSE,
                              min_val = NULL, max_val = NULL) {
  if (is.null(x)) return(NULL)
  if (!is.numeric(x)) {
    stop(sprintf("`%s` must be numeric; got %s.", name,
                 paste(class(x), collapse = "/")),
         call. = FALSE)
  }
  if (length(x) == 0L) return(numeric(0))
  if (!allow_na && anyNA(x)) {
    stop(sprintf("`%s` contains NA values; use the `missing` policy to handle.",
                 name), call. = FALSE)
  }
  if (!is.null(min_val) && !all(is.na(x[x >= min_val | is.na(x)]))) {
    # placeholder for clarity
  }
  bad <- is.infinite(x) & !is.na(x)
  if (any(bad)) {
    stop(sprintf("`%s` contains Inf values.", name), call. = FALSE)
  }
  if (!allow_negative) {
    neg <- !is.na(x) & x < 0
    if (any(neg)) {
      stop(sprintf("`%s` contains negative values: %d of %d.",
                   name, sum(neg), length(x)),
           call. = FALSE)
    }
  }
  if (!allow_zero) {
    zero <- !is.na(x) & x == 0
    if (any(zero)) {
      stop(sprintf("`%s` contains zero values, which are not allowed here: %d of %d.",
                   name, sum(zero), length(x)),
           call. = FALSE)
    }
  }
  if (!is.null(min_val)) {
    und <- !is.na(x) & x < min_val
    if (any(und)) {
      stop(sprintf("`%s` contains values below the allowed minimum (%g).",
                   name, min_val), call. = FALSE)
    }
  }
  if (!is.null(max_val)) {
    ovr <- !is.na(x) & x > max_val
    if (any(ovr)) {
      stop(sprintf("`%s` contains values above the allowed maximum (%g).",
                   name, max_val), call. = FALSE)
    }
  }
  as.numeric(x)
}

# ---- Length matching --------------------------------------------------------

#' Recycle or validate length
#'
#' Allows scalar-to-vector recycling. Stops on incompatible lengths.
#'
#' @param x vector.
#' @param n integer scalar; expected length.
#' @param name character scalar; argument name.
#' @return x recycled to length n.
#' @keywords internal
#' @noRd
match_length <- function(x, n, name = "x") {
  if (is.null(x)) return(rep(NA_real_, n))
  if (length(x) == 1L && n > 1L) return(rep(x, n))
  if (length(x) != n) {
    stop(sprintf("`%s` has length %d but expected %d (or 1 for recycling).",
                 name, length(x), n), call. = FALSE)
  }
  x
}

# ---- Data frame helpers -----------------------------------------------------

#' Require a column to exist in a data frame
#'
#' @param data data.frame.
#' @param col character scalar.
#' @keywords internal
#' @noRd
require_col <- function(data, col) {
  if (!is.data.frame(data)) {
    stop("`data` must be a data.frame.", call. = FALSE)
  }
  if (!col %in% names(data)) {
    stop(sprintf("Column '%s' not found in `data`. Available: %s",
                 col, paste(names(data), collapse = ", ")),
         call. = FALSE)
  }
}

#' Extract a column or substitute a vector
#'
#' If `vec` is NULL, pull from `data[[colname]]`; otherwise use `vec`.
#'
#' @keywords internal
#' @noRd
resolve_vec <- function(vec, data, colname, n = NULL) {
  if (!is.null(vec)) {
    if (is.null(n)) n <- length(vec)
    return(match_length(vec, n, colname))
  }
  if (is.null(data)) return(NULL)
  require_col(data, colname)
  if (is.null(n)) n <- nrow(data)
  match_length(data[[colname]], n, colname)
}

# ---- Result assembly --------------------------------------------------------

#' Return a data frame of results preserving identifiers
#'
#' @param data the input data frame (or NULL).
#' @param ids identifier columns to preserve (named list or NULL).
#' @param results named list of result columns.
#' @param attrs named list of attributes to attach (e.g. method, units).
#' @return data.frame with `forestr2_result` class.
#' @keywords internal
#' @noRd
as_forestr2_result_df <- function(data, ids, results, attrs) {
  if (!is.null(data)) {
    base <- data[, colnames(data) %in% names(ids), drop = FALSE]
  } else {
    base <- as.data.frame(ids, stringsAsFactors = FALSE)
  }
  if (!is.null(ids) && !is.null(data)) {
    # ensure id columns explicitly chosen from data
    id_df <- data[, names(ids), drop = FALSE]
  } else if (!is.null(ids)) {
    id_df <- as.data.frame(ids, stringsAsFactors = FALSE)
  } else {
    id_df <- NULL
  }
  out <- cbind(id_df, as.data.frame(results, stringsAsFactors = FALSE))
  if (!is.null(attrs)) {
    for (nm in names(attrs)) attr(out, nm) <- attrs[[nm]]
  }
  class(out) <- c("forestr2_result", class(out))
  out
}

#' Format a numeric vector with a sensible number of significant digits
#'
#' @param x numeric.
#' @param digits integer scalar; default 4.
#' @return character vector.
#' @export
#' @examples
#' format_sig(c(0.123456, 1.23456, 12.3456))
format_sig <- function(x, digits = 4L) {
  if (!is.numeric(x)) return(as.character(x))
  out <- signif(x, digits = digits)
  out <- format(out, scientific = FALSE, trim = TRUE, big.mark = "")
  out
}

#' Print method for forestr2_result
#'
#' @param x an object inheriting from `forestr2_result`.
#' @param ... passed to `print.data.frame`.
#' @export
print.forestr2_result <- function(x, ...) {
  if (!is.null(attr(x, "method"))) {
    cat(sprintf("<forestr2 result> method: %s\n", attr(x, "method")))
  }
  if (!is.null(attr(x, "units"))) {
    cat(sprintf("units: %s\n", attr(x, "units")))
  }
  if (!is.null(attr(x, "parameter_source"))) {
    cat(sprintf("parameter source: %s\n", attr(x, "parameter_source")))
  }
  NextMethod("print")
  invisible(x)
}

# ---- Coefficient table helpers ----------------------------------------------

#' Coerce a coefficient lookup table to a canonical form
#'
#' Accepts either:
#'   - a named numeric vector (species -> value), or
#'   - a data frame with columns `species` and one or more value columns.
#'
#' @param coef_tbl named numeric vector or data.frame.
#' @param key_col character; column to match `species` against. Default
#'   `species`. Ignored for named-vector input.
#' @return list with `$type` (one of "named","data.frame"), `$data`.
#' @keywords internal
#' @noRd
normalize_coef_table <- function(coef_tbl, key_col = "species") {
  if (is.null(coef_tbl)) {
    return(list(type = "NULL", data = NULL))
  }
  if (is.numeric(coef_tbl) && length(coef_tbl) == 1L) {
    # Scalar numeric: treat as a constant (no species lookup)
    return(list(type = "scalar", data = coef_tbl,
                key_col = NA_character_))
  }
  if (is.numeric(coef_tbl) && !is.null(names(coef_tbl))) {
    return(list(type = "named", data = coef_tbl,
                key_col = NA_character_))
  }
  if (is.data.frame(coef_tbl)) {
    if (!key_col %in% names(coef_tbl)) {
      stop(sprintf("coefficient table must have a '%s' column.", key_col),
           call. = FALSE)
    }
    return(list(type = "data.frame", data = as.data.frame(coef_tbl),
                key_col = key_col))
  }
  stop("`coefficients` must be a named numeric vector or a data frame.",
       call. = FALSE)
}

#' Look up a species-specific value
#'
#' @param sp character vector of species.
#' @param coef normalized coefficient lookup (from [normalize_coef_table()]).
#' @param value_col for data.frame lookups, the column to pull.
#' @param default default value when species not found.
#' @return numeric vector.
#' @keywords internal
#' @noRd
lookup_species_value <- function(sp, coef, value_col, default = NA_real_) {
  if (is.null(coef) || coef$type == "NULL") {
    return(rep(default, length(sp)))
  }
  if (coef$type == "named") {
    return(unname(coef$data[sp]))
  }
  # data.frame
  idx <- match(sp, coef$data[[coef$key_col]])
  out <- coef$data[[value_col]][idx]
  out[is.na(out)] <- default
  out
}

# ---- Misc -------------------------------------------------------------------

#' Pipe-friendly assertion: stop if FALSE
#'
#' @param cond logical scalar.
#' @param msg character scalar.
#' @keywords internal
#' @noRd
stop_if_not <- function(cond, msg) {
  if (!isTRUE(cond)) stop(msg, call. = FALSE)
}

#' Standard error
#'
#' @param x numeric vector.
#' @param na.rm logical; default TRUE.
#' @return numeric scalar (NA if fewer than 2 non-NA obs).
#' @export
#' @examples
#' se_value(1:10)
se_value <- function(x, na.rm = TRUE) {
  if (length(x) < 2L) return(NA_real_)
  stats::sd(x, na.rm = na.rm) / sqrt(sum(!is.na(x)))
}

#' Confidence interval (t-based) for a vector
#'
#' @param x numeric vector.
#' @param level numeric scalar in (0,1); default 0.95.
#' @param na.rm logical; default TRUE.
#' @return numeric vector of length 2 (`lower`,`upper`).
#' @export
#' @examples
#' ci_vector(rnorm(20))
ci_vector <- function(x, level = 0.95, na.rm = TRUE) {
  x <- x[!is.na(x)]
  n <- length(x)
  if (n < 2L) return(c(lower = NA_real_, upper = NA_real_))
  mu <- mean(x)
  s <- stats::sd(x)
  t <- stats::qt((1 + level) / 2, df = n - 1)
  c(lower = mu - t * s / sqrt(n), upper = mu + t * s / sqrt(n))
}
