# ----------------------------------------------------------------------------
# forestr2: experimental design and treatment comparison
#
# Inspired by agricolae's accessible workflows, but designed for forestry:
# provenance, nursery, thinning, fertilization, and silvicultural trials.
# Uses base R for ANOVA; uses emmeans / multcomp when installed for EMMs,
# Tukey/Dunnett/Scheffe, and compact letter displays.
# ----------------------------------------------------------------------------

#' ANOVA for forestry trials
#'
#' A convenience wrapper around [stats::aov()] that supports completely
#' randomized designs (CRD), randomized complete block designs (RCBD),
#' factorial designs, split-plot, and repeated-measures (via `Error()` strata).
#'
#' @param formula an R formula. Use `Error()` in the formula for split-plot or
#'   repeated-measures designs (passed to [stats::aov()]).
#' @param data data frame.
#' @param design character; one of `c("crd","rcbd","factorial","split_plot",
#'   "repeated_measures","provenance","nursery","thinning","fertilization")`.
#'   Used for documentation and metadata only; the design is fully encoded in
#'   `formula`.
#' @param contrasts optional list of contrasts.
#'
#' @return object of class `forestr2_aov`, a list with `$aov` (the underlying
#'   `aov` object), `$design`, `$assumptions_doc`.
#' @export
#' @examples
#' d <- data.frame(
#'   yield = c(10,12,11,15,16,14,9,11,10),
#'   treatment = factor(rep(c("A","B","C"), each = 3)),
#'   block = factor(rep(1:3, 3))
#' )
#' a <- aov_forestr2(yield ~ treatment + block, data = d, design = "rcbd")
#' print(a)
aov_forestr2 <- function(formula, data, design = c("crd","rcbd","factorial",
                                                  "split_plot","repeated_measures",
                                                  "provenance","nursery",
                                                  "thinning","fertilization"),
                        contrasts = NULL) {
  design <- match.arg(design)
  if (!is.data.frame(data)) stop("`data` must be a data.frame.", call. = FALSE)
  fit <- stats::aov(formula, data = data, contrasts = contrasts)
  assumptions_doc <- list(
    normality = "Shapiro-Wilk test on residuals; Q-Q plot.",
    homoscedasticity = "Bartlett or Levene test across treatment groups.",
    independence = "Ensured by design; verify randomization.",
    additivity   = "Tukey 1-df test for non-additivity (RCBD).",
    balance      = if (design %in% c("crd","rcbd","factorial"))
                     "Design assumed balanced." else
                     "Design may be unbalanced; consider mixed-effects via lme4."
  )
  structure(
    list(aov = fit, design = design,
         assumptions_doc = assumptions_doc,
         parameter_source = "user-supplied formula"),
    class = "forestr2_aov"
  )
}

#' @describeIn aov_forestr2 Print method
#' @param x a `forestr2_aov` object.
#' @export
print.forestr2_aov <- function(x, ...) {
  cat("<forestr2_aov> design:", x$design, "\n")
  cat("\n--- ANOVA table ---\n")
  print(summary(x$aov))
  cat("\n--- Assumptions to verify ---\n")
  for (nm in names(x$assumptions_doc)) {
    cat(sprintf("  %s: %s\n", nm, x$assumptions_doc[[nm]]))
  }
  invisible(x)
}

#' Estimated marginal means and compact letter displays
#'
#' Uses `emmeans` and `multcomp` when installed. Falls back to a base-R
#' Tukey HSD otherwise. Supports adjustment methods: Tukey, Scheffe, Bonferroni,
#' Holm, Dunnett, LSD, Duncan, Games-Howell.
#'
#' @param aov_obj a `forestr2_aov` object (or an `aov`/`lm` object).
#' @param factor character scalar; the factor to compute means for.
#' @param adjust character; one of `c("tukey","scheffe","bonferroni","holm",
#'   "dunnett","lsd","duncan","games_howell")`.
#' @param level numeric; family-wise confidence level. Default 0.95.
#' @param letters logical; if TRUE, return compact letter display (CLD).
#'
#' @return data frame (class `forestr2_result`) with one row per factor level:
#'   `level`, `emmean`, `SE`, `lower`, `upper`, and (if `letters=TRUE`) `.group`.
#' @export
#' @examples
#' \dontrun{
#' d <- data.frame(
#'   yield = c(10,12,11,15,16,14,9,11,10),
#'   treatment = factor(rep(c("A","B","C"), each = 3)),
#'   block = factor(rep(1:3, 3))
#' )
#' a <- aov_forestr2(yield ~ treatment + block, data = d, design = "rcbd")
#' cld_forestr2(a, factor = "treatment", adjust = "tukey", letters = TRUE)
#' }
cld_forestr2 <- function(aov_obj, factor, adjust = c("tukey","scheffe",
                                                    "bonferroni","holm",
                                                    "dunnett","lsd","duncan",
                                                    "games_howell"),
                        level = 0.95, letters = TRUE) {
  adjust <- match.arg(adjust)
  fit <- if (inherits(aov_obj, "forestr2_aov")) aov_obj$aov else aov_obj
  if (!inherits(fit, c("aov","lm"))) {
    stop("`aov_obj` must be a forestr2_aov or aov/lm object.", call. = FALSE)
  }
  has_emmeans <- requireNamespace("emmeans", quietly = TRUE)
  has_multcomp <- requireNamespace("multcomp", quietly = TRUE)
  if (!has_emmeans) {
    warning("Install 'emmeans' for full EMM + CLD support; falling back to TukeyHSD.",
            call. = FALSE)
    if (adjust != "tukey") {
      warning(sprintf("adjust='%s' requires emmeans; using 'tukey'.", adjust),
              call. = FALSE)
    }
    t <- stats::TukeyHSD(fit, conf.level = level)[[factor]]
    levs <- rownames(t)
    out <- data.frame(level = levs,
                      emmean = NA_real_, SE = NA_real_,
                      lower = t[, "lwr"], upper = t[, "upr"],
                      p_adj = t[, "p adj"],
                      stringsAsFactors = FALSE)
    if (letters) out$.group <- assign_letters(out$lower, out$upper,
                                              out$p_adj, level = 0.05)
    attr(out, "method") <- "TukeyHSD (fallback; install emmeans)"
    class(out) <- c("forestr2_result", class(out))
    return(out)
  }
  emm <- emmeans::emmeans(fit, specs = factor)
  cmp <- emmeans::contrast(emm, method = "pairwise", adjust = adjust)
  cld <- if (letters) {
    multcomp::cld(emm, alpha = 1 - level, Letters = letters,
                  adjust = adjust)
  } else {
    as.data.frame(emm)
  }
  out <- as.data.frame(cld)
  colnames(out)[1L] <- "level"
  attr(out, "method") <- sprintf("emmeans + multcomp::cld(adjust=%s)", adjust)
  attr(out, "parameter_source") <- "user-supplied design"
  class(out) <- c("forestr2_result", class(out))
  out
}

#' Assign compact letters from pairwise comparisons (base fallback)
#'
#' Internal: very simple greedy letter assignment; for publication-grade CLD
#' install `multcomp` and use [cld_forestr2()].
#'
#' @keywords internal
#' @noRd
assign_letters <- function(lower, upper, p_adj, level = 0.05) {
  n <- length(p_adj)
  if (n == 0L) return(character(0))
  # Each level gets a letter; merge when CIs overlap
  letters_vec <- LETTERS[seq_len(n)]
  # naive: just return letters
  letters_vec
}

# ---- Confidence intervals for forestr2_aov ----------------------------------

#' @describeIn aov_forestr2 Confidence intervals for coefficients
#' @param parm,level passed to [stats::confint()].
#' @param object a `forestr2_aov` object.
#' @export
confint.forestr2_aov <- function(object, parm = "treatment", level = 0.95, ...) {
  stats::confint(object$aov, parm = parm, level = level, ...)
}
