# test-biomass.R
# Unit tests for biomass, carbon, and CO2e functions.
# Critical invariants:
#   - carbon fraction applied EXACTLY ONCE
#   - CO2e conversion is opt-in (no silent 44/12 multiplication)
#   - carbon_fraction range-checked
#   - component fractions reconcile to 1

test_that("calc_tree_biomass volume_density multiplies vol * density", {
  b <- calc_tree_biomass(dbh_cm = 20, height_m = 15,
                         method = "volume_density",
                         wood_density_kg_m3 = 400,
                         component = "stem",
                         biomass_expansion_factor = 1.0)
  v <- calc_tree_volume(dbh_cm = 20, height_m = 15,
                        method = "form_factor", form_factor = 0.45)
  expect_equal(b, v * 400, tolerance = 1e-5)
})

test_that("calc_tree_biomass allometric power law", {
  b <- calc_tree_biomass(dbh_cm = 20, height_m = 15,
                         method = "allometric",
                         equation_form = "power_dbh",
                         coefficients = c(a = 0.1, b = 2.4),
                         component = "aboveground")
  expect_equal(b, 0.1 * 20^2.4)
})

test_that("calc_tree_biomass volume_density total includes root", {
  b_total <- calc_tree_biomass(dbh_cm = 20, height_m = 15,
                               method = "volume_density",
                               wood_density_kg_m3 = 400,
                               component = "total",
                               biomass_expansion_factor = 1.0,
                               root_to_shoot_ratio = 0.25)
  b_ag <- calc_tree_biomass(dbh_cm = 20, height_m = 15,
                            method = "volume_density",
                            wood_density_kg_m3 = 400,
                            component = "aboveground",
                            biomass_expansion_factor = 1.0,
                            root_to_shoot_ratio = 0.25)
  expect_equal(b_total, b_ag * 1.25, tolerance = 1e-5)
})

test_that("calc_carbon_stock applies fraction once", {
  b <- 100
  c <- calc_carbon_stock(b, carbon_fraction = 0.47)
  expect_equal(c, 47)
  # Double application should NOT happen:
  c2 <- calc_carbon_stock(c, carbon_fraction = 0.47)
  expect_equal(c2, 47 * 0.47)
})

test_that("calc_carbon_stock rejects out-of-range fraction", {
  expect_error(calc_carbon_stock(100, carbon_fraction = 0.2),
               "outside the plausible range")
  expect_error(calc_carbon_stock(100, carbon_fraction = 0.7),
               "outside the plausible range")
})

test_that("calc_co2e is opt-in and uses 44/12", {
  c <- 100
  co2 <- calc_co2e(c)
  expect_equal(co2, 100 * 44/12)
})

test_that("calc_co2e does not silently convert carbon", {
  # Carbon mass should not magically become CO2e without calling calc_co2e.
  c <- calc_carbon_stock(100, carbon_fraction = 0.47)
  expect_equal(c, 47)
  # calc_co2e is opt-in: carbon stock does not have a "ratio" attribute
  expect_null(attr(c, "ratio"))
})

test_that("calc_component_biomass rejects non-reconciling fractions", {
  expect_error(
    calc_component_biomass(
      dbh_cm = 20, height_m = 15, species = "Pinus",
      component_fractions = data.frame(
        species = "Pinus",
        stem = 0.65, bark = 0.10, branches = 0.12,
        foliage = 0.03, roots = 0.09, deadwood = 0.05  # sum > 1
      )
    ),
    "do not sum"
  )
})

test_that("calc_component_biomass long form has all components", {
  frac <- data.frame(
    species   = "Pinus",
    stem = 0.65, bark = 0.10, branches = 0.12,
    foliage = 0.03, roots = 0.09, deadwood = 0.01
  )
  out <- calc_component_biomass(dbh_cm = 20, height_m = 15,
                                species = "Pinus",
                                component_fractions = frac,
                                total_biomass_kg = 100)
  expect_equal(nrow(out), 6L)
  expect_setequal(out$component,
                  c("stem","bark","branches","foliage","roots","deadwood"))
  expect_equal(sum(out$biomass_kg), 100, tolerance = 1e-10)
})

test_that("calc_aboveground_biomass sums correct components", {
  frac <- data.frame(
    species = "Picea",
    stem = 0.6, bark = 0.1, branches = 0.1,
    foliage = 0.05, roots = 0.1, deadwood = 0.05
  )
  cb <- calc_component_biomass(dbh_cm = 20, height_m = 15,
                               species = "Picea",
                               component_fractions = frac,
                               total_biomass_kg = 100)
  ag <- calc_aboveground_biomass(cb)
  expect_equal(ag$aboveground_biomass_kg, 100 * (0.6+0.1+0.1+0.05+0.05))
})

test_that("calc_total_biomass reconciles", {
  frac <- data.frame(
    species = "Picea",
    stem = 0.6, bark = 0.1, branches = 0.1,
    foliage = 0.05, roots = 0.1, deadwood = 0.05
  )
  cb <- calc_component_biomass(dbh_cm = 20, height_m = 15,
                               species = "Picea",
                               component_fractions = frac,
                               total_biomass_kg = 100)
  tot <- calc_total_biomass(cb)
  expect_equal(tot$total_biomass_kg, 100, tolerance = 1e-10)
})

test_that("fit_biomass_model returns expected class", {
  skip_if_not_installed("stats")
  d <- data.frame(
    biomass_kg = c(50, 80, 120, 180, 250),
    dbh_cm     = c(10, 15, 20, 25, 30),
    height_m   = c(8, 12, 15, 18, 20)
  )
  m <- fit_biomass_model(d, log(biomass_kg) ~ log(dbh_cm),
                         log_response = TRUE)
  expect_s3_class(m, "forestr2_biomass_model")
  expect_true(!is.null(m$metrics$rmse))
  expect_true(!is.null(m$bias_correction))
})

test_that("aggregate_biomass_plot computes Mg/ha", {
  inv <- tree_inventory(
    tree_id = c("T1","T2","T3","T4"),
    plot_id = c("P1","P1","P2","P2"),
    species = "Pinus",
    dbh_cm  = c(20, 22, 24, 26),
    height_m= c(15, 16, 17, 18),
    plot_area_ha = 0.05
  )
  inv$biomass_kg <- calc_tree_biomass(inv, method = "volume_density",
                                       wood_density_kg_m3 = 400)
  out <- aggregate_biomass_plot(inv, include_co2e = TRUE)
  expect_true("biomass_Mg_ha" %in% names(out))
  expect_true("carbon_stock_Mg_ha" %in% names(out))
  expect_true("co2e_Mg_ha" %in% names(out))
})
