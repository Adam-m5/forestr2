# test-inventory.R
# Unit tests for tree_inventory(), plot_summary(), stand_summary(),
# repeated_measurements(), growth_increments().

test_that("tree_inventory builds minimal valid object", {
  inv <- tree_inventory(
    tree_id = c("T1","T2"),
    plot_id = c("P1","P1"),
    species = c("Pinus","Pinus"),
    dbh_cm  = c(20, 25),
    height_m= c(15, 18),
    plot_area_ha = 0.05
  )
  expect_s3_class(inv, "forestr2_inventory")
  expect_s3_class(inv, "data.frame")
  expect_equal(nrow(inv), 2L)
  expect_equal(attr(inv, "units")[["dbh_cm"]], "cm")
})

test_that("tree_inventory rejects negative dbh", {
  expect_error(
    tree_inventory(tree_id = "T1", dbh_cm = -5, height_m = 10,
                   plot_area_ha = 0.01),
    "negative"
  )
})

test_that("tree_inventory rejects zero height", {
  expect_error(
    tree_inventory(tree_id = "T1", dbh_cm = 10, height_m = 0,
                   plot_area_ha = 0.01),
    "zero"
  )
})

test_that("tree_inventory flags duplicate tree_id within plot", {
  expect_error(
    tree_inventory(tree_id = c("T1","T1"), plot_id = c("P1","P1"),
                   dbh_cm = c(10,12), height_m = c(8,9),
                   plot_area_ha = 0.01),
    "duplicated"
  )
  expect_warning(
    tree_inventory(tree_id = c("T1","T1"), plot_id = c("P1","P1"),
                   dbh_cm = c(10,12), height_m = c(8,9),
                   plot_area_ha = 0.01, allow_duplicate_trees = TRUE)
  )
})

test_that("tree_inventory warns on implausible dbh > 300", {
  expect_warning(
    tree_inventory(tree_id = "T1", dbh_cm = 500, height_m = 10,
                   plot_area_ha = 0.01)
  )
})

test_that("plot_summary computes basal area per ha", {
  inv <- tree_inventory(
    tree_id = c("T1","T2","T3"),
    plot_id = c("P1","P1","P2"),
    species = "Pinus",
    dbh_cm  = c(20, 25, 30),
    height_m= c(15, 18, 20),
    plot_area_ha = 0.05
  )
  ps <- plot_summary(inv, expansion = "fixed_area")
  expect_s3_class(ps, "data.frame")
  expect_equal(nrow(ps), 2L)  # 2 plots
  expect_true("basal_area_m2_ha" %in% names(ps))
  # sanity: P1 has dbh 20 + 25, on 0.05 ha
  # ba per tree = pi * (0.2/2)^2 + pi * (0.25/2)^2 = 0.0314 + 0.0491 = 0.0805 m^2
  # /0.05 = 1.61 m^2/ha
  expect_gt(ps$basal_area_m2_ha[1L], 1.0)
})

test_that("repeated_measurements flags duplicate (tree_id, date)", {
  expect_error(
    repeated_measurements(
      data = data.frame(
        tree_id = c("T1","T1"),
        plot_id = "P1",
        dbh_cm  = c(10, 12),
        height_m= c(8, 9),
        plot_area_ha = 0.01,
        measurement_date = as.Date("2020-01-01")
      ),
      measurement_date = "measurement_date"
    )
  )
})

test_that("growth_increments computes first differences", {
  rep <- repeated_measurements(
    data = data.frame(
      tree_id = c("T1","T1","T2","T2"),
      plot_id = c("P1","P1","P2","P2"),
      dbh_cm  = c(10, 12, 20, 22),
      height_m= c(8, 9, 15, 16),
      plot_area_ha = 0.01,
      measurement_date = as.Date(c("2020-01-01","2021-01-01",
                                   "2020-01-01","2021-01-01"))
    ),
    measurement_date = "measurement_date"
  )
  g <- growth_increments(rep)
  expect_true("dbh_cm_increment" %in% names(g))
  expect_equal(g$dbh_cm_increment, c(NA, 2, NA, 2))
})

test_that("is_forestr2_inventory works", {
  inv <- tree_inventory(tree_id = "T1", dbh_cm = 10, height_m = 8,
                        plot_area_ha = 0.01)
  expect_true(is_forestr2_inventory(inv))
  expect_false(is_forestr2_inventory(mtcars))
})

test_that("tree_inventory requires plot_area_ha for fixed_area expansion", {
  inv <- tree_inventory(tree_id = c("T1","T2"),
                        plot_id = c("P1","P1"),
                        dbh_cm = c(10,12), height_m = c(8,9),
                        plot_area_ha = 0.01)
  inv$plot_area_ha <- NULL
  expect_error(plot_summary(inv, expansion = "fixed_area"),
               "plot_area_ha")
})

test_that("tree_inventory requires expansion_factor for explicit", {
  inv <- tree_inventory(tree_id = c("T1","T2"),
                        plot_id = c("P1","P1"),
                        dbh_cm = c(10,12), height_m = c(8,9),
                        plot_area_ha = 0.01)
  expect_error(plot_summary(inv, expansion = "explicit"),
               "expansion_factor")
})
