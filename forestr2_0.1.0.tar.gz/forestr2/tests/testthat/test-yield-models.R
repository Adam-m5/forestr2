# test-yield-models.R
# Unit tests for growth models, site index, self-thinning, mortality, simulation.

test_that("growth_function_library returns expected forms", {
  lib <- growth_function_library()
  expect_setequal(
    names(lib),
    c("chapman_richards","gompertz","logistic","von_bertalanffy",
      "schumacher","hossfeld","weibull","richards")
  )
})

test_that("site_index returns positive scalar", {
  si <- site_index(height_m = 18, age_yr = 30, base_age_yr = 50)
  expect_length(si, 1L)
  expect_gt(si, 0)
})

test_that("site_index rejects non-positive inputs", {
  expect_error(site_index(0, 30), "positive")
  expect_error(site_index(15, 0), "positive")
})

test_that("fit_growth_model chapman_richards on synthetic data", {
  skip_if_not_installed("stats")
  d <- data.frame(
    age_yr = seq(5, 40, by = 5),
    y      = c(3, 6, 9, 12, 14, 16, 17, 18)
  )
  m <- fit_growth_model(d, model = "chapman_richards")
  expect_s3_class(m, "forestr2_growth_model")
  p <- predict_growth(m, age_yr = c(45, 50))
  expect_equal(nrow(p), 2L)
  expect_true(all(p$predicted > 0))
})

test_that("predict_growth interval includes mean", {
  skip_if_not_installed("stats")
  d <- data.frame(
    age_yr = seq(5, 40, by = 5),
    y      = c(3, 6, 9, 12, 14, 16, 17, 18)
  )
  m <- fit_growth_model(d, model = "chapman_richards")
  p <- predict_growth(m, age_yr = 50, interval = "confidence")
  expect_true(p$lower <= p$predicted)
  expect_true(p$upper >= p$predicted)
})

test_that("self_thinning returns N for given dbh_q", {
  n <- self_thinning(dbh_q_cm = 25)
  expect_equal(n, 450)  # by definition at 25cm
  n2 <- self_thinning(dbh_q_cm = 10)
  expect_gt(n2, 450)  # smaller trees -> more stems
})

test_that("mortality decays stocking", {
  n10 <- mortality(n0 = 1000, annual_rate = 0.01, years = 10)
  expect_equal(n10, 1000 * 0.99^10, tolerance = 1e-10)
  expect_lt(n10, 1000)
})

test_that("simulate_stand returns one row per year", {
  out <- simulate_stand(
    initial = list(n_ha = 1000, ba_m2_ha = 25,
                   volume_m3_ha = 125, age_yr = 25),
    years = 10
  )
  expect_equal(nrow(out), 11L)
  expect_true(all(diff(out$n_ha) < 0))
  expect_true(all(diff(out$ba_m2_ha) > 0))
})

test_that("simulate_stand requires all initial fields", {
  expect_error(
    simulate_stand(initial = list(n_ha = 1000), years = 5),
    "ba_m2_ha"
  )
})
