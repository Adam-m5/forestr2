# test-volume.R
# Unit tests for volume functions: deterministic numeric results, validation,
# missing-value policy, output formats.

test_that("calc_tree_volume form_factor returns expected m3", {
  v <- calc_tree_volume(dbh_cm = 20, height_m = 15,
                        method = "form_factor", form_factor = 0.5)
  # ba = pi * (0.2/2)^2 = pi * 0.01 = 0.031416 m^2
  # v  = 0.031416 * 15 * 0.5 = 0.2356 m^3
  expect_equal(v, 0.0314159 * 15 * 0.5, tolerance = 1e-5)
})

test_that("calc_tree_volume converts cm to m only after validation", {
  v <- calc_tree_volume(dbh_cm = 100, height_m = 10,
                        method = "form_factor", form_factor = 1.0)
  # ba = pi * (1/2)^2 = pi/4 = 0.7854 m^2
  # v  = 0.7854 * 10 * 1.0 = 7.854 m^3
  expect_equal(v, pi * (1/2)^2 * 10 * 1.0, tolerance = 1e-5)
})

test_that("calc_tree_volume rejects negative dbh", {
  expect_error(
    calc_tree_volume(dbh_cm = -5, height_m = 10, method = "form_factor"),
    "negative"
  )
})

test_that("calc_tree_volume species-specific form_factor", {
  v <- calc_tree_volume(
    dbh_cm = c(20, 25), height_m = c(15, 18),
    species = c("Pinus","Picea"),
    form_factor = c("Pinus" = 0.5, "Picea" = 0.4),
    method = "form_factor"
  )
  expect_equal(v[1L], pi * (0.2/2)^2 * 15 * 0.5, tolerance = 1e-5)
  expect_equal(v[2L], pi * (0.25/2)^2 * 18 * 0.4, tolerance = 1e-5)
})

test_that("calc_tree_volume merchantable_height_m overrides height_m", {
  v <- calc_tree_volume(dbh_cm = 20, height_m = 15,
                        merchantable_height_m = 10,
                        method = "form_factor", form_factor = 1)
  expect_equal(v, pi * (0.2/2)^2 * 10 * 1, tolerance = 1e-5)
})

test_that("calc_tree_volume output='data.frame' preserves tree_id", {
  df <- calc_tree_volume(dbh_cm = c(20, 25), height_m = c(15, 18),
                         tree_id = c("T1","T2"),
                         method = "form_factor",
                         output = "data.frame")
  expect_s3_class(df, "forestr2_result")
  expect_equal(df$tree_id, c("T1","T2"))
  expect_equal(attr(df, "units"), "m3 per tree")
})

test_that("calc_tree_volume method='equation' uses function", {
  v <- calc_tree_volume(dbh_cm = c(10, 20),
                        method = "equation",
                        equation = function(dbh_cm, height_m) dbh_cm^2 / 1e4)
  expect_equal(v, c(0.01, 0.04))
})

test_that("calc_stem_section_volume Smalian", {
  # top=20cm, bot=25cm, L=4m
  # A1 = pi*10^2 = 314.16 cm^2; A2 = pi*12.5^2 = 490.87 cm^2
  # V = 4 * (314.16+490.87)/2 = 1610.06 cm^2 * m / 1e4 = 0.161006 m^3
  v <- calc_stem_section_volume(top_diameter_cm = 20, bot_diameter_cm = 25,
                                length_m = 4, method = "smalian")
  expect_equal(v, 4 * (pi*100 + pi*156.25)/2 / 1e4, tolerance = 1e-5)
})

test_that("calc_stem_section_volume Newton", {
  v <- calc_stem_section_volume(top_diameter_cm = 20, bot_diameter_cm = 25,
                                mid_diameter_cm = 22.5, length_m = 4,
                                method = "newton")
  # Am = pi*11.25^2 = 397.61
  # V = 4 * (314.16 + 4*397.61 + 490.87)/6 / 1e4 = 0.161289
  expect_equal(v, 4 * (pi*100 + 4*pi*126.5625 + pi*156.25)/6 / 1e4,
               tolerance = 1e-5)
})

test_that("calc_stem_section_volume Huber requires mid_diameter", {
  expect_error(
    calc_stem_section_volume(top_diameter_cm = 20, bot_diameter_cm = 25,
                             length_m = 4, method = "huber"),
    "mid_diameter_cm"
  )
})

test_that("calc_log_volume returns cumulative per tree", {
  df <- calc_log_volume(
    tree_id = c("T1","T1","T1"),
    log_number = 1:3,
    length_m = c(4, 4, 4),
    butt_diameter_cm = c(30, 25, 20),
    top_diameter_cm  = c(25, 20, 15)
  )
  expect_true("cumulative_volume_m3" %in% names(df))
  expect_true(all(diff(df$cumulative_volume_m3) > 0))
  expect_equal(nrow(df), 3L)
})

test_that("calc_merchantable_volume excludes small tops", {
  df <- calc_merchantable_volume(
    tree_id = c("T1","T1"),
    length_m = c(4, 4),
    butt_diameter_cm = c(30, 25),
    top_diameter_cm  = c(25, 5),   # second log excluded
    species = c("Pinus","Pinus"),
    min_top_diameter_cm = 7
  )
  expect_equal(df$included, c(TRUE, FALSE))
  expect_match(df$status_reason[2L], "min_top_diameter")
})

test_that("calc_volume_by_plot returns design-based SE", {
  inv <- tree_inventory(
    tree_id = c("T1","T2","T3","T4"),
    plot_id = c("P1","P1","P2","P2"),
    species = "Pinus",
    dbh_cm  = c(20, 22, 24, 26),
    height_m= c(15, 16, 17, 18),
    plot_area_ha = 0.05
  )
  inv$volume_m3 <- calc_tree_volume(inv, method = "form_factor")
  out <- calc_volume_by_plot(inv)
  expect_true("se" %in% names(out))
  expect_true("estimator" %in% names(out))
  expect_match(out$estimator, "design-based")
})

test_that("calc_volume_by_plot needs >=2 plots for CI", {
  inv <- tree_inventory(
    tree_id = c("T1","T2"),
    plot_id = c("P1","P1"),
    species = "Pinus",
    dbh_cm  = c(20, 22),
    height_m= c(15, 16),
    plot_area_ha = 0.05
  )
  inv$volume_m3 <- calc_tree_volume(inv)
  out <- calc_volume_by_plot(inv)
  expect_true(is.na(out$se))
})

test_that("fit_volume_model returns forestr2_volume_model", {
  skip_if_not_installed("stats")
  d <- data.frame(
    volume_m3 = c(0.2, 0.3, 0.5, 0.6, 0.8, 1.0),
    dbh_cm    = c(15, 18, 22, 25, 28, 30),
    height_m  = c(12, 14, 16, 18, 20, 22)
  )
  m <- fit_volume_model(d, volume_m3 ~ I(dbh_cm^2 * height_m))
  expect_s3_class(m, "forestr2_volume_model")
  expect_true(!is.null(m$metrics$rmse))
})

test_that("predict_volume returns vector length matching input", {
  d <- data.frame(
    volume_m3 = c(0.2, 0.3, 0.5, 0.6, 0.8, 1.0),
    dbh_cm    = c(15, 18, 22, 25, 28, 30),
    height_m  = c(12, 14, 16, 18, 20, 22)
  )
  m <- fit_volume_model(d, volume_m3 ~ I(dbh_cm^2 * height_m))
  p <- predict_volume(m, newdata = data.frame(dbh_cm = c(20,25),
                                              height_m = c(15,18)))
  expect_equal(nrow(p), 2L)
  expect_true("volume_m3" %in% names(p))
})
