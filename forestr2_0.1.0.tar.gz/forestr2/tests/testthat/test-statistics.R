# test-statistics.R
# Unit tests for aov_forestr2() and cld_forestr2().

test_that("aov_forestr2 returns forestr2_aov", {
  d <- data.frame(
    yield = c(10,12,11,15,16,14,9,11,10),
    treatment = factor(rep(c("A","B","C"), each = 3)),
    block = factor(rep(1:3, 3))
  )
  a <- aov_forestr2(yield ~ treatment + block, data = d, design = "rcbd")
  expect_s3_class(a, "forestr2_aov")
  expect_equal(a$design, "rcbd")
  expect_true("normality" %in% names(a$assumptions_doc))
})

test_that("aov_forestr2 rejects non-data.frame", {
  expect_error(
    aov_forestr2(y ~ x, data = list(y = 1:3, x = 1:3)),
    "data.frame"
  )
})

test_that("cld_forestr2 returns forestr2_result", {
  skip_if_not_installed("emmeans")
  d <- data.frame(
    yield = c(10,12,11,15,16,14,9,11,10,13,12,11),
    treatment = factor(rep(c("A","B","C","D"), each = 3)),
    block = factor(rep(1:3, 4))
  )
  a <- aov_forestr2(yield ~ treatment + block, data = d, design = "rcbd")
  cld <- cld_forestr2(a, factor = "treatment", adjust = "tukey",
                     letters = TRUE)
  expect_s3_class(cld, "forestr2_result")
  expect_equal(nrow(cld), 4L)
})

test_that("cld_forestr2 fallback to TukeyHSD when emmeans absent", {
  skip_if_not_installed("emmeans", minimum_version = NULL)
  # When emmeans IS installed we cannot test the fallback path; skip.
  # (testthat::skip_if_not_installed skips when NOT installed, so we invert.)
  skip("emmeans is installed; fallback path cannot be tested in this environment.")
  d <- data.frame(
    yield = c(10,12,11,15,16,14),
    treatment = factor(rep(c("A","B","C"), each = 2)),
    block = factor(rep(1:2, 3))
  )
  a <- aov_forestr2(yield ~ treatment + block, data = d, design = "rcbd")
  expect_warning(cld_forestr2(a, factor = "treatment"))
})

test_that("confint.forestr2_aov delegates to stats::confint", {
  d <- data.frame(
    yield = c(10,12,11,15,16,14,9,11,10),
    treatment = factor(rep(c("A","B","C"), each = 3)),
    block = factor(rep(1:3, 3))
  )
  a <- aov_forestr2(yield ~ treatment + block, data = d, design = "rcbd")
  ci <- confint(a, parm = "treatment", level = 0.95)
  expect_s3_class(ci, "matrix")
})
