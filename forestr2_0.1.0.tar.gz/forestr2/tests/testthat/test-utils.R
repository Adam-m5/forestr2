# test-utils.R
# Unit tests for utility helpers.

test_that("resolve_missing_policy matches arg", {
  expect_equal(resolve_missing_policy("warn"), "warn")
  expect_equal(resolve_missing_policy("return_na"), "return_na")
  expect_equal(resolve_missing_policy(NULL), "error")
  expect_error(resolve_missing_policy("foo"), "must be one of")
})

test_that("as_finite_numeric rejects negatives by default", {
  expect_error(as_finite_numeric(-1, "x"), "negative")
  expect_equal(as_finite_numeric(-1, "x", allow_negative = TRUE), -1)
})

test_that("as_finite_numeric rejects zeros unless allowed", {
  expect_error(as_finite_numeric(0, "x"), "zero")
  expect_equal(as_finite_numeric(0, "x", allow_zero = TRUE), 0)
})

test_that("match_length recycles scalar to vector", {
  expect_equal(match_length(5, 3, "x"), c(5,5,5))
  expect_error(match_length(1:2, 3, "x"), "length")
})

test_that("normalize_coef_table handles named vector", {
  out <- normalize_coef_table(c(a=1,b=2), "species")
  expect_equal(out$type, "named")
  expect_equal(out$data[["a"]], 1)
})

test_that("normalize_coef_table handles data.frame", {
  out <- normalize_coef_table(data.frame(species="P", val=1),
                              "species")
  expect_equal(out$type, "data.frame")
  expect_equal(out$key_col, "species")
})

test_that("lookup_species_value falls back to default", {
  coef <- normalize_coef_table(c("Pinus"=0.5), "species")
  expect_equal(lookup_species_value("Picea", coef, "form_factor",
                                    default = NA_real_),
               NA_real_)
  expect_equal(lookup_species_value("Pinus", coef, "form_factor",
                                    default = NA_real_),
               0.5)
})

test_that("se_value and ci_vector work", {
  expect_equal(se_value(1:10), sd(1:10)/sqrt(10))
  ci <- ci_vector(1:10)
  expect_true(ci["lower"] < ci["upper"])
})

test_that("format_sig returns string", {
  expect_equal(format_sig(0.123456789), "0.1235")
  expect_equal(format_sig("abc"), "abc")
})

test_that("forestr2_options returns list and can be queried", {
  opts <- forestr2_options()
  expect_true(is.list(opts))
  expect_equal(forestr2_options("forestr2.carbon_fraction"), 0.47)
})
