# This file is part of the 'forestr' package.
# Run testthat tests automatically when the package is loaded by R CMD check.

library(testthat)
library(forestr2)

test_check("forestr2")
