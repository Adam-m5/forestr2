## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment  = "#>",
  fig.width = 7, fig.height = 4
)
has_ggplot <- requireNamespace("ggplot2", quietly = TRUE)

